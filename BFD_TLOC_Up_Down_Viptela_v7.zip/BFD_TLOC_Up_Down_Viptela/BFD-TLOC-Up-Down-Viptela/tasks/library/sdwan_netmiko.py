#!/usr/bin/python
import logging

log = logging.getLogger(__name__)

try:
    import paramiko
    from hashlib import md5
    from netmiko import ConnectHandler
    HAS_NETMIKO = True
except ImportError:
    HAS_NETMIKO = False

from ansible.module_utils.basic import AnsibleModule


def _bypass_md5_fips():
    """Patch paramiko MD5 fingerprint for FIPS-compliant hosts."""
    class _FipsPKey(paramiko.PKey):
        def get_fingerprint_improved(self):
            return md5(self.asbytes(), usedforsecurity=False).digest()
    paramiko.PKey.get_fingerprint = _FipsPKey.get_fingerprint_improved


def _connect(host, username, password, timeout=30, _md5_patched=False):
    """Establish Netmiko SSH connection."""
    try:
        device = {
            "device_type": "cisco_ios",
            "ip": host,
            "username": username,
            "password": password,
            "secret": password,
            "read_timeout_override": timeout,
        }
        conn = ConnectHandler(**device)
        try:
            conn.enable()
        except Exception:
            pass
        return conn
    except ValueError as ve:
        if not _md5_patched:
            log.warning("MD5 FIPS error, applying bypass: %s", ve)
            _bypass_md5_fips()
            return _connect(host, username, password, timeout, _md5_patched=True)
        raise
    except Exception as e:
        log.error("SSH connection failed to %s: %s", host, e)
        raise


def _run_commands(conn, commands, timeout=30):
    """Run list of commands and return {cmd: output} dict."""
    results = {}
    try:
        for cmd in commands:
            output = conn.send_command_timing(cmd, last_read=3.0)
            results[cmd] = output
    except Exception as e:
        log.error("Command execution failed: %s", e)
        raise
    return results


def _run_via_cedge_vrf_ssh(conn, jump_host, username, password, commands, timeout):
    """SSH from cEdge to redundant router via VRF 1."""
    try:
        conn.send_command_timing(f"ssh -l {username} -vrf 1 {jump_host}", last_read=5.0)
        conn.send_command_timing(password, last_read=5.0)
        results = _run_commands(conn, commands, timeout)
        conn.send_command_timing("exit", last_read=2.0)
        return results
    except Exception as e:
        log.error("cEdge VRF SSH to %s failed: %s", jump_host, e)
        raise


def _run_via_vedge_vshell(conn, jump_host, username, password, commands, timeout):
    """SSH from vEdge to redundant router via vshell VPN 1."""
    try:
        conn.send_command_timing("vshell", last_read=3.0)
        conn.send_command_timing(
            f"request execute vpn 1 ssh -l {username}@{jump_host}", last_read=5.0
        )
        conn.send_command_timing(password, last_read=5.0)
        results = _run_commands(conn, commands, timeout)
        conn.send_command_timing("exit", last_read=2.0)
        conn.send_command_timing("exit", last_read=2.0)
        return results
    except Exception as e:
        log.error("vEdge vshell SSH to %s failed: %s", jump_host, e)
        raise


def main():
    module = AnsibleModule(
        argument_spec=dict(
            host=dict(type="str", required=True),
            username=dict(type="str", required=True),
            password=dict(type="str", required=True, no_log=True),
            commands=dict(type="list", required=True),
            timeout=dict(type="int", default=30),
            jump_host=dict(type="str", default=""),
            use_vrf_ssh=dict(type="bool", default=False),
            platform=dict(type="str", default=""),
        ),
        supports_check_mode=False,
    )

    if not HAS_NETMIKO:
        module.fail_json(msg="netmiko is required but not installed")

    try:
        conn = _connect(
            module.params["host"],
            module.params["username"],
            module.params["password"],
            module.params["timeout"],
        )

        if module.params["use_vrf_ssh"] and module.params["jump_host"]:
            if module.params["platform"] == "cedge":
                output = _run_via_cedge_vrf_ssh(
                    conn, module.params["jump_host"],
                    module.params["username"], module.params["password"],
                    module.params["commands"], module.params["timeout"],
                )
            else:
                output = _run_via_vedge_vshell(
                    conn, module.params["jump_host"],
                    module.params["username"], module.params["password"],
                    module.params["commands"], module.params["timeout"],
                )
        else:
            output = _run_commands(conn, module.params["commands"], module.params["timeout"])

        conn.disconnect()
        module.exit_json(changed=False, output=output)

    except Exception as e:
        module.fail_json(msg=str(e))


if __name__ == "__main__":
    main()
