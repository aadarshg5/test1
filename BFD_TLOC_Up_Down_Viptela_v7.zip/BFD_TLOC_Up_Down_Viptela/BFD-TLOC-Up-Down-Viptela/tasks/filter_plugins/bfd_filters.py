import re
import logging
from datetime import datetime, timedelta

log = logging.getLogger(__name__)


def extract_tloc_color(raw):
    """Extract TLOC color from Problem Summary TEXT field."""
    try:
        text_match = re.search(r"TEXT\s*:\s*(.+)", raw, re.IGNORECASE)
        if not text_match:
            return ""
        color_match = re.search(r"down[-\s]+(\S+)", text_match.group(1), re.IGNORECASE)
        return color_match.group(1).strip().rstrip(",.:;") if color_match else ""
    except Exception as e:
        log.error("extract_tloc_color failed: %s", e)
        raise


def detect_platform(show_version_output):
    """Detect vEdge or cEdge from show version output."""
    try:
        lower = show_version_output.lower()
        if any(kw in lower for kw in ("uptime", "cisco ios", "ios-xe", "xe software", "image")):
            return "cedge"
        return "vedge"
    except Exception as e:
        log.error("detect_platform failed: %s", e)
        raise


def parse_bfd_sessions(raw_output, color):
    """Parse BFD sessions from raw command output filtered by color."""
    sessions = []
    try:
        key = None
        for k in raw_output:
            if color.lower() in k.lower():
                key = k
                break
        if not key:
            for k in raw_output:
                if "bfd" in k.lower() and "sessions" in k.lower():
                    key = k
                    break
        if not key:
            return sessions
        text = raw_output[key]
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("-") or "SRC" in line.upper() or "DST" in line.upper():
                continue
            parts = line.split()
            if len(parts) >= 3:
                state = "up" if "up" in parts[2].lower() else "down"
                src_ip = parts[3] if len(parts) > 3 else ""
                dst_ip = parts[4] if len(parts) > 4 else ""
                sessions.append({
                    "peer": parts[0],
                    "state": state,
                    "src_ip": src_ip,
                    "dst_ip": dst_ip
                })
    except Exception as e:
        log.error("parse_bfd_sessions failed: %s", e)
        raise
    return sessions


def parse_bfd_history(raw_output, color):
    """Parse BFD history entries from raw output."""
    history = []
    try:
        key = None
        for k in raw_output:
            if "history" in k.lower() and color.lower() in k.lower():
                key = k
                break
        if not key:
            return history
        text = raw_output[key]
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("-"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                state = "up" if "up" in line.lower() else "down"
                ts_str = parts[0] if re.match(r"\d", parts[0]) else ""
                history.append({"timestamp": ts_str, "state": state})
    except Exception as e:
        log.error("parse_bfd_history failed: %s", e)
        raise
    return history


def is_flapping(history, window_minutes=60):
    """Check if BFD was flapping in the given time window."""
    try:
        if not history or len(history) < 2:
            return False
        cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
        windowed = []
        for entry in history:
            try:
                ts = datetime.strptime(entry.get("timestamp", ""), "%m/%d/%Y %H:%M:%S")
                if ts >= cutoff:
                    windowed.append(entry)
            except (ValueError, TypeError):
                continue
        if not windowed:
            windowed = history[-10:]
        transitions = sum(
            1 for i in range(1, len(windowed))
            if windowed[i]["state"] != windowed[i - 1]["state"]
        )
        return transitions > 1
    except Exception as e:
        log.error("is_flapping failed: %s", e)
        raise


def parse_control_connections(raw_output, platform):
    """Parse control connections into up and down lists."""
    result = {"up": [], "down": []}
    try:
        key = None
        for k in raw_output:
            if "control" in k.lower() and "connection" in k.lower():
                key = k
                break
        if not key:
            return result
        text = raw_output[key]
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("-") or "PEER" in line.upper():
                continue
            parts = line.split()
            if len(parts) >= 2:
                peer = parts[0]
                if "up" in line.lower():
                    result["up"].append({"peer": peer})
                else:
                    result["down"].append({"peer": peer})
    except Exception as e:
        log.error("parse_control_connections failed: %s", e)
        raise
    return result


def parse_local_properties(raw_output, color):
    """Parse public and private IPs from local-properties output."""
    result = {"pub_ip": "", "priv_ip": "", "color": color}
    try:
        key = None
        for k in raw_output:
            if "local" in k.lower() and "propert" in k.lower():
                key = k
                break
        if not key:
            return result
        text = raw_output[key]
        pub_match = re.search(r"public[- ]ip[:\s]+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", text, re.IGNORECASE)
        priv_match = re.search(r"private[- ]ip[:\s]+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", text, re.IGNORECASE)
        if pub_match:
            result["pub_ip"] = pub_match.group(1)
        if priv_match:
            result["priv_ip"] = priv_match.group(1)
    except Exception as e:
        log.error("parse_local_properties failed: %s", e)
        raise
    return result


def parse_interface_status(raw_output, color):
    """Parse interface name and state for the TLOC color."""
    result = {"name": "", "state": "unknown"}
    try:
        for key in raw_output:
            if "interface" in key.lower() and "description" not in key.lower():
                text = raw_output[key]
                for line in text.strip().split("\n"):
                    if color.lower() in line.lower():
                        parts = line.split()
                        if len(parts) >= 2:
                            result["name"] = parts[0]
                            result["state"] = "up" if "up" in line.lower() else "down"
                        break
                break
    except Exception as e:
        log.error("parse_interface_status failed: %s", e)
        raise
    return result


def parse_omp_peers(raw_output):
    """Parse OMP peers into up and down lists."""
    result = {"up": [], "down": []}
    try:
        key = None
        for k in raw_output:
            if "omp" in k.lower() and "peer" in k.lower():
                key = k
                break
        if not key:
            return result
        text = raw_output[key]
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("-") or "PEER" in line.upper():
                continue
            parts = line.split()
            if len(parts) >= 2:
                peer = parts[0]
                if "up" in line.lower():
                    result["up"].append({"peer": peer})
                else:
                    result["down"].append({"peer": peer})
    except Exception as e:
        log.error("parse_omp_peers failed: %s", e)
        raise
    return result


def parse_ipsec_tunnels(raw_output):
    """Parse IPsec tunnel state into formed and missing lists."""
    result = {"formed": [], "missing": []}
    try:
        key = None
        for k in raw_output:
            if "tunnel" in k.lower() or "ipsec" in k.lower():
                key = k
                break
        if not key:
            return result
        text = raw_output[key]
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line or line.startswith("-") or "SOURCE" in line.upper():
                continue
            parts = line.split()
            if len(parts) >= 2:
                if "up" in line.lower() or "active" in line.lower():
                    result["formed"].append({"peer": parts[0]})
                else:
                    result["missing"].append({"peer": parts[0]})
    except Exception as e:
        log.error("parse_ipsec_tunnels failed: %s", e)
        raise
    return result


def extract_peer_ips(sessions):
    """Extract src/dst IP pairs from BFD sessions."""
    try:
        return [{"src_ip": s.get("src_ip", ""), "dst_ip": s.get("dst_ip", "")}
                for s in sessions if s.get("dst_ip")]
    except Exception as e:
        log.error("extract_peer_ips failed: %s", e)
        raise


def parse_redundant_router_ip(raw_output, known_ip=""):
    """Parse redundant router IP from VRRP or odd/even LAN convention."""
    try:
        if known_ip:
            return known_ip
        combined = ""
        if isinstance(raw_output, dict):
            combined = "\n".join(str(v) for v in raw_output.values())
        else:
            combined = str(raw_output)
        vrrp_match = re.search(
            r"[Ss]tandby.*?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", combined
        )
        if vrrp_match:
            return vrrp_match.group(1)
        lan_ips = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.)(\d+)\b", combined)
        for prefix, last_octet in lan_ips:
            octet = int(last_octet)
            if 1 < octet < 254:
                peer_octet = octet + 1 if octet % 2 != 0 else octet - 1
                return f"{prefix}{peer_octet}"
        return ""
    except Exception as e:
        log.error("parse_redundant_router_ip failed: %s", e)
        raise


class FilterModule:
    def filters(self):
        return {
            "extract_tloc_color": extract_tloc_color,
            "detect_platform": detect_platform,
            "parse_bfd_sessions": parse_bfd_sessions,
            "parse_bfd_history": parse_bfd_history,
            "is_flapping": is_flapping,
            "parse_control_connections": parse_control_connections,
            "parse_local_properties": parse_local_properties,
            "parse_interface_status": parse_interface_status,
            "parse_omp_peers": parse_omp_peers,
            "parse_ipsec_tunnels": parse_ipsec_tunnels,
            "extract_peer_ips": extract_peer_ips,
            "parse_redundant_router_ip": parse_redundant_router_ip,
        }
