#!/bin/bash

############################################
# PARVEZ Hussain 11/18/2021
# Copyright 2021, Verizon Inc
#############################################

export PROGRAM=$(basename "$0")
export CWD='.'
export MODULES="${CWD}/modules"
export SCRIPTS="${CWD}/scripts"
export TEST=true
export ERRORFILE="${CWD}/output/errors.log"

#Source all modules
for FN in "${CWD}"/modules/* ; do
 . "${FN}"
done
# Set TEST_RUN and TEST_SKIP
settest
#
#Run the ReadVars function defined in the module ReadDecryptVars
ReadVars "${VARFILE}" "${ENCKEY}"
${TEST_RUN} && echo "returned to script"
#Now the variables are available to use in your script
# I will print them here just to check
${TEST_RUN} && { echo "
HOST: $HOST
TYPE: $TYPE
TACUSER: $TACUSER
TACPASS: $TACPASS
IPADDR: $IPADDR
NEID: $NEID
DATE: $DATE
TIME: $TIME"
}

# Make scripts executable
chmod +x $SCRIPTS/*
${TEST_RUN} && ls -l $SCRIPTS

# export NEID=2-stack ##CHANGE
# export NEID=5-stack ##CHANGE
# export HOST=$NEID

#############################################

export USERNAME=$(id -un)
export AUDITLOG="${CWD}/logs"     # log dir
export dATE=$(date +%d%b%Y_%H:%M:%S)      # Date string for logging
#CURDATE=$(date '+%Y%m%d')                # String of Current date
export CURDATE=$(date)                  # String of Current date
export CURDATESEC=$(date -d"$CURDATE" +%s)
export CURDATETIME=$(date '+%Y%m%d-%H%M%S')
#export LOCALHOST=$(hostname)

mkdir -p $AUDITLOG > /dev/null 2>&1
mkdir -p ${CWD}/output > /dev/null 2>&1
#ARGS=$@

## Check if Inputfile exist

  HostName
  DateTime
  UserName
  ${TEST_RUN} && echo "TACUSER: $TACUSER SSHPASS: $SSHPASS"

## Validate date and time
  date -d"$DATE $TIME"  > /dev/null 2>&1
  if [ $? -eq 1 ]; then
     echo "Invalid Date: $DATE $TIME"
     exit 1
  fi

export ALERT="$DATE $TIME"
export ALERT=$(date -d"$DATE $TIME")
echo -e "\nAlert Time: $ALERT"

export ALERTSEC=$(date -d"$ALERT" +%s)

# Validate hostname, retrieve Ip address and NEID
#cinfo_host

# sleep 3

# Logs and Reports are per HOST so Ansible can collect them all
export LOGFILE=$AUDITLOG/${CURDATETIME}_${HOST}.log # Log file
export REPORTFILE=$AUDITLOG/${CURDATETIME}_${HOST}_Report.txt # Report file

export MAILLOG=${CURDATETIME}_${PROGRAM}.log #  Log File to be email
export MAILREPORT=${CURDATETIME}_${PROGRAM}_Report.log # Report file to be emailed

## This line should be above cinfo_host function bcos cinfo uses it
#export NEID=`cat $INPUTFILE | grep NEID | awk -F":" '{print $NF}' | sed 's/ //g'`
[ "$NEID" = "" ] && echo -e "\n[ERROR]: Hostname not found.\n" | tee -a $LOGFILE $REPORTFILE &&  exit 1

#------------------------------------------------

echo -e "\n ==================== Log File  $DATE =======================" > $LOGFILE
echo -e "\n=============== SUMMARY REPORT  $DATE =======================" >> $REPORTFILE

echo -e "Hostname / IP          : ${HOST} / $IPADDR"    | tee -a $LOGFILE $REPORTFILE
echo -e "NEID                   : $NEID"         | tee -a $LOGFILE $REPORTFILE
echo -e "Alarm Start Time       : $ALERT"   | tee -a $LOGFILE $REPORTFILE
echo "-------------------------------------------------------------------" | tee -a $LOGFILE $REPORTFILE

#echo "Press any key";read

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


# turn on debug mode
#set -x

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


# Device Type is now passed from the Ansible wrapper
echo "Device type: $TYPE" | tee -a $LOGFILE $REPORTFILE

# Ping the device and see if it responds. If not exit
PingDevice "${IPADDR}" | tee -a $LOGFILE $REPORTFILE

case $TYPE in
  IOS)
    ${TEST_RUN} && echo "Running cisco_ios.sh"
    $SCRIPTS/cisco_ios.sh
    ;;
  "IOS 3850")
    ${TEST_RUN} && echo "Running cisco_3850.sh"
    $SCRIPTS/cisco_3850.sh
    ;;
  NEXUS)
    ${TEST_RUN} && echo "Running cisco_nxos.sh"
    $SCRIPTS/cisco_nxos.sh
    ;;
  *)
    echo "Unsupported Device Type" | tee -a $LOGFILE $REPORTFILE
    exit 3
    ;;
esac

# # Determine the device type (Nexus or ios or  others)
# ## We cannot run 'show version' on nexus devices due to a cisco bug
# ## Alternative option is to run 'show system uptime'

# export TYPE=NULL

# ## Check if it is a Nexus device
# export OUTPUT=$CWD/output/$NEID-show_system_uptime
# export COMMAND="show system uptime"
# Run_ssh_Command
# $TEST_RUN && cat $OUTPUT
# cat $OUTPUT | grep 'System start time' > /dev/null
# if [ $? -eq 0 ]; then
#   TYPE="NEXUS"
#   echo "Device type: $TYPE" | tee -a $LOGFILE $REPORTFILE
#   $SCRIPTS/cisco_nxos.sh
# fi

#  ## Check if it is a ios device. Here we can run 'show version'.
# if [ "$TYPE" = "NULL" ]; then
#   export OUTPUT=./output/$NEID-show_version
#   export COMMAND="show version"
#   Run_ssh_Command
#   cat $OUTPUT | grep -i ios | grep Cisco > /dev/null
#   if [ $? -eq 0 ]; then
#     cat $OUTPUT | grep WS-C3850  > /dev/null
#     if [ $? -eq 0 ]; then
#         TYPE="IOS 3850"
#         echo "Device type: $TYPE" | tee -a $LOGFILE $REPORTFILE
#         echo "Run $SCRIPTS/cisco_3850.sh"
#         ls -l $SCRIPTS/cisco_3850.sh
#         $SCRIPTS/cisco_3850.sh
#     else
#         TYPE="IOS"
#         echo "Device type: $TYPE" | tee -a $LOGFILE $REPORTFILE
#         $SCRIPTS/cisco_ios.sh
#     fi
 
#   fi
# fi

# if [ "$TYPE" = "NULL" ]; then
#   echo "Unable to determine Device type"
#   echo "Device type: $TYPE" | tee -a $LOGFILE $REPORTFILE
# fi

#EOF