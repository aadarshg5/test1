#!/bin/bash

############################################
# PARVEZ Hussain 11/18/2021
# Copyright 2021, Verizon Inc
#############################################

${TEST_RUN} && echo HOstName=$NEID
${TEST_RUN} && echo User=$TACUSER

#exit 0


####### All Modules goes here ######
#Source all modules
for FN in ${CWD}/modules/* ; do
 . ${FN}
done

# turn on debug mode
#set -x

#export NEID=sample ##CHANGE
#export NEID=sscorp-noqcja-15180723e366 ##CHANGE


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#=============================================
## Uptime, IOS version, device model, boot image, serial number and others.
## Check uptime to see if the devices has been rebooted
## or lost power within 12 hours of the time indicated by the requestor.
## OR
## If the device has been rebooted between time indicated by the requestor
## and the script execution DATE/TIME
#=============================================

FLAG=n
OverallStatus="Ok"

echo -e "\nAnalysis" >>  $REPORTFILE
echo -e "  a. Uptime, IOS version, device model, boot image, serial number and others......." | tee -a $LOGFILE $REPORTFILE

## Show Version
export OUTPUT=$CWD/output/$NEID-show_version
export COMMAND="show version"
Run_ssh_Command
 
# Check that the output file is not empty
if [ ! -s "$OUTPUT" ]; then
  echo "Connection failed output empty" | tee -a $LOGFILE $REPORTFILE
  echo "OverallStatus: Error" | tee -a $LOGFILE $REPORTFILE
  exit 3
fi

#cat $OUTPUT | tee -a $LOGFILE

MODEL=$(cat $OUTPUT | grep -E  "^Cisco" | grep -i Software)
IMAGE=$(cat $OUTPUT | grep ROM| awk -F, '{print $2}')
KERNEL_UPTIME=$(cat $OUTPUT | grep uptime)
RELOAD_TIME=$(cat $OUTPUT | grep 'System restarted at' | awk -F' at ' '{print $NF}')
RELOAD_REASON=$(cat $OUTPUT | grep 'Last reload reason' | awk -F: '{print $NF}')

WEEK=$(echo $KERNEL_UPTIME | grep week | awk -F'week' '{print $1}' | awk '{print $NF}')
DAY=$(echo $KERNEL_UPTIME | grep day | awk -F'day' '{print $1}' | awk '{print $NF}')
HOUR=$(echo $KERNEL_UPTIME | grep hour | awk -F'hour' '{print $1}' | awk '{print $NF}')
MIN=$(echo $KERNEL_UPTIME | grep minute | awk -F'minute' '{print $1}' | awk '{print $NF}')
SEC=$(echo $KERNEL_UPTIME | grep second | awk -F'second' '{print $1}' | awk '{print $NF}')

[ "$WEEK" = "" ] && WEEK=0
[ "$DAY" = "" ] && DAY=0
[ "$HOUR" = "" ] && HOUR=0
[ "$MIN" = "" ] && MIN=0
[ "$SEC" = "" ] && SEC=0

${TEST_RUN} && { echo "
Week=$WEEK
Day=$DAY
Hour=$HOUR
Min=$MIN
Sec=$SEC"
}


REBOOTTIME=$(date -d"$CURDATE -$WEEK weeks -$DAY days -$HRS hours -$MIN minutes -$SEC seconds")

GMTTIME=$(date -d"$RELOAD_TIME")
GMTTIMESEC=$(date -d"$RELOAD_TIME" +%s)

#GMTTIME=$(date -d"$RELOAD_TIME")
#GMTTIMESEC=$(date -d"$RELOAD_TIME" +%s)
GMTTIME=$REBOOTTIME
GMTTIMESEC=$(date -d"$REBOOTTIME" +%s)

  echo -e "     > [MODEL]:" | tee -a $LOGFILE $REPORTFILE
  echo -e "     > $MODEL" | tee -a $LOGFILE $REPORTFILE
  echo -e "     > [IMAGE]:              $IMAGE" | tee -a $LOGFILE $REPORTFILE
  echo -e "     > Reload Time:  $REBOOTTIME"| tee -a $LOGFILE $REPORTFILE
  echo -e "     > Reload Reason: $RELOAD_REASON" | tee -a $LOGFILE $REPORTFILE

## CURTIMESEC will always be greater than GMTTIMESEC
RebootSecDiff=$(( CURDATESEC - GMTTIMESEC ))

if [[ $RebootSecDiff -le 43200 ]]; then
  echo -e "     > [ERROR]: Devices rebooted in last 12 hours" | tee -a $LOGFILE $REPORTFILE
  FLAG=y
fi

if [[ $GMTTIMESEC -ge $ALERTSEC ]]; then
   RebootSecDiff=$(( GMTTIMESEC - ALERTSEC ))
else
   RebootSecDiff=$(( ALERTSEC - GMTTIMESEC ))
fi

if [[ $RebootSecDiff -le 43200 ]]; then
  echo -e "     > [ERROR]: Devices rebooted within 12 hours of Alert Time" | tee -a $LOGFILE $REPORTFILE
  FLAG=y
fi

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#echo "Press any key";read

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#=============================================
## Displays a terse output of all error counters on the switch
## Execute twice with a MINIMUM 10 second pause between executions.
## Diff the counters to get "incrementing" counters.
## If counter decrease ignore
## If counter increase highlight
#=============================================

echo -e "\n  b. Checking incrementing counters for error.......................[25 sec Runtime]"  | tee -a $REPORTFILE

sleep 3

export OUTPUT=$CWD/output/$NEID-show_interface_counter_err
export COMMAND="show interface counter err"

Run_ssh_Command
 cp -p $OUTPUT  ${OUTPUT}_old     ##CHANGE


#### Wait 15 seconds and run the command again
echo -e "\nWaiting 15 seconds and running the command again" | tee -a $LOGFILE
export SEC=15
 sleep $SEC
 #CHANGE there are other jobs running with sleep in the command so this never exists
# JOB=$(ps -ef | grep sleep | grep -v grep | wc -l)
# while [ "$JOB" -ge 1 ]; do
#     spin
#     JOB=$(ps -ef | grep sleep | grep -v grep | wc -l)
# done

Run_ssh_Command

## Now we have two files $OUTPUT and $OUTPUT_old
## Each file will be broken up into 3 subfiles each
#   sed 's/\r$//' file.txt > out.txt -- remove carriage Return

for FILE in $OUTPUT ${OUTPUT}_old; do

        cp -p $FILE ${FILE}_ORIG   ## Backup the original file

        sed -i 's/ \{1,\}/,/g' $FILE    ## Replace multiple space with comma
 #       sed -i 's/\r$//g' $FILE        ## remove carriage Return
        sed -i 's/0Connection.*$/0/g' $FILE   ## delete the line '0Connection,to,sscorp-noqcja-15180723e366,closed,by,remote,host'

        ##Extract all lines between string 'Align-Err' and 'Single-Col'.
        ##Include the line 'Align-Err'. But exclude line 'Single-Col'
        awk '/Align-Err/ {p=1} /Single-Col/ {p=0} p' ${FILE} > ${FILE}_1

        #Remove blank lines
        sed -i '/^$/d' ${FILE}_1

        ##Extract all lines between string 'Single-Col' and 'SQETest-Err'.
        ##Include the line 'Single-Col'. But exclude line 'SQETest-Err'
        awk '/Single-Col/ {p=1} /SQETest-Err/ {p=0} p' ${FILE} > ${FILE}_2

        #Remove blank lines
        sed -i '/^$/d' ${FILE}_2

        ##Extract all lines between string 'SQETest-Err' till EOF.

        awk '/SQETest-Err/,/*/' ${FILE} > ${FILE}_3

        #Remove blank lines
        sed -i '/^$/d' ${FILE}_3
done

## Start comparison between values of old subfiles and new subfiles

PORT=$CWD/output/$NEID-port
OLDOUTPUT=${OUTPUT}_old
FLAG=n
i=1
while [ $i -le 3 ]; do
#  echo -e "\n i = $i"
   ## Extract the 1st column and remove the top line
   cat ${OUTPUT}_$i | awk -F"," '{print $1}'|  sed  "1d" > $PORT
   for INTERFACE in $(cat $PORT); do
                INTERFACE="$INTERFACE,"   ##Add a comma(,) at the end to distinguish from (Te1/1,) and (Te1/10,)
#echo INTERFACE=$INTERFACE
        OLDLINE=$(cat ${OLDOUTPUT}_$i | grep $INTERFACE)
        NEWLINE=$(cat ${OUTPUT}_$i | grep $INTERFACE)
#echo OLDLINE=$OLDLINE
#echo NEWLINE=$NEWLINE

## Compare between the values
        k=2
        while [ $k -le 6 ]; do
          OLDVAL=$(echo $OLDLINE | awk -v myvar="$k" -F',' '{print $myvar}')
          NEWVAL=$(echo $NEWLINE | awk -v myvar="$k" -F',' '{print $myvar}')
#echo OLDVAL=$OLDVAL
#echo NEWVAL=$NEWVAL
          if [ $OLDVAL -lt $NEWVAL ]; then
            COUNTER=$(cat ${OUTPUT}_$i | head -1 |  awk -v myvar="$k" -F',' '{print $myvar}')  ## Capture the counter name
            echo "     > [ERROR]: ${INTERFACE}[${COUNTER}] Prev=$OLDVAL, Cur=$NEWVAL" | tee -a $LOGFILE $REPORTFILE
            FLAG=y
          fi
          k=$(( k + 1 ))
        done

      done
      i=$(( i + 1 ))
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e ""           | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------

echo -e "\n  c. Checking bgp summary status.................................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_ip_bgp_summary
export COMMAND="show ip bgp summary"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE

#LastReboot=1w0d
#LastReboot=1d0h
#LastReboot=01:00:00

# Capture all data after 'MsgRcvd' till EOF
cat $OUTPUT | awk '/MsgRcvd/{p = 1;next} /*/{p = 0 } p' > ${OUTPUT}_tmp

# Capture all the interfaces

INTERFACE=$(cat ${OUTPUT}_tmp | awk '{print $1}')

#echo $INTERFACE
for i in $INTERFACE; do
LastReboot=""
LINE=$(cat ${OUTPUT}_tmp | grep -w $i)
LastReboot=$(echo $LINE | awk '{print $9}')
LastReboot_to_Uptime

echo | tee -a $LOGFILE
echo $LINE              | tee -a $LOGFILE
echo Neighbor:  $i, LastReboot: $LastReboot, DAYS: $DAYS        | tee -a $LOGFILE
#echo DAYS=$DAYS                | tee -a $LOGFILE
echo -e "Uptime         : $UPTIME"      | tee -a $LOGFILE
echo -e "Alert Time     : $ALERT"       | tee -a $LOGFILE

# Scenerio 1:
# Alert time came FIRST and Uptime of Neighbor came later. i.e UPTIMESEC > ALERTSEC
# Should trigger an ERROR saying that there is a state change of the neighbor.
# rrespective of within 24 hours or not.
if [ ${UPTIMESEC} -gt ${ALERTSEC} ]; then
   echo "     > $LINE"     >> $REPORTFILE
   echo "     > [ERROR]: Change of state of neighbor after alert." | tee -a $LOGFILE $REPORTFILE
   FLAG=y
else
# Scenerio 2:
# Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
## a. Should trigger an ERROR if it is within 24 hours of Alert time
# Scenerio 3:
# Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
## b. Should NOT trigger an ERROR if Uptime is more than 24 hours of Alert time
  Diff=$(( ALERTSEC - UPTIMESEC ))
    if [ $Diff -le 86400 ];then
        echo "     > $LINE"     >> $REPORTFILE
        echo "     > [ERROR]: Alert triggered Within 24 hours of Interface time" | tee -a $LOGFILE $REPORTFILE
        FLAG=y
    fi
fi

#echo "Press any key";read
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------

echo -e "\n  d. Checking OSPF neighbors and their status..............." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_ip_ospf_neighbor_detail
#export OUTPUT=$NEID-show_ip_ospf_neighbor_detail
export COMMAND="show ip ospf neighbor detail"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE

#LastReboot=1w0d
#LastReboot=1d0h
#LastReboot=01:00:00

# Capture all lines with string 'Neighbor' and join odd and even lines
## sed '$!N;s/\n/,/' -- join odd and even lines
cat $OUTPUT | grep Neig | grep -v priority | sed '$!N;s/\n/,/' > ${OUTPUT}_tmp

# Capture all the interfaces

INTERFACE=$(cat ${OUTPUT}_tmp | awk '{print $2}' | sed 's/,//')

#echo $INTERFACE
for i in $INTERFACE; do
echo Interface=$i
LastReboot=""
LINE=$(cat ${OUTPUT}_tmp | grep -w $i)
LastReboot=$(echo $LINE | awk '{print $NF}')
echo $LINE
echo LastReboot=$LastReboot

#exit 0

LastReboot_to_Uptime

echo -e "Alert Date:       $ALERT"
echo -e "Interface Uptime: $UPTIME"

# Scenerio 1:
# Alert time came FIRST and Uptime of Neighbor came later. i.e UPTIMESEC > ALERTSEC
# Should trigger an ERROR saying that there is a state change of the neighbor.
# rrespective of within 24 hours or not.
if [ ${UPTIMESEC} -gt ${ALERTSEC} ]; then
   echo -e "     > $LINE           " >> $REPORTFILE
   echo -e "     > [ERROR]: Change of state of neighbor after alert." | tee -a $LOGFILE $REPORTFILE
   FLAG=y
else
# Scenerio 2:
# Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
## a. Should trigger an ERROR if it is within 24 hours of Alert time
# Scenerio 3:
# Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
## b. Should NOT trigger an ERROR if Uptime is more than 24 hours of Alert time
  Diff=$(( ALERTSEC - UPTIMESEC ))
    if [ $Diff -le 86400 ];then
        echo -e "     >$LINE"           >> $REPORTFILE
        echo -e "     >[ERROR]: Alert triggered Within 24 hours of Interface time" | tee -a $LOGFILE $REPORTFILE
        FLAG=y
    fi
fi

#echo "Press any key";read
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------
#=============================================
## Graph showing CPU utilization.
## Detect from output sustained CPU at 100%
#=============================================
##A: Look analyze first line of output for utilization.
## If five seconds, one minute, or five minutes is >80% that is fail.
##B: Look at each row indicating a process,
#look at the column for 5sec 1min 5min. If any of these are >50% that is fail.



#
echo -e "\n  e. Checking CPU Utilization............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_processes_cpu_history
#export OUTPUT=$NEID-show_processes_cpu_history
export COMMAND="show processes cpu history"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE


##
## sed -n '1,/<pattern>/p' -- Extract all lines from beginning till pattern match
## sed -e's/^ *//g'     -- Remove spaces from beginning of the line
## sed '/^$/d'          -- Remove blank lines

cat $OUTPUT \
  | sed -n '1,/per second/p' \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperSec

if grep -E "80.*#" "${OUTPUT}"_CPUperSec > /dev/null; then
  echo "     > [ERROR]: CPU per Second is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
  OverallStatus="Error"
else
  echo "     > CPU per Second is OK" | tee -a $LOGFILE $REPORTFILE
fi

cat $OUTPUT \
  | awk '/per second/{ f = 1; next } /per minute/{ f = 0 } f' $OUTPUT \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperMin

cat ${OUTPUT}_CPUperMin | grep -E "80.*#" > /dev/null

if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Minute is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
  OverallStatus="Error"
else
  echo "     > CPU per Minute is OK" | tee -a $LOGFILE $REPORTFILE
fi

cat $OUTPUT \
  | awk '/per minute/{ f = 1; next } /per hour/{ f = 0 } f' $OUTPUT \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperHr

cat ${OUTPUT}_CPUperHr | grep -E "80.*#" > /dev/null

if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Hour is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
  OverallStatus="Error"
else
  echo "     > CPU per Hour is OK" | tee -a $LOGFILE $REPORTFILE
fi


#--------------------------------------------------------------------

#=============================================
## Health check for all installed modules. Can be checked for individual modules.
# For each test in the output,
# look at the "error code" line and look for "DIAG_FAILED".
#=============================================

echo -e "\n  f. Health check for all installed modules.. ............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_diagnostic_result_module_all_detail
export COMMAND="show diagnostic result module all detail"

Run_ssh_Command

# cat $OUTPUT | tee -a $LOGFILE


## Add Extra Module for Tagging
cat $OUTPUT | grep "Module 999" > /dev/null 2>&1
if [ $? -eq 1 ]; then
echo "Module 999" >> $OUTPUT
fi

## Capture all the modules
cat $OUTPUT  | grep -E -i "^Module" | awk -F: '{print $1}' | awk '{print $NF}'  > $CWD/output/AllModules

Mod1=""
Mod2=""

for MOD in $(cat $CWD/output/AllModules); do

if [ "$Mod1" = "" ]; then
   Mod1="Module $MOD"

else
   Mod2="Module $MOD"
#   Printing the Data Blocks Including the “BEGIN” Boundary Only
   sed -n "/$Mod1/, /$Mod2/{ /$Mod2/!p }" $OUTPUT > ${OUTPUT}_Module_${PrevMod}
   Mod1=$Mod2

fi
PrevMod=$MOD
done

## Remove Module tag
cat $CWD/output/AllModules | grep -v 999 > $CWD/output/AllModules_tmp
mv $CWD/output/AllModules_tmp $CWD/output/AllModules


## sed '$!N;s/\n/,/' -- JOin Odd and even lines

for MOD in $(cat $CWD/output/AllModules); do
echo
 cat ${OUTPUT}_Module_${MOD} \
    | grep -E "Test|Error code"  \
        | grep -v "Test results" \
        | sed '$!N;s/\n/,/' \
        | awk '{print $1,$2,$NF}' \
        > ${OUTPUT}_Module_${MOD}_tmp


 cat ${OUTPUT}_Module_${MOD}_tmp | grep DIAG_FAILED > ${OUTPUT}_Module_${MOD}_Failed

 if [[ -s ${OUTPUT}_Module_${MOD}_Failed ]] ; then
     echo "     > [ERROR]: Module $MOD" | tee -a $LOGFILE $REPORTFILE
     cat ${OUTPUT}_Module_${MOD}_Failed | sed -e 's/^/     /' | tee -a $LOGFILE $REPORTFILE
     FLAG=y
 fi
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------


#=============================================
## Process, Its ID and % of utilization.
## "A: Look analyze first line of output for utilization.
## If five seconds, one minute, or five minutes is >80% that is fail.
## B: Look at each row indicating a process,
## look at the column for 5sec 1min 5min.
## If any of these are >50% that is fail."      "Report if A Fails
#=============================================


echo -e "\n  g. Check Process ID and utilization..............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_proc_cpu_sort
export COMMAND="show proc cpu sort | ex 0.00"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE

## Remove blank lines
sed -i '/^$/d' $OUTPUT

echo

LINE=$(cat $OUTPUT | grep 'CPU utilization')
echo $LINE
#CPU utilization for five seconds: 14%/0%; one minute: 21%; five minutes: 22%

CPU_5Sec=$(echo $LINE | awk -F';' '{print $1}' | awk '{print $NF}' | sed 's/%.*//g')
CPU_1Min=$(echo $LINE | awk -F';' '{print $2}' | awk '{print $NF}' | sed 's/%.*//g')
CPU_5Min=$(echo $LINE | awk -F';' '{print $3}' | awk '{print $NF}' | sed 's/%.*//g')

if (( $(echo "${CPU_5Sec} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: CPU Utilization for 5 Seconds shows ABOVE 50% -- ${CPU_5Sec}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
fi
if (( $(echo "${CPU_1Min} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: CPU Utilization for 1 Minute shows ABOVE 50% -- ${CPU_1Min}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
fi
if (( $(echo "${CPU_5Min} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: CPU Utilization for 5 Minutes shows ABOVE 50%  -- ${CPU_5Min}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
fi

## awk  -v OFS=, '{$8="XXX"; print }' -- Replace 8th column with XXX
cat $OUTPUT | grep -E -v "CPU utilization|PID" | awk  -v OFS=, '{$8="XXX"; print }' > ${OUTPUT}_tmp

F=n
for LINE in $(cat ${OUTPUT}_tmp); do
    CPU_5Sec=$(echo $LINE | awk -F',' '{print $5}' | sed 's/%.*//g')
    CPU_1Min=$(echo $LINE | awk -F',' '{print $6}' | sed 's/%.*//g')
    CPU_5Min=$(echo $LINE | awk -F',' '{print $7}' | sed 's/%.*//g')
        PROC=$(echo $LINE | awk -F"XXX" '{print $NF}' | sed 's/^,//g' | sed 's/,/ /g')

if (( $(echo "${CPU_5Sec} > 80" | bc -l) ));then
       echo -e "[ERROR]: $PROC for 5 Seconds shows ABOVE 80% -- ${CPU_5Sec}%"
           F=y
           FLAG=y
    fi
if (( $(echo "${CPU_1Min} > 80" | bc -l) ));then
       echo -e "[ERROR]: $PROC for 1 Minute shows ABOVE 80% -- ${CPU_1MIN}%"
           F=y
           FLAG=y
    fi
if (( $(echo "${CPU_5Min} > 80" | bc -l) ));then
       echo -e "[ERROR]: $PROC for 5 Minutes shows ABOVE 80% -- ${CPU_5Min}%"
           F=y
           FLAG=y
    fi
done
if [ "$F" = "y" ];then
     cat $OUTPUT | head -12 | tee -a $LOGFILE
fi

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   OverallStatus="Error"
fi
FLAG=n

#echo "Press any key";read

#=============================================
## Memory, Its ID and % of utilization.
## A: Processor Pool analyze % used. If greater than 80% = fail
## B: I/O Pool analyze % used. If greater than 80% = fail"      "Report if A Fails
## Report top 10 (if applicable) processes"
#=============================================


echo -e "\n  h. Check Memory ID and utilization..............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_processes_memory_sorted
export COMMAND="show processes memory sorted"

Run_ssh_Command

#cat $OUTPUT | tee -a $LOGFILE


cat $OUTPUT | grep "Pool Total" > ${OUTPUT}_tmp

TOTAL=$(cat ${OUTPUT}_tmp | grep Processor | awk  '{print $4}')
USED=$(cat ${OUTPUT}_tmp | grep Processor | awk  '{print $6}')
RESULT=$(echo "scale = 2; $USED / $TOTAL * 100" | bc -l)

if (( $(echo "$RESULT > 80" | bc -l) ));then
  echo -e "     > [ERROR]: Processor Pool Memory used is more than 80% -- ${RESULT}%" | tee -a $LOGFILE $REPORTFILE
  FLAG=y
else
  echo -e "     > [INFO]: Processor Pool Memory used is ${RESULT}% (< 80%)-- OK" | tee -a $LOGFILE $REPORTFILE
fi

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#=============================================
## SAMsgThread -- Check memory holding if greater than 5 MB
#=============================================


echo -e "\n  i. Checking SAMsgThread memory holding..............................." | tee -a $LOGFILE $REPORTFILE

SIZE=$(cat $OUTPUT | grep SAMsgThread | awk '{print $5}')

#echo SIZE=$SIZE

if [ "$SIZE" != "" ]; then
  MBSIZE=$(echo "scale = 1; $SIZE / 1000000" | bc -l)
  if [ "$SIZE" -ge 5000000 ];then
        echo -e "     > [ERROR]: SAMsgThread memory Holding is more than 5MB  -- $MBSIZE MB" | tee -a $LOGFILE $REPORTFILE
        FLAG=y

  else
        echo -e "     > [INFO]: SAMsgThread memory Holding is LESS than 5MB ( $MBSIZE MB ) -- OK" | tee -a $LOGFILE $REPORTFILE
  fi
else
   echo -e "     > [INFO]: SAMsgThread process is not running" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
fi

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

echo "" >> $REPORTFILE
echo "Overall Status :${OverallStatus}" >> $REPORTFILE
echo -e "\n=============================== End of Report ======================\n" >> $REPORTFILE


echo -e "\n End of the script \n" | tee -a $LOGFILE
#EOF