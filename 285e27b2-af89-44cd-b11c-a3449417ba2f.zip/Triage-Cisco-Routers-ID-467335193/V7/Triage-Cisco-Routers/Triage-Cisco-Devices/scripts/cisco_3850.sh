#!/bin/bash

############################################
# PARVEZ Hussain 11/18/2021
# Copyright 2021, Verizon Inc
#############################################

${TEST_RUN} && echo "In cisco_3850 script"
${TEST_RUN} && { echo "
Variables
PWD $CWD
Report $REPORTFILE
Log $LOGFILE"
}

# echo HostName=$NEID
# echo User=$TACUSER

####### All Modules goes here ######
#Source all modules
for FN in "${CWD}"/modules/* ; do
 . "${FN}"
done

# turn on debug mode
# set -x

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#=============================================
## Uptime, IOS version, device model, boot image, serial number and others.
## Check uptime to see if the devices has been rebooted
## or lost power within 12 hours of the time indicated by the requestor.
## OR
## If the device has been rebooted between time indicated by the requestor
## and the script execution DATE/TIME
#=============================================

FLAG=n
OverallStatus="Ok"

echo -e "\nAnalysis" >>  $REPORTFILE
echo -e "  a. Uptime, IOS version, device model and others......." | tee -a $LOGFILE $REPORTFILE

## Show Version
export OUTPUT=$CWD/output/$NEID-show_version
export COMMAND="show version"
Run_ssh_Command

#cat $OUTPUT | tee -a $LOGFILE

echo -e "Output $OUTPUT" | tee -a $LOGFILE

## Identify the number of switches running on the device
SWCOUNT=$(cat $OUTPUT | grep WS-C3850 | grep -Ev "^Model Number|memory" | wc -l)

## Identify the Primary Switch number
PRI_SWITCH=$(cat $OUTPUT | grep WS-C3850 | grep -Ev '^Model Number' | grep '\*' | awk '{print $2}')
echo -e "Primary Switch = 0$PRI_SWITCH" | tee -a $LOGFILE

if [ $PRI_SWITCH = "0" ];then
  echo "Unable to identify the primary switch" | tee -a $LOGFILE
  echo "OverallStatus: Error" | tee -a $LOGFILE $REPORTFILE
  exit 1
fi

## CApture primary switch data
## Capture data from beginning of file till the pattern 'Switch Ports'
sed '/Switch Ports/q' $OUTPUT > ${OUTPUT}_PrimarySwitch

echo -e "Primary Switch info: ${OUTPUT}_PrimarySwitch" | tee -a $LOGFILE

## Capture data for other switches
# read

for (( i=1; i<=$SWCOUNT; i++ )); do
   if  [ $i -eq ${PRI_SWITCH} ]; then
      continue      #The first section of the $OUTPUT is Primary switch, already captured.
   fi
   sed -n "/Switch 0$i/, /Switch 0/p" $OUTPUT > ${OUTPUT}_Switch0$i
   echo -e "Output for Switch0$i: ${OUTPUT}_Switch0$i" | tee -a $LOGFILE
done

## Now that we have data for all switches, we will capture switch start time and reload reason

echo ALERT TIME = $ALERT
echo Current Date = $CURDATETIME

for (( i=1; i<=$SWCOUNT; i++ )); do
   if  [ $i -eq ${PRI_SWITCH} ]; then
      SWOUTPUT=${OUTPUT}_PrimarySwitch
      SWITCH="Switch 0$i [PRIMARY]"
    else
      SWOUTPUT=${OUTPUT}_Switch0$i
      SWITCH="Switch 0$i"
   fi

#   read

   RELOAD_REASON=$(cat $SWOUTPUT | grep 'Last reload reason' | awk -F: '{print $NF}')
   UPTIME=$(cat $SWOUTPUT | grep uptime)

echo "$SWITCH Uptime = $UPTIME" | tee -a $LOGFILE

   WEEK=$(echo $UPTIME | grep week | awk -F'week' '{print $1}' | awk '{print $NF}')
   DAY=$(echo $UPTIME | grep day | awk -F'day' '{print $1}' | awk '{print $NF}')
   HOUR=$(echo $UPTIME | grep hour | awk -F'hour' '{print $1}' | awk '{print $NF}'
   )
   MIN=$(echo $UPTIME | grep minute | awk -F'minute' '{print $1}' | awk '{print $NF}')
   SEC=$(echo $UPTIME | grep second | awk -F'second' '{print $1}' | awk '{print $NF}')

   [ "$WEEK" = "" ] && WEEK=0
   [ "$DAY" = "" ] && DAY=0
   [ "$HOUR" = "" ] && HOUR=0
   [ "$MIN" = "" ] && MIN=0
   [ "$SEC" = "" ] && SEC=0

   REBOOTTIME=$(date -d"$CURDATE -$WEEK weeks -$DAY days -$HRS hours -$MIN minutes -$SEC seconds")

   GMTTIME=$(date -d"$UPTIME")
   GMTTIMESEC=$(date -d"$UPTIIME" +%s)

   #GMTTIME=`date -d"$RELOAD_TIME"`
   #GMTTIMESEC=`date -d"$RELOAD_TIME" +%s`
   # GMTTIME=$REBOOTTIME
   GMTTIMESEC=$(date -d"$REBOOTTIME" +%s)

#   echo -e "-----------------------------------------" | tee -a  $LOGFILE $REPORTFILE
   echo -e "\n     $SWITCH" | tee -a $LOGFILE $REPORTFILE
   echo -e "     -------------" | tee -a  $LOGFILE $REPORTFILE
   echo -e "     > Reload Time:  $REBOOTTIME"| tee -a $LOGFILE $REPORTFILE
   echo -e "     > Reload Reason: $RELOAD_REASON" | tee -a $LOGFILE $REPORTFILE

   ## CURTIMESEC will always be greater than GMTTIMESEC
   RebootSecDiff=$(expr ${CURDATESEC} - ${GMTTIMESEC})

   if [[ $RebootSecDiff -le 43200 ]]; then
      echo -e "     > [ERROR]: Devices rebooted in last 12 hours" | tee -a $LOGFILE $REPORTFILE
      FLAG=y
   fi

   if [[ $GMTTIMESEC -ge $ALERTSEC ]]; then
      RebootSecDiff=$(expr $GMTTIMESEC - $ALERTSEC)
   else
      RebootSecDiff=$(expr $ALERTSEC - $GMTTIMESEC)
   fi

   if [[ $RebootSecDiff -le 43200 ]]; then
      echo -e "     > [ERROR]: Devices rebooted within 12 hours of Alert Time" | tee -a $LOGFILE $REPORTFILE
      FLAG=y
   fi

   if [ "$FLAG" = "n" ]; then
      echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
   else
      echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
      OverallStatus="Error"
   fi

done
FLAG=n

#echo "Press any key";read

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



#=============================================
## Displays a terse output of all error counters on the switch
## Execute twice with a MINIMUM 10 second pause between executions.
## Diff the counters to get "incrementing" counters.
## If counter decrease ignore
## If counter increase highlight
#=============================================

echo -e "\n  b. Checking incrementing counters for error.......................[25 sec Runtime]"  | tee -a $REPORTFILE

sleep 3

export OUTPUT=$CWD/output/$NEID-show_interface_counter_err
export COMMAND="show interface counter err"

Run_ssh_Command

cp -p $OUTPUT  ${OUTPUT}_old     ##CHANGE 

echo "Output: $OUTPUT" | tee -a $LOGFILE

#### Wait 15 seconds and run the command again
echo -e "\nWaiting 15 seconds and running the command again" | tee -a $LOGFILE
export SEC=15
 sleep $SEC

Run_ssh_Command

## Now we have two files $OUTPUT and $OUTPUT_old
## Each file will be broken up into subfiles as per no. of switches

for FILE in $OUTPUT ${OUTPUT}_old; do

   cp -p $FILE ${FILE}_ORIG   ## Backup the original file

   sed -i 's/\r$//g' $FILE        ## remove carriage Return
   sed -i 's/0Connection.*$/0/g' $FILE   ## delete the line '0Connection,to,....closed,by,remote,host'
   sed -e 's/^ *//g' $FILE > ${FILE}_tmp ## Remove spaces at the end of each line
   mv ${FILE}_tmp $FILE
   sed -i 's/ \{1,\}/,/g' $FILE    ## Replace multiple space with comma
   sed -i '/^$/d' $FILE   	## Remove blank lines

   ##Extract all lines between string 'Align-Err' and 'Single-Col'.
   ##Include the line 'Align-Err'. But exclude line 'Single-Col'

   awk '/Align-Err/ {p=1} /Single-Col/ {p=0} p' ${FILE} > ${FILE}_1

   echo -e "Output: ${FILE}_1" | tee -a $LOGFILE

   ##Extract all lines between string 'Single-Col' till EOF.

   awk '/Single-Col/,/*/' ${FILE} > ${FILE}_2

   echo -e "Output: ${FILE}_2" | tee -a $LOGFILE

done

#read

## Start comparison between values of old subfiles and new subfiles

PORT=$CWD/output/$NEID-port
OLDOUTPUT=${OUTPUT}_old
FLAG=n
i=1
while [ $i -le 2 ]; do
  echo -e "\n i = $i"
   ## Extract the 1st column and remove the top line
   cat ${OUTPUT}_$i | awk -F"," '{print $1}'|  sed  "1d" > $PORT
   for INTERFACE in $(cat $PORT); do
       INTERFACE="$INTERFACE,"   ##Adding a comma(,) at the end to distinguish from (Te1/1,) and (Te1/10,)
      echo INTERFACE=$INTERFACE
      OLDLINE=$(cat ${OLDOUTPUT}_$i | grep $INTERFACE)
      NEWLINE=$(cat ${OUTPUT}_$i | grep $INTERFACE)
#echo OLDLINE=$OLDLINE
#echo NEWLINE=$NEWLINE

# read

## Compare between the values
        k=2
        while [ $k -le 6 ]; do
          OLDVAL=$(echo $OLDLINE | awk -v myvar="$k" -F',' '{print $myvar}')
          NEWVAL=$(echo $NEWLINE | awk -v myvar="$k" -F',' '{print $myvar}')
#echo OLDVAL=$OLDVAL
#echo NEWVAL=$NEWVAL
#read
          if [ $OLDVAL -lt $NEWVAL ]; then
            COUNTER=$(cat ${OUTPUT}_$i | head -1 |  awk -v myvar="$k" -F',' '{print $myvar}')  ## Capture the counter name
            echo "     > [ERROR]: ${INTERFACE}[${COUNTER}] Prev=$OLDVAL, Cur=$NEWVAL" | tee -a $LOGFILE $REPORTFILE
            FLAG=y
          fi
          k=$(expr $k + 1)
#read
        done

      done
      i=$(expr $i + 1)
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e ""           | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------

#=============================================
## Graph showing CPU utilization.
## Detect from output sustained CPU at 100%
#=============================================
##A: Look analyze first line of output for utilization.
## If five seconds, one minute, or five minutes is >80% that is fail.
##B: Look at each row indicating a process,
#look at the column for 5sec 1min 5min. If any of these are >50% that is fail.


echo -e "\n  c. Checking CPU Utilization............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_processes_cpu_history
export COMMAND="show processes cpu history"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE


##
## sed -n '1,/<pattern>/p' -- Extract all lines from beginning till pattern match
## sed -e's/^ *//g'     -- Remove spaces from beginning of the line
## sed '/^$/d'          -- Remove blank lines

cat $OUTPUT \
  | sed -n '1,/per second/p' \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperSec

cat ${OUTPUT}_CPUperSec | grep -E "80.*#" > /dev/null
if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Second is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
else
  echo "     > CPU per Second is OK" | tee -a $LOGFILE $REPORTFILE
fi

cat $OUTPUT \
  | awk '/per second/{ f = 1; next } /per minute/{ f = 0 } f' $OUTPUT \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperMin

cat ${OUTPUT}_CPUperMin | grep -E "80.*#" > /dev/null

if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Minute is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
else
  echo "     > CPU per Minute is OK" | tee -a $LOGFILE $REPORTFILE
fi

cat $OUTPUT \
  | awk '/per minute/{ f = 1; next } /per hour/{ f = 0 } f' $OUTPUT \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperHr

cat ${OUTPUT}_CPUperHr | grep -E "80.*#" > /dev/null

if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Hour is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
else
  echo "     > CPU per Hour is OK" | tee -a $LOGFILE $REPORTFILE
fi


#--------------------------------------------------------------------

#=============================================
## Health check for all installed modules. Can be checked for individual modules.
# For each test in the output,
# look at the "error code" line and look for "DIAG_FAILED".
#=============================================

echo -e "\n  d. Health check for all installed switches.. ............................." | tee -a $LOGFILE $REPORTFILE
#read
export OUTPUT=$CWD/output/$NEID-show_diagnostic_result_switch_all_detail
export COMMAND="show diagnostic result switch all detail"

Run_ssh_Command

# cat $OUTPUT | tee -a $LOGFILE

#   remove carriage Return
sed -i 's/\r$//' $OUTPUT

## Add Extra Switch for Tagging
cat $OUTPUT | grep "switch 999:" > /dev/null 2>&1
if [ $? -eq 1 ]; then
echo "switch 999:" >> $OUTPUT
fi

#read

## Capture all the switches
cat $OUTPUT  | grep -E -i "^switch" | awk -F: '{print $1}' | awk '{print $NF}'  > $CWD/output/Allswitches

SW1=""
SW2=""
#read
for SW in $(cat $CWD/output/Allswitches); do

   if [ "$SW1" = "" ]; then
     	SW1="[Ss]witch $SW"

   else
   	SW2="[Ss]witch $SW"
	#   Printing the Data Blocks Including the “BEGIN” Boundary Only
   	sed -n "/$SW1/, /$SW2/{ /$SW2/!p }" $OUTPUT > ${OUTPUT}_switch_${PrevMod}
   	SW1=$SW2

   fi
PrevMod=$SW

#read

done

## Remove Module tag
cat $CWD/output/Allswitches | grep -v 999 > $CWD/output/Allswitches_tmp
mv $CWD/output/Allswitches_tmp $CWD/output/Allswitches

#read
## sed '$!N;s/\n/,/' -- JOin Odd and even lines

for SW in $(cat $CWD/output/Allswitches); do
echo
 cat ${OUTPUT}_switch_${SW} \
    | grep -E "Test|Error code"  \
        | grep -v "Test results" \
        | sed '$!N;s/\n/,/' \
        | awk '{print $1,$2,$NF}' \
        > ${OUTPUT}_switch_${SW}_tmp
read

 cat ${OUTPUT}_switch_${SW}_tmp | grep DIAG_FAILED > ${OUTPUT}_switch_${SW}_Failed

 if [[ -s ${OUTPUT}_switch_${SW}_Failed ]] ; then
     echo "     > [ERROR]: switch $SW" | tee -a $LOGFILE $REPORTFILE
     cat ${OUTPUT}_switch_${SW}_Failed | sed -e 's/^/     /' | tee -a $LOGFILE $REPORTFILE
     FLAG=y
 fi

#read
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

echo "" >> $REPORTFILE
echo "Overall Status :${OverallStatus}" >> $REPORTFILE
echo -e "\n=============================== End of Report ======================\n" >> $REPORTFILE


echo -e "\n End of the script \n" | tee -a $LOGFILE
#EOF