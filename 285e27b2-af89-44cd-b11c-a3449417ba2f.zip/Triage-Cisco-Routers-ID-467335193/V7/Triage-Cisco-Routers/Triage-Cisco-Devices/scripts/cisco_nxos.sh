#!/bin/bash

############################################
# PARVEZ Hussain 11/18/2021
# Copyright 2021, Verizon Inc
#############################################

#export PROGRAM=$(basename $0) #DO NOT declare here
#export CWD=$(dirname $0)       #DO NOT declare here
#export MODULES=$CWD/modules   #DO NOT declare here

####### All Modules goes here ######
#Source all modules
for FN in ${CWD}/modules/* ; do
 . ${FN}
done

# turn on debug mode
#set -x

#export NEID=sample ##CHANGE
#export NEID=sscorp-noqcja-15180723e366 ##CHANGE


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#=============================================
## Uptime, IOS version, device model, boot image, serial number and others.
## Check uptime to see if the devices has been rebooted
## or lost power within 12 hours of the time indicated by the requestor.
## OR
## If the device has been rebooted between time indicated by the requestor
## and the script execution DATE/TIME
#=============================================

FLAG=n
OverallStatus="Ok"

echo -e "\nAnalysis" >>  $REPORTFILE
echo -e "  a. Checking Uptime......." | tee -a $LOGFILE $REPORTFILE

## Show System Uptime
export OUTPUT=$CWD/output/$NEID-show_system_uptime
export COMMAND="show system uptime"
Run_ssh_Command

# Check that the output file is not empty
if [ ! -s $OUTPUT ]; then
  echo "Connection failed output emply" | tee -a $LOGFILE $REPORTFILE
  echo "OverallStatus: Error" | tee -a $LOGFILE $REPORTFILE
  exit 3
fi

REBOOTTIME=$(cat $OUTPUT | grep 'System start time' | awk -F'time:' '{print $NF}' | sed -e's/^ *//g')

GMTTIME=$REBOOTTIME
GMTTIMESEC=$(date -d"$REBOOTTIME" +%s)

echo -e "     > Reload Time:  $REBOOTTIME" | tee -a $LOGFILE $REPORTFILE

## CURTIMESEC will always be greater than GMTTIMESEC
RebootSecDiff=$(( CURDATESEC - GMTTIMESEC ))

if [[ $RebootSecDiff -le 43200 ]]; then
  echo -e "     > [ERROR]: Devices rebooted in last 12 hours" | tee -a $LOGFILE $REPORTFILE
  FLAG=y
fi

if [[ $GMTTIMESEC -ge $ALERTSEC ]]; then
   RebootSecDiff=$(( GMTTIMESEC - ALERTSEC ))
else
   RebootSecDiff=$(( ALERTSEC - GMTTIMESEC ))
fi

if [[ $RebootSecDiff -le 43200 ]]; then
  echo -e "     > [ERROR]: Devices rebooted within 12 hours of Alert Time" | tee -a $LOGFILE $REPORTFILE
  FLAG=y
fi

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
   else
   echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#echo "Press any key";read

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#=============================================
## Displays a terse output of all error counters on the switch
## Execute twice with a MINIMUM 10 second pause between executions.
## Diff the counters to get "incrementing" counters.
## If counter decrease ignore
## If counter increase highlight
#=============================================

echo -e "\n  b. Checking incrementing counters for error.......................[25 secs Runtime]"  | tee -a $LOGFILE $REPORTFILE

sleep 3

export OUTPUT=$CWD/output/$NEID-show_interface_counter_err
export COMMAND="show interface counter err"

Run_ssh_Command

cp -p $OUTPUT  ${OUTPUT}_old     ##CHANGE

#### Wait 15 seconds and run the command again
echo -e "\nWaiting 15 seconds and running the command again" | tee -a $LOGFILE
export SEC=15
 sleep $SEC    #CHANGE
#JOB=$(ps -ef | grep sleep | grep -v grep | wc -l)
#while [ "$JOB" -ge 1 ]; do
#    spin
#    JOB=$(ps -ef | grep sleep | grep -v grep | wc -l)
#done

Run_ssh_Command

## Now we have two files $OUTPUT and $OUTPUT_old
## Each file will be broken up into 3 subfiles each
#   sed 's/\r$//' file.txt > out.txt -- remove carriage Return

for FILE in $OUTPUT ${OUTPUT}_old; do

        cp -p $FILE ${FILE}_ORIG   ## Backup the original file ##CHANGE

        sed -i 's/ \{1,\}/,/g' $FILE    ## Replace multiple space with comma
 #       sed -i 's/\r$//g' $FILE        ## remove carriage Return
        sed -i 's/0Connection.*$/0/g' $FILE   ## delete the line '0Connection,to,sscorp-noqcja-15180723e366,closed,by,remote,host'
        sed -i '/\-\-\-\-\-\-\-/d' $FILE  ## Remove lines with '--------------'
        sed -i 's/\-\-\,/0\,/g' $FILE    ##Replace --, with 0,
        sed -i 's/\-\-$/0/g' $FILE      ##Replace --<eol> with 0
        sed -i '/^$/d' ${FILE}          ##Remove blank lines


        ##Extract all lines between string 'Align-Err' and 'Single-Col'.
        ##Include the line 'Align-Err'. But exclude line 'Single-Col'
        awk '/Align-Err/ {p=1} /Single-Col/ {p=0} p' ${FILE} > ${FILE}_1

        ##Extract all lines between string 'Single-Col' and 'SQETest-Err'.
        ##Include the line 'Single-Col'. But exclude line 'SQETest-Err'
        awk '/Single-Col/ {p=1} /SQETest-Err/ {p=0} p' ${FILE} > ${FILE}_2

        ## Ignore all the discarded ports
        if grep -q InDiscards "${FILE}"; then

           ##Extract all lines between string 'SQETest-Err' and 'InDiscards'.
           ##Include the line 'SQETest-Err'. But exclude line 'InDiscards'
           awk '/SQETest-Err/ {p=1} /InDiscards/ {p=0} p' ${FILE} > ${FILE}_3
           sed -i '$ d' "${FILE}"_3

        else

           ##Extract all lines between string 'SQETest-Err' till EOF.
           awk '/SQETest-Err/,/*/' "${FILE}" > "${FILE}"_3

        fi

done

## Start comparison between values of old subfiles and new subfiles

PORT=$CWD/output/$NEID-port
OLDOUTPUT=${OUTPUT}_old
FLAG=n
i=1
while [ $i -le 3 ]; do
#  echo -e "\n i = $i"
   ## Extract the 1st column and remove the top line
   cat ${OUTPUT}_$i | awk -F"," '{print $1}'|  sed  "1d" > $PORT
   for INTERFACE in $(cat $PORT); do
                INTERFACE="$INTERFACE,"   ##Add a comma(,) at the end to distinguish from (Te1/1,) and (Te1/10,)
#echo INTERFACE=$INTERFACE
        OLDLINE=$(cat ${OLDOUTPUT}_$i | grep $INTERFACE)
        NEWLINE=$(cat ${OUTPUT}_$i | grep $INTERFACE)
#echo OLDLINE=$OLDLINE
#echo NEWLINE=$NEWLINE

## Compare between the values
        k=2
        while [ $k -le 6 ]; do
          OLDVAL=$(echo $OLDLINE | awk -v myvar="$k" -F',' '{print $myvar}')
          NEWVAL=$(echo $NEWLINE | awk -v myvar="$k" -F',' '{print $myvar}')
#echo OLDVAL=$OLDVAL
#echo NEWVAL=$NEWVAL
          if [ $OLDVAL -lt $NEWVAL ]; then
            COUNTER=$(cat ${OUTPUT}_$i | head -1 |  awk -v myvar="$k" -F',' '{print $myvar}')  ## Capture the counter name
            echo "     > [ERROR]: ${INTERFACE}[${COUNTER}] Prev=$OLDVAL, Cur=$NEWVAL" | tee -a $LOGFILE $REPORTFILE
            FLAG=y
          fi
          k=$((k + 1))
        done

      done
      i=$((i + 1))
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
else
   echo -e "     > Status ----- ERR" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------

echo -e "\n  c. Checking bgp summary status.................................." | tee -a $LOGFILE $REPORTFILE

## Determine if bgp module is running.
## If so, then run 'show ip bgp summary' and get the stats
#bgp                    1          enabled
#bgp                    1          enabled(not-running)
#bgp                    1          disable (edited)

export OUTPUT=$CWD/output/$NEID-show_feature_i_bgp
export COMMAND="show feature | i bgp"

Run_ssh_Command

cat $OUTPUT
cat $OUTPUT | grep enabled | grep -v not-running > /dev/null
if [ $? -eq 0 ]; then
   echo -e "     > bgp module is enabled" | tee -a $LOGFILE $REPORTFILE
   export OUTPUT=$CWD/output/$NEID-show_ip_bgp_summary
   export COMMAND="show ip bgp summary"
   Run_ssh_Command
   cat $OUTPUT | tee -a $LOGFILE

   #LastReboot=1w0d
   #LastReboot=1d0h
   #LastReboot=01:00:00

   # Capture all data after 'MsgRcvd' till EOF
   cat $OUTPUT | awk '/MsgRcvd/{p = 1;next} /*/{p = 0 } p' > ${OUTPUT}_tmp

   # Capture all the interfaces

   INTERFACE=$(cat ${OUTPUT}_tmp | awk '{print $1}')

   #echo $INTERFACE
   for i in $INTERFACE; do
      LastReboot=""
      LINE=$(cat ${OUTPUT}_tmp | grep -w $i)
      LastReboot=$(echo $LINE | awk '{print $9}')
      LastReboot_to_Uptime

      echo | tee -a $LOGFILE
      echo $LINE              | tee -a $LOGFILE
      echo Neighbor:  $i, LastReboot: $LastReboot, DAYS: $DAYS        | tee -a $LOGFILE
      #echo DAYS=$DAYS                | tee -a $LOGFILE
      echo -e "Uptime         : $UPTIME"      | tee -a $LOGFILE
      echo -e "Alert Time     : $ALERT"       | tee -a $LOGFILE

      # Scenerio 1:
      # Alert time came FIRST and Uptime of Neighbor came later. i.e UPTIMESEC > ALERTSEC
      # Should trigger an ERROR saying that there is a state change of the neighbor.
      # rrespective of within 24 hours or not.
      if [ ${UPTIMESEC} -gt ${ALERTSEC} ]; then
         echo "     > $LINE"     >> $REPORTFILE
         echo "     > [ERROR]: Change of state of neighbor after alert." | tee -a $LOGFILE $REPORTFILE
         FLAG=y
      else
         # Scenerio 2:
         # Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
         ## a. Should trigger an ERROR if it is within 24 hours of Alert time
         # Scenerio 3:
         # Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
         ## b. Should NOT trigger an ERROR if Uptime is more than 24 hours of Alert time
         Diff=$(( ALERTSEC - UPTIMESEC ))
         if [ $Diff -le 86400 ];then
            echo "     > $LINE"     >> $REPORTFILE
            echo "     > [ERROR]: Alert triggered Within 24 hours of Interface time" | tee -a $LOGFILE $REPORTFILE
            FLAG=y
         fi
      fi

      #echo "Press any key";read
   done

   if [ "$FLAG" = "n" ]; then
      echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
   fi
else
   echo
   echo "     > bgp module is NOT running or disabled" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi

FLAG=n


#--------------------------------------------------------------------

echo -e "\n  d. Checking OSPF neighbors and their status..............." | tee -a $LOGFILE $REPORTFILE


## Determine if ospf module is running.
## If so, then run 'show ip ospf neighbor detail' and get the stats
#ospf                    1          enabled
#ospf                    1          enabled(not-running)
#ospf                    1          disable (edited)

export OUTPUT=$CWD/output/$NEID-show_feature_i_ospf
export COMMAND="show feature | i ospf"

Run_ssh_Command

cat $OUTPUT
cat $OUTPUT | grep enabled | grep -v not-running > /dev/null
if [ $? -eq 0 ]; then
   echo -e "     > ospf module is enabled" | tee -a $LOGFILE $REPORTFILE
echo
   export OUTPUT=$CWD/output/$NEID-show_ip_ospf_neighbor_detail
   export COMMAND="show ip ospf neighbor detail"
   Run_ssh_Command

   cat $OUTPUT | tee -a $LOGFILE

   #LastReboot=1w0d
   #LastReboot=1d0h
   #LastReboot=01:00:00

   # Capture all lines with string 'Neighbor' and 'last change' and 'last change'.
   # Then join odd and even lines

   ## sed '$!N;s/\n/,/' -- join odd and even lines
   cat $OUTPUT | grep -E "Neighbor|last change" | sed '$!N;s/\n/,/' > ${OUTPUT}_tmp

   # Capture all the interfaces

   INTERFACE=$(cat ${OUTPUT}_tmp | awk '{print $2}' | sed 's/,//')

   #echo $INTERFACE
   for i in $INTERFACE; do
      echo Interface=$i
      LastReboot=""
      LINE=$(cat ${OUTPUT}_tmp | grep -w $i)
      LastReboot=$(echo $LINE | awk '{print $NF}')
      echo $LINE
      echo LastReboot=$LastReboot

      #exit 0

      LastReboot_to_Uptime

      echo -e "Alert Date:       $ALERT"
      echo -e "Interface Uptime: $UPTIME"

      # Scenerio 1:
      # Alert time came FIRST and Uptime of Neighbor came later. i.e UPTIMESEC > ALERTSEC
      # Should trigger an ERROR saying that there is a state change of the neighbor.
      # rrespective of within 24 hours or not.
      if [ ${UPTIMESEC} -gt ${ALERTSEC} ]; then
         echo -e "     > $LINE           " >> $REPORTFILE
         echo -e "     > [ERROR]: Change of state of neighbor after alert." | tee -a $LOGFILE $REPORTFILE
         FLAG=y
      else
         # Scenerio 2:
         # Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
         ## a. Should trigger an ERROR if it is within 24 hours of Alert time
         # Scenerio 3:
         # Uptime of Neighbor came first and Alert time came later. i.e UPTIMESEC < ALERTSEC
         ## b. Should NOT trigger an ERROR if Uptime is more than 24 hours of Alert time
         Diff=$(( ALERTSEC - UPTIMESEC ))
         if [ $Diff -le 86400 ];then
            echo -e "     >$LINE"           >> $REPORTFILE
            echo -e "     >[ERROR]: Alert triggered Within 24 hours of Interface time" | tee -a $LOGFILE $REPORTFILE
            FLAG=y
         fi
      fi

      #echo "Press any key";read
   done

   if [ "$FLAG" = "n" ]; then
      echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
   else
      echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
      OverallStatus="Error"
   fi

else
   echo -e "     > ospf module is NOT running or disabled" | tee -a $LOGFILE $REPORTFILE
fi

FLAG=n

#--------------------------------------------------------------------
#=============================================
## Graph showing CPU utilization.
## Detect from output sustained CPU at 100%
#=============================================
##A: Look analyze first line of output for utilization.
## If five seconds, one minute, or five minutes is >80% that is fail.
##B: Look at each row indicating a process,
#look at the column for 5sec 1min 5min. If any of these are >50% that is fail.

#
echo -e "\n  e. Checking CPU Utilization............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_processes_cpu_history
export COMMAND="show processes cpu history"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE

##
## sed -n '1,/<pattern>/p' -- Extract all lines from beginning till pattern match
## sed -e's/^ *//g'     -- Remove spaces from beginning of the line
## sed '/^$/d'          -- Remove blank lines

cat $OUTPUT \
  | sed -n '1,/per second/p' \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperSec

cat ${OUTPUT}_CPUperSec | grep -E "80.*#" > /dev/null
if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Second is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
  OverallStatus="Error"
else
  echo "     > CPU per Second is OK" | tee -a $LOGFILE $REPORTFILE
fi

cat $OUTPUT \
  | awk '/per second/{ f = 1; next } /per minute/{ f = 0 } f' $OUTPUT \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperMin

cat ${OUTPUT}_CPUperMin | grep -E "80.*#" > /dev/null

if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Minute is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
  OverallStatus="Error"
else
  echo "     > CPU per Minute is OK" | tee -a $LOGFILE $REPORTFILE
fi

cat $OUTPUT \
  | awk '/per minute/{ f = 1; next } /per hour/{ f = 0 } f' $OUTPUT \
  | sed -e's/^ *//g' \
  | sed '/^$/d' \
  | grep -E "^10 |^20 |^30 |^40 |^50 |^60 |^70 |^80 |^90 |^100 " \
  > ${OUTPUT}_CPUperHr

cat ${OUTPUT}_CPUperHr | grep -E "80.*#" > /dev/null

if [ $? -eq 0 ]; then
  echo "     > [ERROR]: CPU per Hour is ABOVE 80%" | tee -a $LOGFILE $REPORTFILE
  OverallStatus="Error"
else
  echo "     > CPU per Hour is OK" | tee -a $LOGFILE $REPORTFILE
fi

#--------------------------------------------------------------------

#=============================================
## Health check for all installed modules. Can be checked for individual modules.
# For each test in the output,
# look at the "error code" line and look for "DIAG_FAILED".
#=============================================

echo -e "\n  f. Health check for all installed modules.. ............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_diagnostic_result_module_all_detail
export COMMAND="show diagnostic result module all detail"

Run_ssh_Command

 cat $OUTPUT | tee -a $LOGFILE


## Add Extra Module for Tagging
cat $OUTPUT | grep "Module 999" > /dev/null 2>&1
if [ $? -eq 1 ]; then
echo "Module 999" >> $OUTPUT
fi

## Capture all the modules
cat $OUTPUT  | grep -E "^Module" | awk -F: '{print $1}' | awk '{print $NF}'  > $CWD/output/AllModules

Mod1=""
Mod2=""

for MOD in $(cat $CWD/output/AllModules); do

if [ "$Mod1" = "" ]; then
   Mod1="Module $MOD"

else
   Mod2="Module $MOD"
#   Printing the Data Blocks Including the “BEGIN” Boundary Only
   sed -n "/$Mod1/, /$Mod2/{ /$Mod2/!p }" $OUTPUT > ${OUTPUT}_Module_${PrevMod}
   Mod1=$Mod2

fi
PrevMod=$MOD
done

## Remove Module tag
cat $CWD/output/AllModules | grep -v 999 > $CWD/output/AllModules_tmp
mv $CWD/output/AllModules_tmp $CWD/output/AllModules


## sed '$!N;s/\n/,/' -- JOin Odd and even lines

for MOD in $(cat $CWD/output/AllModules); do
echo
 cat ${OUTPUT}_Module_${MOD} \
    | grep -E "Test|Error code"  \
        | grep -v "Test results" \
        | sed '$!N;s/\n/,/' \
        | awk '{print $1,$2,$NF}' \
        > ${OUTPUT}_Module_${MOD}_tmp


 cat ${OUTPUT}_Module_${MOD}_tmp | grep DIAG_FAILED > ${OUTPUT}_Module_${MOD}_Failed

 if [[ -s ${OUTPUT}_Module_${MOD}_Failed ]] ; then
     echo "     > [ERROR]: Module $MOD" | tee -a $LOGFILE $REPORTFILE
     cat ${OUTPUT}_Module_${MOD}_Failed | sed -e 's/^/     /' | tee -a $LOGFILE $REPORTFILE
     FLAG=y
 fi
done

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
   else
   echo -e "     > Status ----- Err" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
fi
FLAG=n

#--------------------------------------------------------------------


#=============================================
## Process, Its ID and % of utilization.
## "A: Look analyze first line of output for utilization.
## If five seconds, one minute, or five minutes is >80% that is fail.
## B: Look at each row indicating a process,
## look at the column for 5sec 1min 5min.
## If any of these are >50% that is fail."      "Report if A Fails
#=============================================

#set -x

echo -e "\n  g. Check Process ID and utilization..............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_proc_cpu_sort
export COMMAND="show proc cpu sort | exclude 0.00"

Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE

## Remove blank lines
sed -i '/^$/d' $OUTPUT

echo

## Some Nexus output has the line 'CPU utilization' while others dont

LINE=$(cat $OUTPUT | grep 'CPU utilization')
echo $LINE

if [ "$LINE" != "" ]; then

 #CPU utilization for five seconds: 14%/0%; one minute: 21%; five minutes: 22%
 #CPU util  :   5.1% user,   5.1% kernel,   89.8% idle

 CPU_5Sec=$(echo $LINE | awk -F';' '{print $1}' | awk '{print $NF}' | sed 's/%.*//g')
 CPU_1Min=$(echo $LINE | awk -F';' '{print $2}' | awk '{print $NF}' | sed 's/%.*//g')
 CPU_5Min=$(echo $LINE | awk -F';' '{print $3}' | awk '{print $NF}' | sed 's/%.*//g')

 if (( $(echo "${CPU_5Sec} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: CPU Utilization for 5 Seconds shows ABOVE 50% -- ${CPU_5Sec}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
 fi
 if (( $(echo "${CPU_1Min} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: CPU Utilization for 1 Minute shows ABOVE 50% -- ${CPU_1Min}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
 fi
 if (( $(echo "${CPU_5Min} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: CPU Utilization for 5 Minutes shows ABOVE 50%  -- ${CPU_5Min}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
 fi

else
   LINE=$(cat $OUTPUT | grep 'CPU util')
   USERCPU=$(echo $LINE | awk -F',' '{print $1}' | awk '{print $(NF-1)}'| sed 's/%.*//g')
   KERNELCPU=$(echo $LINE | awk -F',' '{print $2}' | awk '{print $(NF-1)}'| sed 's/%.*//g')

 if (( $(echo "${USERCPU} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: User CPU Utilization shows ABOVE 50% -- ${USERCPU}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
 fi
 if (( $(echo "${KERNELCPU} > 50" | bc -l) ));then
   echo -e "     > [ERROR]: Kernel CPU Utilization shows ABOVE 50% -- ${KERNELCPU}%" | tee -a $LOGFILE $REPORTFILE
   FLAG=y
 fi

#   echo "     > [ERROR]: Output does not have 'CPU utilization' data" | tee -a $LOGFILE $REPORTFILE

fi

#echo "Press any key";read

## Check individual processes for high CPU

## awk  -v OFS=, '{$5="XXX"; print }' -- Replace 5th column with XXX
#cat $OUTPUT | grep -E -v "CPU utilization|PID" | awk  -v OFS=, '{$8="XXX"; print }' > ${OUTPUT}_tmp
#cat $OUTPUT | grep -E -v "CPU util|PID|---|Please" | awk  -v OFS=, '{$5="XXX"; print }' > ${OUTPUT}_tmp
cat $OUTPUT | grep -E -v "CPU util|PID|---|Please" | sed -e's/^ *//g' | sed 's/ \{1,\}/,/g' > ${OUTPUT}_tmp

F=n
for LINE in $(cat ${OUTPUT}_tmp); do
    CPU_1Sec=$(echo $LINE | awk -F',' '{print $5}' | sed 's/%.*//g')
        PROC=$(echo $LINE | awk -F',' '{print $NF}' | sed 's/^,//g' | sed 's/,/ /g')

#echo PROC=$PROC
if (( $(echo "${CPU_1Sec} > 80" | bc -l) ));then
       echo -e "[ERROR]: $PROC for 1 Seconds shows ABOVE 80% -- ${CPU_1Sec}%"
           F=y
           FLAG=y
    fi
done
if [ "$F" = "y" ];then
     cat $OUTPUT | head -12 | tee -a $LOGFILE
fi

if [ "$FLAG" = "n" ]; then
   echo -e "     > Status ----- OK" | tee -a $LOGFILE $REPORTFILE
   else
   OverallStatus="Error"
fi
FLAG=n

#echo "Press any key";read
#=============================================
## Memory, Its ID and % of utilization.
## A: Processor Pool analyze % used. If greater than 80% = fail
## B: I/O Pool analyze % used. If greater than 80% = fail"      "Report if A Fails
## Report top 10 (if applicable) processes"
#=============================================


echo -e "\n  h. Check System resources..............................." | tee -a $LOGFILE $REPORTFILE

export OUTPUT=$CWD/output/$NEID-show_system_resources
export COMMAND="show system resources"
Run_ssh_Command

cat $OUTPUT | tee -a $LOGFILE

Load_Avg_1_min=$(cat $OUTPUT | grep 'Load average' | awk '{print $5}')
Load_Avg_5_min=$(cat $OUTPUT | grep 'Load average' | awk '{print $8}')
Load_Avg_15_min=$(cat $OUTPUT | grep 'Load average' | awk '{print $NF}')
# Set the Load Average Max = # of CPUs - 1
Load_Max=$(echo "$(cat $OUTPUT | grep -c CPU) -2" | bc)

FLAG=n
if (( $(echo "$Load_Avg_1_min > ${Load_Max}" | bc -l) ));then
    echo -e "     > [ERROR]: System Load average for 1 minute shows GREATER than ${Load_Max} -- ${Load_Avg_1_min}" | tee -a $LOGFILE $REPORTFILE
    FLAG=y
fi
if (( $(echo "$Load_Avg_5_min > ${Load_Max}" | bc -l) ));then
    echo -e "     > [ERROR]: System Load average for 5 minutes shows GREATER than ${Load_Max} -- ${Load_Avg_5_min}" | tee -a $LOGFILE $REPORTFILE
    FLAG=y
fi
if (( $(echo "$Load_Avg_15_min > ${Load_Max}" | bc -l) ));then
    echo -e "     > [ERROR]: System Load average for 15 minutes shows GREATER than ${Load_Max} -- ${Load_Avg_15_min}" | tee -a $LOGFILE $REPORTFILE
    FLAG=y
fi

if [ "$FLAG" = "n" ]; then
    echo -e "     > System Load Average....All [OK]" | tee -a $LOGFILE $REPORTFILE
else
   OverallStatus="Error"
fi

## Verify Avg CPU idle %age > 80%

CPU_states_idle=$(cat $OUTPUT | grep 'CPU states' | awk -F',' '{print $NF}' | awk '{print $1}' | sed 's/%.*//g')

if (( $(echo "${CPU_states_idle} < 80" | bc -l) ));then
   echo -e "     > [ERROR]: CPU states idle time shows BELOW 80% -- ${CPU_states_idle}%" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
else
   echo -e "     > Average CPU states idle time... All [OK]" | tee -a $LOGFILE $REPORTFILE
fi

## Verify idle time for individual CPU greater than 80%

#echo -e "\n" | tee -a $LOGFILE $REPORTFILE
for i in {0..20}; do
 CPU_idle=$(cat $OUTPUT | grep CPU$i | awk -F',' '{print $NF}' | awk '{print $1}' | sed 's/%.*//g')
  if [ "$CPU_idle" = "" ]; then
      break
  else
     if (( $(echo "${CPU_idle} < 80" | bc -l) ));then
       echo -e "     > [ERROR]: CPU$i idle states  shows BELOW 80% -- ${CPU_idle}%" | tee -a $LOGFILE $REPORTFILE
       OverallStatus="Error"
     else
        echo -e "     > CPU$i idle states..... [OK]" | tee -a $LOGFILE $REPORTFILE
    fi
  fi
done

#echo -e "\n" | tee -a $LOGFILE $REPORTFILE

MEM_STAT=$(cat $OUTPUT | grep 'Current memory' | awk '{print $NF}')
if [ "$MEM_STAT" != "OK" ]; then
   echo -e "     > [ERROR]: Check current memory status" | tee -a $LOGFILE $REPORTFILE
   OverallStatus="Error"
else
   echo -e "     > Current memory status: All[OK]" | tee -a $LOGFILE $REPORTFILE
fi

echo "
Overall Status :${OverallStatus}

=============================== End of Report ======================
" >> $REPORTFILE


echo -e "\n End of the script \n" | tee -a $LOGFILE
#EOF