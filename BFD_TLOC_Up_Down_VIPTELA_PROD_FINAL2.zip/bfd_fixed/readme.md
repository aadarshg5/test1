# BFD TLOC Up/Down Viptela

## Overview
Automated triage playbook for BFD TLOC Up/Down alarms on Cisco SD-WAN (Viptela) devices.
Triggered by ETMS via vCAT when Assure1 raises a BFDTLOCUpDown incident.

## Supported Devices
- Cisco vEdge (native Viptela OS)
- Cisco cEdge (IOS-XE with SD-WAN)

## Group / Request Type
- Group: ETMS_Triage
- Request Type: BFDTLOCUpDown
- Playbook Name: BFDTLOCUpDown-Cisco-Router

## Credentials Required
- TACACS (device SSH) — injected by vCAT via encrypted inventory at runtime
- vManage login — injected as extra vars (vmanage_user / vmanage_password)
- Assure1 login — injected as extra vars (assure1_user / assure1_password) from CINFO

## vCAT Integration Flow
1. ETMS ticket arrives, engineer adds `vcats=triage` comment
2. vCAT service account triggers automation workflow
3. vCAT decrypts JSON inventory via `decryptinv` command
4. Inventory contains `Problem Summary` (all alarm fields), `MgmtIP`, `DNSEntityName`,
   `entityHostName`, `vcatsAuthToken`, `request` block
5. vCAT calls `site.yml` with this inventory and runtime extra vars
6. All device names, IPs, alarm IDs — extracted dynamically from inventory at runtime
7. Nothing is hardcoded in the playbook

## What This Playbook Does
1. Parses `Problem Summary` to extract TLOC color and Assure1 Alarm ID at runtime
2. Detects device platform (vEdge vs cEdge) from `show version` output
3. Cross-references ETMS for existing Control TLOC Down ticket
4. Runs full BFD diagnostic suite
5. Validates control plane, interface state, redundant router if applicable
6. Analyzes peer path for single or all-peers-down scenarios
7. Clears vManage alarm via POST /dataservice/alarms/clear with UUID
8. Queries Assure1 to verify alarm cleared (device clear auto-propagates to Assure1)
9. Checks ETMS impact alarm all-clear status
10. Writes `ava-TRIAGE-DeviceUpDown` to output.dat only when ALL 3 conditions pass:
    - BFD stable >= 40 minutes
    - vManage BFD alarm cleared
    - Assure1 alert cleared

## vManage Alarm Clear
- Endpoint: POST /dataservice/alarms/clear (per Cisco SD-WAN vManage SOP)
- UUID queried from /dataservice/alarms filtered by device hostname and BFD rule
- Auth: Cookie (JSESSIONID) + X-XSRF-TOKEN (from /j_security_check + /dataservice/client/token)
- Success: HTTP 200 or 204

## Assure1 Alert Validation
- Endpoint: GET {assure1_base_url}/api/event/events/{assure1_alarm_id}
- assure1_base_url injected by vCAT at runtime — not hardcoded
- assure1_alarm_id extracted from Problem Summary field at runtime
- Auth: Basic base64(assure1_user:assure1_password) — from CINFO, injected by vCAT
- Dual-pattern cleared check (fallback covers different Assure1 response formats):
  - Pattern A: HTTP 404, or success=false, or data array empty
  - Pattern B: Severity == 'Normal' on matching event
- DO NOT actively clear Assure1 — device alarm clear auto-propagates within seconds

## Possible Outcomes
- **CLOSED**: BFD stable, all alarms cleared — `ava-TRIAGE-DeviceUpDown` written
- **ESCALATION TIER-2**: BFD flapping, tunnel issues, OMP down, persisting BFD down
- **FIELD ENGINEER**: Interface down after bounce
- **DEFERRED**: Existing Control TLOC Down ticket found

## Extra Vars (injected by vCAT at runtime — never hardcode)
- `vmanage_host`: vManage IP/hostname
- `vmanage_user`: vManage username
- `vmanage_password`: vManage password
- `assure1_base_url`: Assure1 base URL
- `assure1_user`: Assure1 username (from CINFO)
- `assure1_password`: Assure1 password (from CINFO)
- `etms_base_url`: ETMS REST base URL (default: https://etms.verizon.com)

## Output File
- `output.dat` written to `VCATS_INV_WS/output.dat` — read by vCAT after execution
