"""Jinja2 filter plugin for BFD TLOC Up/Down Viptela automation package."""

from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Any


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

def detect_platform(show_version_output: str) -> str:
    """Return 'vedge', 'ios_xe', or 'unknown' from show version output."""
    out = show_version_output or ""
    if re.search(r"IOS[ -]XE", out, re.IGNORECASE):
        return "ios_xe"
    if re.search(r"vEdge|vedge|SD-WAN|viptela", out, re.IGNORECASE):
        return "vedge"
    if re.match(r"^\d+\.\d+[\d\.]*\s*$", out.strip()):
        return "vedge"
    return "unknown"


# ---------------------------------------------------------------------------
# Problem Summary / alarm text parsing
# ---------------------------------------------------------------------------

def extract_text_field(problem_summary: str) -> str:
    """Extract the TEXT: value from the full ETMS Problem Summary string."""
    m = re.search(r"TEXT:\s*(.+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_tloc_color(text_field: str) -> str:
    """Extract TLOC color from the TEXT field using 'down- <color>' pattern."""
    m = re.search(r"down-\s+(\S+)", text_field or "")
    return m.group(1).strip() if m else ""


def extract_assure1_alarm_id(problem_summary: str) -> str:
    """Extract ASSURE1 ALARM ID from Problem Summary string."""
    m = re.search(r"ASSURE1 ALARM ID:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_hostname_from_summary(problem_summary: str) -> str:
    """Extract HOSTNAME field from Problem Summary string."""
    m = re.search(r"HOSTNAME:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_neid_from_summary(problem_summary: str) -> str:
    """Extract NEID field from Problem Summary string."""
    m = re.search(r"NEID:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_ip_from_summary(problem_summary: str) -> str:
    """Extract IP ADDRESS field from Problem Summary string."""
    m = re.search(r"IP ADDRESS:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


# ---------------------------------------------------------------------------
# BFD session parsing
# ---------------------------------------------------------------------------

def parse_bfd_sessions_vedge(output: str, tloc_color: str) -> list[dict]:
    """Parse vEdge 'show bfd sessions local-color <color>' into list of dicts."""
    sessions: list[dict] = []
    for line in (output or "").splitlines():
        line = line.strip()
        if not line or line.startswith("-") or re.match(r"^System\s+IP", line, re.IGNORECASE):
            continue
        parts = line.split()
        if len(parts) < 6:
            continue
        color_col = parts[3] if len(parts) > 3 else ""
        if tloc_color and tloc_color not in color_col:
            continue
        sessions.append({
            "system_ip": parts[0],
            "site_id": parts[1],
            "state": parts[2].lower(),
            "src_color": color_col,
            "uptime": parts[4] if len(parts) > 4 else "",
            "transitions": parts[5] if len(parts) > 5 else "0",
        })
    return sessions


def parse_bfd_sessions_cedge(output: str, tloc_color: str) -> list[dict]:
    """Parse cEdge 'show sdwan bfd sessions | include <color>' into list of dicts."""
    sessions: list[dict] = []
    for line in (output or "").splitlines():
        line = line.strip()
        if not line or line.startswith("-") or re.match(r"^SYSTEM\s+IP", line, re.IGNORECASE):
            continue
        parts = line.split()
        if len(parts) < 6:
            continue
        color_col = parts[3] if len(parts) > 3 else ""
        if tloc_color and tloc_color not in color_col:
            continue
        sessions.append({
            "system_ip": parts[0],
            "site_id": parts[1],
            "state": parts[2].lower(),
            "src_color": color_col,
            "uptime": parts[4] if len(parts) > 4 else "",
            "transitions": parts[5] if len(parts) > 5 else "0",
        })
    return sessions


def all_bfd_sessions_up(sessions: list[dict]) -> bool:
    """Return True if every session state is 'up'."""
    if not sessions:
        return False
    return all(s.get("state", "").lower() == "up" for s in sessions)


def any_bfd_session_down(sessions: list[dict]) -> bool:
    """Return True if any session state is not 'up'."""
    return any(s.get("state", "").lower() != "up" for s in sessions)


# ---------------------------------------------------------------------------
# Uptime parsing
# ---------------------------------------------------------------------------

def parse_uptime_seconds(uptime_str: str) -> int:
    """Convert uptime string ('0:18:01', '1h30m', '2d3h') to integer seconds."""
    s = (uptime_str or "").strip()

    m = re.match(r"^(?:(\d+):)?(\d+):(\d+):(\d+)$", s)
    if m:
        days = int(m.group(1) or 0)
        return days * 86400 + int(m.group(2)) * 3600 + int(m.group(3)) * 60 + int(m.group(4))

    m = re.match(r"^(\d+):(\d+):(\d+)$", s)
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))

    total = 0
    for unit, multiplier in [("d", 86400), ("h", 3600), ("m", 60), ("s", 1)]:
        m2 = re.search(rf"(\d+){unit}", s)
        if m2:
            total += int(m2.group(1)) * multiplier
    return total


def bfd_uptime_above_threshold(sessions: list[dict], threshold_minutes: int) -> bool:
    """Return True if all sessions have uptime above threshold_minutes."""
    threshold_secs = int(threshold_minutes) * 60
    for s in (sessions or []):
        if parse_uptime_seconds(s.get("uptime", "0")) < threshold_secs:
            return False
    return True


# ---------------------------------------------------------------------------
# BFD log parsing and stability evaluation
# ---------------------------------------------------------------------------

def parse_bfd_logs(output: str, lookback_minutes: int = 60) -> list[dict]:
    """Parse BFD/tloc log output into timestamped event list within lookback window."""
    events: list[dict] = []
    now = datetime.utcnow()
    cutoff = now - timedelta(minutes=int(lookback_minutes))

    for line in (output or "").splitlines():
        line_s = line.strip()
        if not line_s:
            continue
        m = re.search(
            r"(\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2}|\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2})",
            line_s,
        )
        event_time = None
        if m:
            ts_str = m.group(1)
            for fmt in ("%b %d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
                try:
                    parsed = datetime.strptime(ts_str, fmt)
                    if parsed.year == 1900:
                        parsed = parsed.replace(year=now.year)
                    event_time = parsed
                    break
                except ValueError:
                    continue

        is_flap = bool(re.search(r"down|flap|transition|reset|timeout", line_s, re.IGNORECASE))
        in_window = (event_time is None) or (event_time >= cutoff)

        if in_window:
            events.append({
                "timestamp": event_time.isoformat() if event_time else "unknown",
                "is_flap": is_flap,
                "raw": line_s,
            })
    return events


def is_bfd_stable(logs: list[dict]) -> bool:
    """Return True if no flap events found in the parsed log window."""
    return not any(e.get("is_flap", False) for e in (logs or []))


def classify_bfd_stability(sessions: list[dict], logs: list[dict], threshold_minutes: int = 40) -> str:
    """Return 'stable', 'flapping', or 'recently_recovered' based on sessions and logs."""
    if not all_bfd_sessions_up(sessions):
        return "down"
    if not is_bfd_stable(logs):
        return "flapping"
    if not bfd_uptime_above_threshold(sessions, threshold_minutes):
        return "recently_recovered"
    return "stable"


# ---------------------------------------------------------------------------
# BFD history parsing
# ---------------------------------------------------------------------------

def parse_bfd_history(output: str, tloc_color: str) -> list[dict]:
    """Parse BFD history output filtered to tloc_color."""
    entries: list[dict] = []
    for line in (output or "").splitlines():
        if tloc_color and tloc_color not in line:
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        entries.append({
            "system_ip": parts[0],
            "site_id": parts[1] if len(parts) > 1 else "",
            "color": parts[2] if len(parts) > 2 else "",
            "state": parts[3].lower() if len(parts) > 3 else "",
            "raw": line,
        })
    return entries


# ---------------------------------------------------------------------------
# Control connections
# ---------------------------------------------------------------------------

def parse_control_connections(output: str) -> list[dict]:
    """Parse show control connections output into list of dicts."""
    connections: list[dict] = []
    for line in (output or "").splitlines():
        line_s = line.strip()
        if not line_s or line_s.startswith("-") or re.match(r"^PEER|^Peer", line_s):
            continue
        parts = line_s.split()
        if len(parts) < 3:
            continue
        connections.append({
            "peer_ip": parts[0],
            "type": parts[1] if len(parts) > 1 else "",
            "state": parts[2].lower() if len(parts) > 2 else "",
            "raw": line_s,
        })
    return connections


def control_tloc_up(connections: list[dict]) -> bool:
    """Return True if any control connection state is 'up'."""
    return any(c.get("state", "").lower() == "up" for c in (connections or []))


# ---------------------------------------------------------------------------
# Local properties (TLOC termination)
# ---------------------------------------------------------------------------

def parse_local_properties(output: str) -> dict:
    """Parse show control local-properties output for public/private IPs."""
    result: dict = {"public_ip": "", "private_ip": ""}
    for line in (output or "").splitlines():
        m = re.search(r"public-ip\s*[:\s]+(\d+\.\d+\.\d+\.\d+)", line, re.IGNORECASE)
        if m:
            result["public_ip"] = m.group(1)
        m2 = re.search(r"private-ip\s*[:\s]+(\d+\.\d+\.\d+\.\d+)", line, re.IGNORECASE)
        if m2:
            result["private_ip"] = m2.group(1)
    return result


def tloc_terminated_locally(local_properties: dict) -> bool:
    """Return True if public_ip == private_ip (TLOC terminates on this device)."""
    pub = (local_properties or {}).get("public_ip", "")
    priv = (local_properties or {}).get("private_ip", "")
    return bool(pub and priv and pub == priv)


# ---------------------------------------------------------------------------
# OMP peers
# ---------------------------------------------------------------------------

def parse_omp_peers(output: str) -> list[dict]:
    """Parse show omp peers output into list of dicts."""
    peers: list[dict] = []
    for line in (output or "").splitlines():
        line_s = line.strip()
        if not line_s or line_s.startswith("-") or re.match(r"^PEER|^Peer", line_s):
            continue
        parts = line_s.split()
        if len(parts) < 3:
            continue
        peers.append({
            "peer": parts[0],
            "type": parts[1] if len(parts) > 1 else "",
            "state": parts[2].lower() if len(parts) > 2 else "",
            "raw": line_s,
        })
    return peers


def omp_sessions_up(peers: list[dict]) -> bool:
    """Return True if any OMP peer state is 'up'."""
    return any(p.get("state", "").lower() == "up" for p in (peers or []))


# ---------------------------------------------------------------------------
# Interface status
# ---------------------------------------------------------------------------

def parse_interface_status(output: str, interface_name: str) -> str:
    """Return 'up', 'down', 'admin-down', or 'unknown' for a named interface."""
    pattern = re.escape(interface_name)
    for line in (output or "").splitlines():
        if re.search(pattern, line, re.IGNORECASE):
            l = line.lower()
            if "admin" in l and "down" in l:
                return "admin-down"
            if "down" in l:
                return "down"
            if "up" in l:
                return "up"
    return "unknown"


# ---------------------------------------------------------------------------
# Template status
# ---------------------------------------------------------------------------

def parse_template_status(output: str) -> bool:
    """Return True if device is template-managed (attached/true/enabled)."""
    for line in (output or "").splitlines():
        l = line.lower()
        if re.search(r"template.*(attached|true|enabled)", l) or \
           re.search(r"(attached|true|enabled).*template", l):
            return True
    return False


# ---------------------------------------------------------------------------
# IPsec tunnels
# ---------------------------------------------------------------------------

def parse_ipsec_tunnels(output: str, tloc_color: str) -> list[dict]:
    """Parse IPsec tunnel output filtered to tloc_color."""
    tunnels: list[dict] = []
    for line in (output or "").splitlines():
        if tloc_color and tloc_color not in line:
            continue
        line_s = line.strip()
        if not line_s:
            continue
        parts = line_s.split()
        tunnels.append({
            "raw": line_s,
            "peer": parts[0] if parts else "",
        })
    return tunnels


# ---------------------------------------------------------------------------
# VRRP parsing + peer IP derivation
# ---------------------------------------------------------------------------

def parse_vrrp_output(output: str) -> dict:
    """Parse show vrrp output for vrrp_state, primary_ip, virtual_ip."""
    result: dict = {"vrrp_state": "unknown", "primary_ip": "", "virtual_ip": ""}
    for line in (output or "").splitlines():
        l = line.lower()
        if "master" in l or "active" in l:
            result["vrrp_state"] = "master"
        elif "backup" in l or "standby" in l:
            result["vrrp_state"] = "backup"
        m = re.search(r"virtual\s+ip[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", line, re.IGNORECASE)
        if m:
            result["virtual_ip"] = m.group(1)
        m2 = re.search(r"local\s+ip[^:]*:\s*(\d+\.\d+\.\d+\.\d+)", line, re.IGNORECASE)
        if m2:
            result["primary_ip"] = m2.group(1)
    return result


def derive_peer_ip(mgmt_ip: str) -> str:
    """Derive redundant router IP using odd/even last-octet rule."""
    parts = (mgmt_ip or "").split(".")
    if len(parts) != 4:
        return ""
    try:
        last = int(parts[3])
        peer_last = last + 1 if last % 2 != 0 else last - 1
        return ".".join(parts[:3] + [str(peer_last)])
    except ValueError:
        return ""


# ---------------------------------------------------------------------------
# Ping result
# ---------------------------------------------------------------------------

def parse_ping_result(output: str) -> bool:
    """Return True if ping indicates 0% packet loss or 100% success."""
    out = output or ""
    if re.search(r"\b0% packet loss", out) or "Success rate is 100" in out:
        return True
    return False


# ---------------------------------------------------------------------------
# BFD flapping detection
# ---------------------------------------------------------------------------

def detect_bfd_flapping(sessions: list[dict]) -> bool:
    """Return True if any session has transitions > 5."""
    for s in (sessions or []):
        try:
            if int(s.get("transitions", 0)) > 5:
                return True
        except (ValueError, TypeError):
            continue
    return False


# ---------------------------------------------------------------------------
# Alarm / alert state evaluation
# ---------------------------------------------------------------------------

def is_alarm_stuck(alarm_json: Any) -> bool:
    """Return True if vManage alarm is active/not cleared."""
    if not alarm_json:
        return False
    if isinstance(alarm_json, list):
        return len(alarm_json) > 0
    if isinstance(alarm_json, dict):
        active = alarm_json.get("active", True)
        cleared = alarm_json.get("cleared", False)
        return bool(active) and not bool(cleared)
    return False


def filter_vmanage_alarms(alarms_data: list[dict], hostname: str, alarm_name: str = "BFD") -> list[dict]:
    """Filter vManage alarm list to those matching hostname and alarm type."""
    matched: list[dict] = []
    for alarm in (alarms_data or []):
        values = alarm.get("values", [{}])
        if isinstance(values, list) and values:
            values = values[0]
        host = values.get("host-name", "")
        rule = alarm.get("rule_name_display", "")
        if hostname.lower() in host.lower() and alarm_name.lower() in rule.lower():
            matched.append({
                "uuid": alarm.get("uuid", ""),
                "host_name": host,
                "rule_name": rule,
                "active": alarm.get("active", True),
                "cleared": alarm.get("cleared", False),
                "raw": alarm,
            })
    return matched


def extract_alarm_uuids(filtered_alarms: list[dict]) -> list[str]:
    """Extract UUID list from filtered vManage alarms."""
    return [a["uuid"] for a in (filtered_alarms or []) if a.get("uuid")]


# ---------------------------------------------------------------------------
# Ansible filter map
# ---------------------------------------------------------------------------

class FilterModule:
    """Ansible filter plugin entry point."""

    def filters(self) -> dict:
        """Return filter function map."""
        return {
            "detect_platform": detect_platform,
            "extract_text_field": extract_text_field,
            "extract_tloc_color": extract_tloc_color,
            "extract_assure1_alarm_id": extract_assure1_alarm_id,
            "extract_hostname_from_summary": extract_hostname_from_summary,
            "extract_neid_from_summary": extract_neid_from_summary,
            "extract_ip_from_summary": extract_ip_from_summary,
            "parse_bfd_sessions_vedge": parse_bfd_sessions_vedge,
            "parse_bfd_sessions_cedge": parse_bfd_sessions_cedge,
            "all_bfd_sessions_up": all_bfd_sessions_up,
            "any_bfd_session_down": any_bfd_session_down,
            "parse_uptime_seconds": parse_uptime_seconds,
            "bfd_uptime_above_threshold": bfd_uptime_above_threshold,
            "parse_bfd_logs": parse_bfd_logs,
            "is_bfd_stable": is_bfd_stable,
            "classify_bfd_stability": classify_bfd_stability,
            "parse_bfd_history": parse_bfd_history,
            "parse_control_connections": parse_control_connections,
            "control_tloc_up": control_tloc_up,
            "parse_local_properties": parse_local_properties,
            "tloc_terminated_locally": tloc_terminated_locally,
            "parse_omp_peers": parse_omp_peers,
            "omp_sessions_up": omp_sessions_up,
            "parse_interface_status": parse_interface_status,
            "parse_template_status": parse_template_status,
            "parse_ipsec_tunnels": parse_ipsec_tunnels,
            "parse_vrrp_output": parse_vrrp_output,
            "derive_peer_ip": derive_peer_ip,
            "parse_ping_result": parse_ping_result,
            "detect_bfd_flapping": detect_bfd_flapping,
            "is_alarm_stuck": is_alarm_stuck,
            "filter_vmanage_alarms": filter_vmanage_alarms,
            "extract_alarm_uuids": extract_alarm_uuids,
        }
