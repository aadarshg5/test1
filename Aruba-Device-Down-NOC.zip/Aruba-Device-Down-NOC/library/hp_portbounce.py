#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule
import time
import re

try:
    from netmiko import ConnectHandler
    HAS_NETMIKO = True
except ImportError:
    HAS_NETMIKO = False

def run_module():
    module_args = dict(
        host=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        enable_pass=dict(type='str', required=True, no_log=True),
        interface=dict(type='str', required=True),
        device_type=dict(type='str', default='aruba_aoscx') # Use aruba_os for 2930F
    )

    result = dict(changed=False, message='', updates='')
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    if not HAS_NETMIKO:
        module.fail_json(msg='netmiko library is required. Install with: pip install netmiko')

    device = {
        'device_type': module.params['device_type'],
        'host': module.params['host'],
        'username': module.params['username'],
        'password': module.params['password'],
        'secret': module.params['enable_pass'],
        'global_delay_factor': 2,
        'fast_cli': False, # Critical for slow banners
    }

    interface = module.params['interface']
    config_commands = [
        f"interface {interface}",
        "shutdown",
        "no shutdown"
    ]

    try:
        net_connect = ConnectHandler(**device)
        
        # --- ARUBA 2930F BYPASS STRATEGY ---
        # 1. Wait and clear the "Press any key to continue" disclaimer
        time.sleep(2)
        net_connect.write_channel("\n\n\n")
        time.sleep(2)

        # 2. Prevent pagination
        net_connect.send_command_timing("terminal length 0")

        # 3. Elevate to Privileged EXEC (enable mode)
        if not net_connect.check_enable_mode():
            net_connect.enable()
        
        # 4. Perform the Port Bounce
        # send_config_set automatically enters 'config term' and exits 'end'
        output = net_connect.send_config_set(config_commands)
        
        net_connect.disconnect()

        result['changed'] = True
        result['message'] = f"Port {interface} bounced successfully."
        result['updates'] = output
        
        module.exit_json(**result)

    except Exception as e:
        module.fail_json(msg=f"Module Error: {str(e)}")

if __name__ == '__main__':
    run_module()