#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule
import time
import re
from netmiko import ConnectHandler, redispatch

def strip_ansi_codes(text):
    """Remove ANSI escape sequences (color codes, etc)."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def clean_output(output, command):
    """Remove echoed command and trailing prompt from device output."""
    output = strip_ansi_codes(output)
    lines = [line.strip() for line in output.splitlines() if line.strip()]
    cleaned = []
    for i, line in enumerate(lines):
        if i == 0 and command in line: continue
        if i == len(lines) - 1 and (line.endswith("#") or line.endswith(">")): continue
        cleaned.append(line)
    return "\n".join(cleaned), cleaned

def run_command(router_host, router_user, router_pass, switch_ip, switch_user, switch_pass, command):
    # Setup for the Jump Host (Aruba Router)
    router_device = {
        'device_type': 'aruba_os',
        'ip': router_host,
        'username': router_user,
        'password': router_pass,
        'secret': router_pass,
        'global_delay_factor': 3,
    }

    try:
        # Step 1: Connect to Aruba Router
        conn = ConnectHandler(**router_device)
        
        # Bypass Router's "Press any key"
        conn.write_channel("\n")
        time.sleep(2)
        conn.find_prompt()
        conn.enable()

        # Step 2: SSH Jump to Aruba Switch
        # Syntax: ssh <user>@<ip>
        ssh_cmd = f"ssh {switch_user}@{switch_ip}"
        conn.write_channel(ssh_cmd + "\n")
        time.sleep(2)
        
        # Send Switch Password
        conn.write_channel(switch_pass + "\n")
        time.sleep(2)

        # Step 3: Redispatch for the Switch session
        redispatch(conn, device_type='aruba_os')

        # Bypass Switch's "Press any key"
        conn.write_channel("\n")
        time.sleep(3)
        conn.find_prompt()
        conn.enable()
        
        # Step 4: Execute Command
        raw_output = conn.send_command(command, expect_string=r"#")
        
        # CRITICAL: Strip null characters to prevent Ansible Syslog crash
        raw_output = raw_output.replace('\x00', '')
        
        # Step 5: Clean Exit
        conn.write_channel("exit\n") # Return to Router
        time.sleep(1)
        conn.disconnect()
        
        cleaned_str, cleaned_lines = clean_output(raw_output, command)
        return cleaned_str, cleaned_lines, None

    except Exception as e:
        return None, None, str(e)

def main():
    module_args = dict(
        router_host=dict(type='str', required=True),
        router_user=dict(type='str', required=True),
        router_pass=dict(type='str', required=True, no_log=True),
        switch_ip=dict(type='str', required=True),
        switch_user=dict(type='str', required=True),
        switch_pass=dict(type='str', required=True, no_log=True),
        command=dict(type='str', required=True)
    )

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)

    stdout, stdout_lines, error = run_command(
        module.params['router_host'],
        module.params['router_user'],
        module.params['router_pass'],
        module.params['switch_ip'],
        module.params['switch_user'],
        module.params['switch_pass'],
        module.params['command']
    )

    if error:
        module.fail_json(msg="Execution failed", error=error)

    module.exit_json(changed=False, stdout=stdout, stdout_lines=stdout_lines)

if __name__ == '__main__':
    main()