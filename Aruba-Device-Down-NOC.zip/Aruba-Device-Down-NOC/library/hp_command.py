#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule
import os
import json
import re
import time
from netmiko import ConnectHandler

def strip_ansi_codes(text):
    """Remove ANSI escape sequences (color codes, cursor moves, etc)."""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def clean_output(output, command):
    """Remove echoed command and trailing prompt from device output."""
    output = strip_ansi_codes(output)
    lines = [line.strip() for line in output.splitlines() if line.strip()]

    cleaned = []
    for i, line in enumerate(lines):
        if i == 0 and command in line:
            continue
        if i == len(lines) - 1 and (line.endswith("#") or line.endswith(">")):
            continue
        cleaned.append(line)

    return "\n".join(cleaned), cleaned

def load_first_aruba_device():
    """Run decryptinv and return first Aruba device's credentials."""
    stream = os.popen('/bin/sh -c decryptinv')
    raw_inventory = stream.read()
    inventory = json.loads(raw_inventory)
    hosts = inventory.get('all', {}).get('hosts', {})

    for hostname, host_info in hosts.items():
        mgmt_ip = host_info.get("MgmtIP")
        username = host_info.get("ansible_user")
        password = host_info.get("ansible_password")
        if mgmt_ip and username and password:
            return {
                'hostname': hostname,
                'ip': mgmt_ip,
                'username': username,
                'password': password
            }

    return None

def run_command(host, username, password, command):
    #device_info = load_first_aruba_device()
    #if not device_info:
    #    return None, None, "No valid Aruba device found in inventory"

    #device = {
    #    'device_type': 'aruba_os',
    #    'ip': device_info['ip'],
    #    'username': device_info['username'],
    #    'password': device_info['password'],
    #    'secret': device_info['password'],
    #}

    device = {
        'device_type': 'aruba_os',
        'ip': host,
        'username': username,
        'password': password,
        'secret': password,
        'global_delay_factor': 3,
    }

    try:
        conn = ConnectHandler(**device)
        
        conn.write_channel("\n")
        time.sleep(3)
        
        conn.find_prompt()
        
        conn.enable()
        raw_output = conn.send_command(command, expect_string=r"#")
        conn.disconnect()
        
        cleaned_str, cleaned_lines = clean_output(raw_output, command)
        return cleaned_str, cleaned_lines, None

    except Exception as e:
        return None, None, str(e)

def main():

    module_args = dict(
        host=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        command=dict(type='str', required=True)
    )

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)

    command = module.params['command']
    host = module.params['host']
    username = module.params['username']
    password = module.params['password']

    stdout, stdout_lines, error = run_command(host, username, password, command)

    if error:
        module.fail_json(msg="Command execution failed", stdout=error, stdout_lines=[error])

    module.exit_json(changed=False, stdout=stdout, stdout_lines=stdout_lines)

if __name__ == '__main__':
    main()