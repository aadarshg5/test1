#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from netmiko import ConnectHandler
import json
import re

def parse_key_value(lines):
    """Standard Key: Value parser for show version and show system."""
    data = {}
    for line in lines:
        if ":" in line:
            # Split only on the first colon to handle values like Build IDs
            parts = line.split(":", 1)
            key = parts[0].strip().lower().replace(" ", "_").replace("-", "_")
            value = parts[1].strip()
            data[key] = value
    return data

def parse_table(lines):
    """Positional slicing for show interface brief and statistics."""
    rows = []
    sep_idx = -1
    # Find the dashed line separator
    for i, line in enumerate(lines):
        if line.startswith("---"):
            sep_idx = i
            break
    if sep_idx == -1: return []

    # Map headers for Interface Brief
    headers = ["port", "native_vlan", "mode", "type", "enabled", "status", "reason", "speed"]

    for line in lines[sep_idx + 1:]:
        # Skip noise and headers
        if any(x in line for x in ["---", "Port", "VLAN", "(Mb/s)"]) or len(line) < 10:
            continue
        
        # Positional slicing ensures data doesn't shift if a column is empty
        row_values = [
            line[0:10].strip(), line[10:18].strip(), line[18:25].strip(),
            line[25:40].strip(), line[40:48].strip(), line[48:56].strip(),
            line[56:79].strip(), line[79:].strip()
        ]
        rows.append(dict(zip(headers, row_values)))
    return rows

def parse_smart(raw_text, cmd):
    """Chooses parser based on the command content."""
    lines = [l.strip('\r') for l in raw_text.splitlines() if l.strip()]
    if not lines: return {}

    cmd_l = cmd.lower()
    
    # Logs are returned as a raw list
    if "logging" in cmd_l:
        return {"logs": lines}
    
    # Use table parser ONLY for tabular commands to avoid breaking show version
    if any(x in cmd_l for x in ["brief", "statistics", "utilization"]):
        return parse_table(lines)
    
    # Default for show version, show system, etc.
    return parse_key_value(lines)

def run_module():
    module_args = dict(
        host=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        commands=dict(type='list', required=True)
    )

    result = dict(changed=False, command_data={})
    module = AnsibleModule(argument_spec=module_args)

    device = {
        'device_type': 'aruba_aoscx',
        'host': module.params['host'],
        'username': module.params['username'],
        'password': module.params['password'],
        'global_delay_factor': 2,
    }

    try:
        with ConnectHandler(**device) as net_connect:
            net_connect.find_prompt()
            # Prevent --More-- prompts
            net_connect.send_command_timing("terminal length 0")
            
            for cmd in module.params['commands']:
                if not cmd.strip(): continue
                
                # Use timing-based delivery for SSH stability
                raw_output = net_connect.send_command_timing(
                    cmd.strip(),
                    delay_factor=2.0 
                )
                
                clean_key = cmd.strip().lower().replace(" ", "_").replace("-", "_")
                result['command_data'][clean_key] = parse_smart(raw_output, cmd)
        
        module.exit_json(**result)
    except Exception as e:
        module.fail_json(msg="SSH/Parsing Error: " + str(e), command_data={})

if __name__ == '__main__':
    run_module()
