#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from netmiko import ConnectHandler
import time

def run_module():
    module_args = dict(
        jump_host=dict(type='str', required=True),
        jump_host_user=dict(type='str', required=True),
        jump_host_pass=dict(type='str', required=True, no_log=True),
        ceRouter_host=dict(type='str', required=True),
        ceRouter_user=dict(type='str', required=True),
        ceRouter_pass=dict(type='str', required=True, no_log=True),
        commands=dict(type='list', required=True)
    )

    # We use a dictionary for results to make formatting easier later
    result = dict(changed=False, results_dict={}, failed=False)
    module = AnsibleModule(argument_spec=module_args)

    d1_params = {
        'device_type': 'cisco_ios',
        'host': module.params['jump_host'],
        'username': module.params['jump_host_user'],
        'password': module.params['jump_host_pass'],
    }

    try:
        net_connect = ConnectHandler(**d1_params)
        ssh_cmd = f"ssh -l {module.params['ceRouter_user']} {module.params['ceRouter_host']}"
        net_connect.write_channel(ssh_cmd + "\n")
        time.sleep(3)

        output = net_connect.read_channel()
        if 'yes/no' in output.lower():
            net_connect.write_channel("yes\n")
            time.sleep(2)

        if 'password' in output.lower():
            net_connect.write_channel(module.params['ceRouter_pass'] + "\n")
            time.sleep(3)

        # Execute and capture into the dictionary
        final_outputs = {}
        for cmd in module.params['commands']:
            cmd_output = net_connect.send_command_timing(cmd)
            final_outputs[cmd] = cmd_output.strip()

        result['results_dict'] = final_outputs
        result['changed'] = True

        net_connect.disconnect()
        module.exit_json(**result)

    except Exception as e:
        module.fail_json(msg=str(e), **result)

if __name__ == '__main__':
    run_module()