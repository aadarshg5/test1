#!/usr/bin/python
from ansible.module_utils.basic import AnsibleModule
from netmiko import ConnectHandler
import time

def run_module():
    # Define the inputs (arguments) Ansible will pass to the script
    module_args = dict(
        router_host=dict(type='str', required=True),
        router_user=dict(type='str', required=True),
        router_pass=dict(type='str', required=True, no_log=True),
        router_secret=dict(type='str', required=True, no_log=True),
        switch_ip=dict(type='str', required=True),
        switch_user=dict(type='str', required=True),
        switch_pass=dict(type='str', required=True, no_log=True),
        command=dict(type='str', default='show version')
    )

    result = dict(
        changed=False,
        output=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Netmiko Logic
    try:
        router_details = {
            'device_type': 'cisco_ios',
            'host': module.params['router_host'],
            'username': module.params['router_user'],
            'password': module.params['router_pass'],
            'secret': module.params['router_secret'],
        }

        net_connect = ConnectHandler(**router_details)
        net_connect.enable()

        # Jump Logic
        ssh_cmd = f"ssh -l {module.params['switch_user']} {module.params['switch_ip']}"
        net_connect.write_channel(ssh_cmd + "\n")
        time.sleep(2)

        output = net_connect.read_channel()

        # Handle Fingerprint
        if "yes/no" in output.lower():
            net_connect.write_channel("yes\n")
            time.sleep(1)
            output = net_connect.read_channel()

        # Handle Password
        if "password" in output.lower():
            net_connect.write_channel(module.params['switch_pass'] + "\n")
            time.sleep(3)
            output = net_connect.read_channel()

        # Verify login and run command
        if "#" in output or ">" in output:
            net_connect.send_command("terminal length 0", expect_string=r"[#>]")
            final_output = net_connect.send_command(
                module.params['command'],
                expect_string=r"[#>]",
                read_timeout=120
            )

            result['output'] = final_output
            result['changed'] = True
        else:
            module.fail_json(msg="Failed to reach switch prompt", last_output=output)

        net_connect.write_channel("exit\n")
        net_connect.disconnect()

        module.exit_json(**result)

    except Exception as e:
        module.fail_json(msg=f"Logic failure: {str(e)}")

if __name__ == '__main__':
    run_module()