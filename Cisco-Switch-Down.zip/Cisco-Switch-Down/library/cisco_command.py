
#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
import os

# Ensure Netmiko is installed
try:
    from netmiko import ConnectHandler
    from netmiko.exceptions import NetmikoTimeoutException, NetmikoAuthenticationException
    HAS_NETMIKO = True
except ImportError:
    HAS_NETMIKO = False

def run_module():
    # Define the arguments expected from Ansible
    module_args = dict(
        host=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        command=dict(type='str', required=True)
    )

    result = dict(
        changed=False,
        stdout='',
        detected_type='',
        msg=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if not HAS_NETMIKO:
        module.fail_json(msg='netmiko is required for this module. Please install it via: pip install netmiko')

    # Logic to handle different device types
    # cisco_ios handles IOS-XE, cEdge, and standard switches
    # cisco_viptela handles vEdge (Viptela OS)
    target_types = ['cisco_ios', 'cisco_viptela']
    success = False
    error_summary = []

    for d_type in target_types:
        try:
            device_params = {
                'device_type': d_type,
                'host': module.params['host'],
                'username': module.params['username'],
                'password': module.params['password'],
                'timeout': 15,
                'global_delay_factor': 2,
                # session_log is useful for debugging SSH prompts if needed
                # 'session_log': 'netmiko_session.log',
            }

            # Netmiko automatically handles the "Are you sure you want to continue (yes/no)?" 
            # SSH host key prompt if ssh_config is handled or via Paramiko's default behavior.
            with ConnectHandler(**device_params) as net_connect:
                output = net_connect.send_command(module.params['command'])
                
                result['stdout'] = output
                result['detected_type'] = d_type
                result['changed'] = True
                success = True
                break  # Exit loop on success

        except (NetmikoTimeoutException, NetmikoAuthenticationException) as e:
            error_summary.append(f"{d_type}: {str(e)}")
            continue
        except Exception as e:
            error_summary.append(f"{d_type}: Unknown error: {str(e)}")
            continue

    if not success:
        module.fail_json(msg=f"All login attempts failed. Errors: {'; '.join(error_summary)}")

    module.exit_json(**result)

if __name__ == '__main__':
    run_module()