#!/usr/bin/python
from ansible.module_utils.basic import AnsibleModule

def run_module():
    module_args = dict(
        host=dict(type='str', required=True),
        username=dict(type='str', required=True),
        password=dict(type='str', required=True, no_log=True),
        command=dict(type='str', required=True)
    )

    module = AnsibleModule(argument_spec=module_args)

    user = module.params['username']
    host = module.params['host']
    pw = module.params['password']
    cmd = module.params['command']

    # We use 'expect' to handle the keyboard-interactive prompt
    # which standard SSH/sshpass cannot do on hardened Viptela devices.
    expect_script = (
        'spawn ssh -o StrictHostKeyChecking=no {user}@{host} "{cmd}"; '
        'expect "Password:"; '
        'send "{password}\\r"; '
        'expect eof;'
    ).format(user=user, host=host, cmd=cmd, password=pw)

    # Wrap the expect script into a shell call
    full_cmd = ["expect", "-c", expect_script]

    rc, stdout, stderr = module.run_command(full_cmd)

    if rc != 0:
        module.fail_json(msg="Authentication or Command failed", stdout=stdout, stderr=stderr)

    module.exit_json(changed=True, stdout=stdout)

if __name__ == '__main__':
    run_module()