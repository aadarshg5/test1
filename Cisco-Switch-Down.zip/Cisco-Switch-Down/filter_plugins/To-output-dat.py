#!/usr/bin/python

# Description: Ansible custom filter plugin which will handle actions to produce summary output JSON in output.dat file used in vCats playbooks
# Author: Arokiya Ag 
# Refernce: Daniel Smycek

import json, os, time, re, ast, errno, csv, pprint
from ansible.parsing.ajson import AnsibleJSONEncoder
from ansible.errors import AnsibleError, AnsibleFilterError, AnsibleFilterTypeError
from ansible.utils.display import Display
from collections import OrderedDict



class FilterModule(object):
    ''' Shared output dat filter module '''
    
    baseDictKeysOrder = ["RunDateTime", "ActionType", "Devices"]
    deviceDictKeysOrder = ["DNSName", "ManagementIPAddress", "Hostname", "Make", "Platform", "Serial", "DeviceType", "Model", "SWVersion", "Domain", "Status", "Message"]
    actionDictKeysOrder = ["Name", "Status", "Message", "RunDateTime"]
    defaultHTMLTemplatePath = os.getcwd() + "/files/HTML_template_v0.1.html"
    defaultHTMLTagToReplace = '<<outputDatJSON>>'
    defaultHTMLOutputFilePath = 'defined on fly based on provided path in function'
    defaultHTMLOutputFolderPath = 'defined on fly based on provided path in function'
    

    # Public methods
    def filters(self):
        return {
            'base_to_output_dat': self.base_to_output_dat,
            'device_to_output_dat': self.device_to_output_dat,
            'action_to_output_dat': self.action_to_output_dat,
            'csv_record_to_output_dat': self.csv_record_to_output_dat,
            'resolve_domain_number': self.resolve_domain_number,
            'output_dat_to_html_viewer': self.output_dat_to_html_viewer,
            'load_csv': self.load_csv
        }



    def base_to_output_dat(self, dummy, path="", actionType=""):
        """ check if standalone or integrated action and generate lvl 1 = base of output.dat structure; return complete and valid structure of output.dat """
        if (path == "" or actionType == ""):
            raise AnsibleFilterError("To-output-dat: mandatory variables path or actionType not defined")

        # Lock file
        with FileLock(path, "base"):            
            # If integrated action == return current output.dat json
            if (self.__is_output_dat_empty(path) == True):
                return self.__load_output_dat(path)
            
            # Base structure
            baseDict = {
                "RunDateTime": self.__get_miliseconds_since_epoch(),
                "ActionType": actionType,
                "Devices": []
            }
            return self.__write_to_output_dat(baseDict, path)



    def device_to_output_dat(self, oldDeviceDict, path="", hostVars=""):
        """ generate or update lvl 2 = device in output.dat structure """
        if (path == ""):
            raise AnsibleFilterError("To-output-dat: mandatory variable path is not defined")
        if ("ansible_facts" not in hostVars):
            raise AnsibleFilterError("To-output-dat: the ansible_facts object wasn't found in hostVars object")
 
        # Lock file
        with FileLock(path, hostVars.get("MgmtIP", "")):
            #time.sleep(1);
            
            # New Device structure without Actions array (new or update)
            deviceDict = {
                "DNSName": hostVars.get("DNSEntityName", ""),
                "ManagementIPAddress": hostVars.get("MgmtIP", ""),
                "Hostname": hostVars.get("ansible_facts", "").get("net_hostname", ""),
                "Make": hostVars.get("make", ""),
                "Platform": oldDeviceDict.get("Platform", ""),
                "Serial": hostVars.get("ansible_facts", "").get("net_serialnum", ""),
                "DeviceType": hostVars.get("deviceType", ""),
                "Model": hostVars.get("ansible_facts", "").get("net_model", ""),
                "Domain": self.__resolve_domain_name(),
                "Status": oldDeviceDict.get("Status", ""),
                "Message": oldDeviceDict.get("Message", ""),
                "DeviceVersion": hostVars.get("ansible_facts", "").get("net_version", "")
            }
            
            # Add / Update device in dict
            return self.__update_device_in_output_dat(self.__update_order_of_keys(deviceDict, self.deviceDictKeysOrder), path)            



    def action_to_output_dat(self, actionDict, path="", deviceIP=""):
        """ update lvl 3 = action in output.dat structure """
        if (path == "" or deviceIP == ""):
            raise AnsibleFilterError("To-output-dat: mandatory variable path or deviceIP is not defined")
        
        # Lock file
        with FileLock(path, deviceIP):
            #time.sleep(1);
            
            # Load current output.dat
            outputDatDict = self.__load_output_dat(path)
            if (type(outputDatDict) is not type(OrderedDict())):        
                raise AnsibleFilterError("To-output-dat: invalid JSON loaded from output.dat - " + str(type(outputDatDict)))
            if ("Devices" not in outputDatDict):
                raise AnsibleFilterError("To-output-dat: devices array wasn't found in output.dat")
            if (type(outputDatDict["Devices"]) is not list):
                raise AnsibleFilterError("To-output-dat: devices is not an array")
                
            # Add current "RunDateTime" to structure
            actionDict['RunDateTime'] = self.__get_miliseconds_since_epoch()
        
            # Inject new action dict to device actions list
            found = False
            deviceDict = dict()               
            for dev in outputDatDict.get("Devices", []):
                if dev["ManagementIPAddress"] == deviceIP:
                    dev["Actions"].append(self.__update_order_of_keys(actionDict, self.actionDictKeysOrder))          
                    found = True
                    deviceDict.update(dev)
            if (found == False):
                raise AnsibleFilterError("To-output-dat: device " + deviceIP + " is not in output.dat")
    
            # Update output.dat
            self.__write_to_output_dat(outputDatDict, path)
            
            # Try to also generate HTML based on default values
            if os.path.exists(self.defaultHTMLTemplatePath):
                defaultHTMLOutputFolderPath = os.path.dirname(path) + "/output"
                if not os.path.exists(defaultHTMLOutputFolderPath):
                    os.makedirs(defaultHTMLOutputFolderPath)
                self.defaultHTMLOutputFilePath = defaultHTMLOutputFolderPath + "/output.html"
                self.output_dat_to_html_viewer("foo", path, self.defaultHTMLTemplatePath, self.defaultHTMLOutputFilePath, self.defaultHTMLTagToReplace, outputDatDict)
                Display().warning("To-output-dat: HTML generated/updated - " + self.defaultHTMLOutputFilePath)
                
            # Return
            return str(json.dumps(deviceDict))
            
            
            
    def output_dat_to_html_viewer(self, dummy, outputDatPath="", templatePath="", outputHTMLPath="", tag="", outputDatDict=None):
        """ inject output.dat json string (line form) to template (replkace) of tag """
        if (outputDatPath == "" or templatePath == "" or outputHTMLPath == "" or tag == ""):
            raise AnsibleFilterError("To-output-dat: mandatory variables outputDatPath / templatePath / outputHTMLPath / tag not defined")
        
        # Lock file
        with FileLock(outputHTMLPath, "HTML"):
        
            # Load current output.dat
            if outputDatDict is None:
                outputDatDict = self.__load_output_dat(outputDatPath)
                if (type(outputDatDict) is not type(OrderedDict())):        
                    Display().warning("To-output-dat: invalid JSON loaded from output.dat - " + str(type(outputDatDict)))
                    return
                    
            # Transform to JSON string + normalize
            jsonString = str(json.dumps(outputDatDict)).replace("'", "").replace("\\", "\\\\").replace("\"", "\\\"")
            
            # Load HTML template
            templateLines = self.__load_file(templatePath)
            if (len(templateLines) < 1):
                Display().warning("To-output-dat: invalid template or template is empty")
                return
                
            # Replace tag and save 
            for i, line in enumerate(templateLines):
                if tag in line:
                    templateLines[i] = line.replace(tag, jsonString)
            self.__write_lines_to_file(templateLines, outputHTMLPath)         
                

            
    def csv_record_to_output_dat(self, record, path=""):
        """ insert record in csv for in output.dat; """
        if (path == "" or record == ""):
            raise AnsibleFilterError("To-output-dat: mandatory variables path or record not defined")

        # Lock file
        with FileLock(path, "csv"):
            return self.__write_csv_to_output_dat(record, path)
            
            
            
    def load_csv(self, dummy, path=""):
        """ insert record in csv for in output.dat; """
        if (path == ""):
            raise AnsibleFilterError("To-output-dat: mandatory variables path not defined")

        return self.__load_csv_file(path)
            


    def resolve_domain_number(self, dummy):
        """ return domain number """
        return self.__resolve_domain_number()
    
        
        
    # Private methods
    def __get_miliseconds_since_epoch(self):
        return int(round(time.time() * 1000))
            
    def __resolve_domain_number(self):
        """ resolve domain number based on current server hostname and VZ server name convention """
        try:
            if os.getenv('HOSTNAME') is None:
                if os.getenv('NODE_NAME') == "pdctd30-snmcpe1b.mso.mci.com":                                      
                    # LAB
                    return "centos"
                return int(re.findall(r"[np]dc\D+(\d+)\-",(os.getenv('NODE_NAME')))[0])
            else:
                if os.getenv('HOSTNAME') == "ndctc01-cmds1.mso.mci.com":     
                    # LAB
                    return "centos"
                elif os.getenv('HOSTNAME') == "dxsrv1": 
                    # Centos
                    return "centos"
                return int(re.findall(r"[np]dc\D+(\d+)\-",(os.getenv('HOSTNAME')))[0])
        except:
            Display().warning("To-output-dat: unable to resolve server domain number")
            return ""
            
    def __resolve_domain_name(self):
        """ resolve domain name based on current server hostname and VZ server name convention """
        try:
            return os.getenv('NODE_NAME') if os.getenv('HOSTNAME') is None else os.getenv('HOSTNAME')
        except:
            Display().warning("To-output-dat: unable to resolve server domain name")
            return ""
            
            
            
    def __write_lines_to_file(self, lines, path):
        """ Write  """
        injectJson = None
        try:
            f = open(path, 'w')
            f.write("".join(lines))
            f.close()            
        except:
            Display().warning("To-output-dat: unable to write lines to + " + path) 
        return injectJson
        
       
       
    def __write_to_output_dat(self, sourceDict, path):
        """ Converse to final dict to"nice" JSON and write it to output.dat """
        injectJson = None
        try:
            injectJson = json.dumps(self.__update_order_of_keys(sourceDict, self.baseDictKeysOrder), indent=4, separators=(',', ': '))
            injectJson += '\n'
            f = open(path, 'w')
            f.write(injectJson)
            f.close()            
        except:
            Display().warning("To-output-dat: unable to modify keys to follow order and write to output.dat") 
        return injectJson
        
        
        
    def __write_csv_to_output_dat(self, record, path):
        """ append csv output.dat with record """
        try:
            f = open(path, 'a')
            f.write(record +  "\n")
            f.close()            
        except:
            Display().warning("To-output-dat: unable to append record to output.dat") 
            return False
        return True
        
   
   
    def __load_csv_file(self, path):
        """ open csv file and deserialize it to list of lists """
        finalList = []
        try:
            f = open(path, 'r')
            reader = csv.reader(f)
            for row in reader:
                finalList.append(map(lambda rec: "\"" + rec + "\"" if "\n" in rec else rec , row))
            f.close()            
        except:
            Display().warning("To-output-dat: unable to load csv file: " + path) 
            return finalList
        return finalList
        
        
        
    def __load_file(self, path):
        """ open file and return lines """
        finalList = []
        try:
            f = open(path, 'r')
            for row in f:
                finalList.append(row)
            f.close()            
        except:
            Display().warning("To-output-dat: unable to load file: " + path) 
            return []
        return finalList
    


    def __load_output_dat(self, path):
        """ load JSON from output.dat and converse it to dict """
        outputDatDict = None
        try:
            f = open(path, 'r');
            outputDatDict = json.loads(f.read())   
            f.close()              
        except:
            Display().warning("To-output-dat: unable to parse output.dat to JSON")
              
        # Device normalization (ordred after load)
        try:
            # Base
            outputDatDict = self.__update_order_of_keys(outputDatDict, self.baseDictKeysOrder)
                        
            # Devices
            devicesTempList = []
            for dev in outputDatDict.get("Devices", []):
                normalizerdDev = self.__update_order_of_keys(dev, self.deviceDictKeysOrder)
                
                # Actions
                actionsTempList = []
                for act in normalizerdDev.get("Actions", []):
                    normalizerdAct = self.__update_order_of_keys(act, self.actionDictKeysOrder)
                    actionsTempList.append(normalizerdAct)
                
                normalizerdDev["Actions"] = actionsTempList
                devicesTempList.append(normalizerdDev)
            outputDatDict["Devices"] = devicesTempList
        except:
            Display().warning("To-output-dat: unable to finish dict normalization")
            return outputDatDict
        return outputDatDict



    def __is_output_dat_empty(self, path):
        """ check if output.dat exists """
        return os.path.isfile(path)



    def __update_device_in_output_dat(self, deviceDict, path):
        """ found specific device in output.dat and update it or add new one"""

        # Load current output.dat
        outputDatDict = self.__load_output_dat(path)
        if (type(outputDatDict) is not type(OrderedDict())):         
            raise AnsibleFilterError("To-output-dat: invalid JSON loaded from output.dat. - " + str(type(outputDatDict)))
        if ("Devices" not in outputDatDict):
            raise AnsibleFilterError("To-output-dat: devices array wasn't found in output.dat")
        if (type(outputDatDict["Devices"]) is not list):
            raise AnsibleFilterError("To-output-dat: devices are not an array type")

        # Find the device
        found = False
        
        for dev in outputDatDict.get("Devices", []):
            if dev["ManagementIPAddress"] == deviceDict["ManagementIPAddress"]:
                dev.update(deviceDict)
                deviceDict.update(dev)
                found = True
        if (found == False):
            # New device == empty actions list
            deviceDict["Actions"] = []
            outputDatDict["Devices"].append(self.__update_order_of_keys(deviceDict, self.deviceDictKeysOrder))    

        # Update output.dat
        self.__write_to_output_dat(outputDatDict, path)  
        
        # Try to also generate HTML based on default values
        if os.path.exists(self.defaultHTMLTemplatePath):
            defaultHTMLOutputFolderPath = os.path.dirname(path) + "/output"
            if not os.path.exists(defaultHTMLOutputFolderPath):
                os.makedirs(defaultHTMLOutputFolderPath)
            self.defaultHTMLOutputFilePath = defaultHTMLOutputFolderPath + "/output.html"
            self.output_dat_to_html_viewer("foo", path, self.defaultHTMLTemplatePath, self.defaultHTMLOutputFilePath, self.defaultHTMLTagToReplace, outputDatDict)
            Display().warning("To-output-dat: HTML generated/updated - " + self.defaultHTMLOutputFilePath)
        
        return str(json.dumps(deviceDict))



    def __update_order_of_keys(self, sourceDict, orderOfKeysList):
        """ Sort dictionary object for save in desired ordrer for 3 layers we use """
        finalDict = OrderedDict()
        tempDict = sourceDict.copy()
        try:
            for key in orderOfKeysList:
                finalDict[key] = tempDict.pop(key)
            for key in tempDict.keys():
                finalDict[key] = tempDict[key]
            return finalDict
        except:
            Display().warning("To-output-dat: unable to resolve order of keys properly")
            return sourceDict

# Support classes - FileLock
class FileLockException(Exception):
    pass
 
class FileLock(object):
    """ A file locking mechanism that has context-manager support so 
        you can use it in a with statement. This should be relatively cross
        compatible as it doesn't rely on msvcrt or fcntl for the locking.
    """
 
    def __init__(self, file_name, description, timeout=20, delay=.5):
        """ Prepare the file locker. Specify the file to lock and optionally
            the maximum timeout and the delay between each attempt to lock.
        """
        if timeout is not None and delay is None:
            raise ValueError("If timeout is not None, then delay must not be None.")
        self.is_locked = False
        self.description = description
        self.lockfile =  file_name + ".lock"
        self.file_name = file_name
        self.timeout = timeout
        self.delay = delay
        self.debug = True
 
 
 
    # Public methods
    def acquire(self):
        """ Acquire the lock, if possible. If the lock is in use, it check again
            every `wait` seconds. It does this until it either gets the lock or
            exceeds `timeout` number of seconds, in which case it throws 
            an exception.
        """
        start_time = time.time()
        while True:
            try:
                self.fd = os.open(self.lockfile, os.O_CREAT|os.O_EXCL|os.O_RDWR)
                self.is_locked = True
                if self.debug:
                    Display().warning("To-output-dat: lock file for " + self.description + " -- " + str(time.time()))
                break;
            except OSError as e:
                if self.debug:
                    Display().warning("To-output-dat: wait for file for " + self.description + " -- " + str(time.time()))
                if e.errno != errno.EEXIST:
                    raise
                if self.timeout is None:
                    Display().warning("To-output-dat: not possible to do file lock")
                    break;
                if (time.time() - start_time) >= self.timeout:
                    Display().warning("To-output-dat: file lock time exceeded")
                    break;
                time.sleep(self.delay)
 
    def release(self):
        """ Get rid of the lock by deleting the lockfile. 
            When working in a `with` statement, this gets automatically 
            called at the end.
        """
        if self.is_locked:
            os.close(self.fd)
            os.unlink(self.lockfile)
            self.is_locked = False
            if self.debug:
                Display().warning("To-output-dat: unlock file for " + self.description + " -- " + str(time.time()))
 
 
 
    # Private methods
    def __enter__(self):
        """ Activated when used in the with statement. 
            Should automatically acquire a lock to be used in the with block.
        """
        if not self.is_locked:
            self.acquire()
        return self
 
    def __exit__(self, type, value, traceback):
        """ Activated at the end of the with statement.
            It automatically releases the lock if it isn't locked.
        """
        if self.is_locked:
            self.release()

    def __del__(self):
        """ Make sure that the FileLock instance doesn't leave a lockfile
            lying around.
        """
        self.release()