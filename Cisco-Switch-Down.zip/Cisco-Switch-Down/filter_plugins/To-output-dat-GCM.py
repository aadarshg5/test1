#!/usr/bin/python
# Ansible custom filter plugin - Lite (v0.9.1)
# Description: Only action to write data output JSON in output.dat file used in vCats playbooks
# Reference: Daniel Smycek(v0.8.5)
# Author: Balaji VR

from ansible.utils.display import Display
from ansible.errors import AnsibleFilterError
from collections import OrderedDict
import json, os, time, errno, logging, re

class FilterModule(object):
    ''' Shared output dat filter module '''
    
    baseDictKeysOrder = ["RunDateTime", "ActionType", "CTIAttributes", "Devices"]
    deviceDictKeysOrder = ["DNSName", "ManagementIPAddress", "Domain", "Status", "Message", "BeforeChange","AfterChange"]
    actionDictKeysOrder = ["Name", "Status", "Message", "Config-Line","Tests"]
    cmdDictKeysOrder = ["Command","Commandlines"]


    # Public methods
    def filters(self):
        return {
            'base_to_output_dat_new': self.base_to_output_dat_new,
            'device_to_output_dat_new': self.device_to_output_dat_new,
            'resolve_domain_number': self.resolve_domain_number,
            'cmd_to_output_dat': self.cmd_to_output_dat,
            'status_msg_to_output_dat': self.status_msg_to_output_dat
        }


    def base_to_output_dat_new(self, dummy, CTIAttributes, path="", actionType=""):
        """ check if standalone or integrated action and generate lvl 1 = base of output.dat structure; return complete and valid structure of output.dat """
        if (path == "" or actionType == ""):
            raise AnsibleFilterError("To-output-dat-GCM: mandatory variables path or actionType not defined")

        # Lock file
        with FileLock(path, "base"):
            # If integrated action == return current output.dat json
            if (self.__is_output_dat_empty(path) == True):
                return self.__load_output_dat(path)
            
            # Base structure
            
            baseDictnew = {
                "RunDateTime": self.__get_miliseconds_since_epoch(),
                "ActionType": actionType,
                "CTIAttributes": CTIAttributes,                                
                "Devices": []
            }
            return self.__write_to_output_dat(baseDictnew, path)


    def device_to_output_dat_new(self, deviceDict, path="", hostVars=""):
        """ generate or update lvl 2 = device in output.dat structure """
        if (path == ""):
            raise AnsibleFilterError("To-output-dat-GCM: mandatory variable path is not defined")
        if ("ansible_facts" not in hostVars):
            raise AnsibleFilterError("To-output-dat-GCM: the ansible_facts object wasn't found in hostVars object")
 
        # Lock file
        with FileLock(path, hostVars.get("MgmtIP", "")):
            doMain= self.__resolve_domain_name()
            deviceDict['Domain'] = doMain
            return self.__update_device_in_output_dat(self.__update_order_of_keys(deviceDict, self.deviceDictKeysOrder), path)            


    def cmd_to_output_dat(self, cmdDict, outputType="", path="", hostVars=""):
        if (path == ""):
            raise AnsibleFilterError("To-output-dat-GCM: mandatory variable path is not defined")
        if ("MgmtIP" not in hostVars):
            raise AnsibleFilterError("To-output-dat-GCM: the MgmtIP object wasn't found in hostVars object")
 
        # Lock file
        with FileLock(path, hostVars.get("MgmtIP", "")):                        
            # Load current output.dat
            outputDatDict = self.__load_output_dat(path)
            if (type(outputDatDict) is not type(OrderedDict())):         
                raise AnsibleFilterError("To-output-dat-GCM: invalid JSON loaded from output.dat during cmd. - " + str(type(outputDatDict)))
            if (type(outputDatDict["Devices"]) is not list):
                raise AnsibleFilterError("To-output-dat-GCM: devices are not an array type")
            
            # BeforeChange
            if outputType == 'BeforeChange':
                found = False
                for dev in outputDatDict.get("Devices", []):
                    if (dev["ManagementIPAddress"] == hostVars['MgmtIP']) or (dev["DNSName"] == hostVars['DNSEntityName']):
                        ## if input is list conatins Dict
                        if (isinstance(cmdDict, list)):
                            if (dev[outputType]):
                                for pav in cmdDict:
                                    flag = False
                                    for val in dev[outputType]:
                                        ## Checking if command already exist on output.dat
                                        if (pav['Command'] == val['Command']):
                                            Display().warning("To-output-dat-GCM: - BeforeChange "+val['Command']+ " Already exist output.dat")
                                            flag = True
                                            break
                                    if not flag:
                                        dev[outputType].append(self.__update_order_of_keys(pav, self.cmdDictKeysOrder))
                            else:
                                for pav in cmdDict:
                                    dev[outputType].append(self.__update_order_of_keys(pav, self.cmdDictKeysOrder))
                        
                        ## If input is Dict
                        else:
                            flag = False
                            for val in dev[outputType]:
                                ## Checking if command already exist on output.dat
                                if (cmdDict['Command'] == val['Command']):
                                    Display().warning("To-output-dat-GCM: - BeforeChange "+val['Command']+ " Already exist output.dat")
                                    flag = True
                                    break
                            if not flag:
                                dev[outputType].append(self.__update_order_of_keys(cmdDict, self.cmdDictKeysOrder))
                        found = True
                if (found == False):
                    raise AnsibleFilterError("To-output-dat-GCM: " + outputType + " is not in output.dat")
            
            # AfterChange
            if outputType == 'AfterChange':
                found = False
                for dev in outputDatDict.get("Devices", []):
                    if (dev["ManagementIPAddress"] == hostVars['MgmtIP']) or (dev["DNSName"] == hostVars['DNSEntityName']):
                        
                        ## if input is list conatins Dict
                        if (isinstance(cmdDict, list)):
                            if (dev[outputType]):
                                for pav in cmdDict:
                                    flag = False
                                    for val in dev[outputType]:
                                        ## Checking if command already exist on output.dat
                                        if (pav['Command'] == val['Command']):
                                            Display().warning("To-output-dat-GCM: - AfterChange "+str(pav['Command'])+ " Already exist output.dat and same needs to be updated.")
                                            dev[outputType].remove(val)
                                            dev[outputType].append(self.__update_order_of_keys(pav, self.cmdDictKeysOrder))
                                            flag = True
                                            break
                                    if not flag:
                                        #Display().warning("To-output-dat-GCM: - AfterChange - Not flag block")
                                        dev[outputType].append(self.__update_order_of_keys(pav, self.cmdDictKeysOrder))
                            else:
                                #Display().warning("To-output-dat-GCM: - AfterChange - else")
                                for pav in cmdDict:
                                    dev[outputType].append(self.__update_order_of_keys(pav, self.cmdDictKeysOrder))
                        
                        ## If input is Dict
                        else:
                            #Display().warning("To-output-dat-GCM: On else-------------------------------")
                            flag = False
                            for val in dev[outputType]:
                                ## Checking if command already exist on output.dat
                                if (cmdDict['Command'] == val['Command']):
                                    Display().warning("To-output-dat-GCM: - AfterChange "+str(pav['Command'])+ " Already exist output.dat and same needs to be updated.")
                                    dev[outputType].remove(val)
                                    dev[outputType].append(self.__update_order_of_keys(cmdDict, self.cmdDictKeysOrder))
                                    flag = True
                                    break
                            if not flag:
                                #Display().warning("To-output-dat-GCM: - AfterChange - Not flag block")
                                dev[outputType].append(self.__update_order_of_keys(cmdDict, self.cmdDictKeysOrder))
                        found = True

                if (found == False):
                    raise AnsibleFilterError("To-output-dat-GCM: " + outputType + " is not in output.dat")
            

            # Update output.dat
            self.__write_to_output_dat(outputDatDict, path)  
            
            return str(json.dumps(cmdDict))


    def status_msg_to_output_dat(self, dummy, confStatus="", confMsg="", path="", hostVars=""):
        if (path == ""):
            raise AnsibleFilterError("To-output-dat-GCM: mandatory variable path is not defined")
        if ("MgmtIP" not in hostVars):
            raise AnsibleFilterError("To-output-dat-GCM: the MgmtIP object wasn't found in hostVars object")
 
        # Lock file
        with FileLock(path, hostVars.get("MgmtIP", "")):                        
            # Load current output.dat
            outputDatDict = self.__load_output_dat(path)
            if (type(outputDatDict) is not type(OrderedDict())):   
                #Display().warning("To-output-dat-GCM: "+ str(outputDatDict))
                raise AnsibleFilterError("To-output-dat-GCM: invalid JSON loaded from output.dat status_msg. - " + str(type(outputDatDict)))
            if (type(outputDatDict["Devices"]) is not list):
                raise AnsibleFilterError("To-output-dat-GCM: devices are not an array type")
            
            # Find the device
            found = False
            for dev in outputDatDict.get("Devices", []):
                if (dev["ManagementIPAddress"] == hostVars['MgmtIP']) or (dev["DNSName"] == hostVars['DNSEntityName']):
                    #Display().warning("To-output-dat-GCM: Status has '"+ str(dev["Status"]) + "' and new value is : '"+confStatus+"'")
                    #Display().warning("To-output-dat-GCM: Message has '"+ str(dev["Message"]) + "' and new value is : '"+confMsg+"'")
                    #dev.update({"Status": confStatus})
                    Display().warning("To-output-dat-GCM: Changes in Status and Message are being updated")
                    if confStatus == 'ERROR':
                        dev["Status"] = 'Failure'
                    else:
                        dev["Status"] = confStatus
                    dev["Message"] = confMsg
                    found = True
            if (found == False):
                raise AnsibleFilterError("To-output-dat-GCM: DNSEntityName or MgmtIP is not found in output.dat")

            # Update output.dat
            self.__write_to_output_dat(outputDatDict, path)  
            
            return str(json.dumps(outputDatDict))



    ##"-------------------------- Sub Functions--------------------------"
    def __get_miliseconds_since_epoch(self):
        return int(round(time.time() * 1000))    

    
    def __is_output_dat_empty(self, path):
        """ check if output.dat exists """
        return os.path.isfile(path)
    
       
    def __write_to_output_dat(self, sourceDict, path):
        """ Converse to final dict to"nice" JSON and write it to output.dat """
        injectJson = None
        try:
            injectJson = json.dumps(self.__update_order_of_keys(sourceDict, self.baseDictKeysOrder), indent=4, separators=(',', ': '))
            injectJson += '\n'
            f = open(path, 'w')
            f.write(injectJson)
            f.close()            
        except:
            Display().warning("To-output-dat: unable to modify keys to follow order and write to output.dat") 
        return injectJson
        
   
    def __update_order_of_keys(self, sourceDict, orderOfKeysList):
        """ Sort dictionary object for save in desired ordrer for 3 layers we use """
        finalDict = OrderedDict()
        tempDict = sourceDict.copy()
        
        try:
            for key in orderOfKeysList:
                finalDict[key] = tempDict.pop(key)
            for key in tempDict.keys():
                finalDict[key] = tempDict[key]
            return finalDict
        except:
            #Display().warning("To-output-dat-GCM: SourceDict is: "+str(sourceDict)+" and OrderKeys is :"+str(orderOfKeysList))
            Display().warning("To-output-dat-GCM: unable to resolve order of keys properly")
            return sourceDict
                     
  
    def __load_output_dat(self, path):
        """ load JSON from output.dat and converse it to dict """
        outputDatDict = None
        try:
            f = open(path, 'r')
            outputDatDict = json.loads(f.read())   
            f.close()              
        except:
            Display().warning("To-output-dat-GCM: unable to parse output.dat to JSON")
              
        # Device normalization (ordred after load)
        try:
            # Base
            outputDatDict = self.__update_order_of_keys(outputDatDict, self.baseDictKeysOrder)
                        
            # Devices
            devicesTempList = []
            for dev in outputDatDict.get("Devices", []):
                normalizerdDev = self.__update_order_of_keys(dev, self.deviceDictKeysOrder)

                # BeforeChange
                bfcTempList = []
                for i in normalizerdDev.get("BeforeChange", []):
                    normalizerdAct = self.__update_order_of_keys(i, self.cmdDictKeysOrder)
                    bfcTempList.append(normalizerdAct)
                ##---##
                normalizerdDev["BeforeChange"] = bfcTempList

                # AfterChange
                afcTempList = []
                for j in normalizerdDev.get("AfterChange", []):
                    normalizerdAct = self.__update_order_of_keys(j, self.cmdDictKeysOrder)
                    afcTempList.append(normalizerdAct)
                ##---##
                normalizerdDev["AfterChange"] = afcTempList

                devicesTempList.append(normalizerdDev)
            outputDatDict["Devices"] = devicesTempList
        except:
            Display().warning("To-output-dat-GCM: unable to finish dict normalization")
            return outputDatDict
        return outputDatDict


    def __update_device_in_output_dat(self, deviceDict, path):
        """ found specific device in output.dat and update it or add new one"""
        # Load current output.dat
        outputDatDict = self.__load_output_dat(path)
        if (type(outputDatDict) is not type(OrderedDict())):         
            raise AnsibleFilterError("To-output-dat-GCM: invalid JSON loaded from output.dat. - " + str(type(outputDatDict)))
        # if ("Devices" not in outputDatDict):
        #     raise AnsibleFilterError("To-output-dat-GCM: devices array wasn't found in output.dat")
        if (type(outputDatDict["Devices"]) is not list):
            raise AnsibleFilterError("To-output-dat-GCM: devices are not an array type")

        # Find the device
        found = False
        
        for dev in outputDatDict.get("Devices", []):
            if (dev["ManagementIPAddress"] == deviceDict["ManagementIPAddress"]) or (dev["DNSName"] == deviceDict["DNSName"]):
                dev.update(deviceDict)
                deviceDict.update(dev)
                found = True
        if (found == False):
            outputDatDict["Devices"].append(self.__update_order_of_keys(deviceDict, self.deviceDictKeysOrder))    

        # Update output.dat
        self.__write_to_output_dat(outputDatDict, path)  
        
        return str(json.dumps(deviceDict))
    
    def resolve_domain_number(self, dummy):
        """ return domain number """
        return self.__resolve_domain_number()
    
    def __resolve_domain_number(self):
        """ resolve domain number based on current server hostname and VZ server name convention """
        try:
            if os.getenv('HOSTNAME') is None:
                if os.getenv('NODE_NAME') == "pdctd30-snmcpe1b.mso.mci.com":                                      
                    # LAB
                    return "centos"
                return int(re.findall(r"[np]dc\D+(\d+)\-",(os.getenv('NODE_NAME')))[0])
            else:
                if os.getenv('HOSTNAME') == "ndctc01-cmds1.mso.mci.com":     
                    # LAB
                    return "centos"
                elif os.getenv('HOSTNAME') == "dxsrv1": 
                    # Centos
                    return "centos"
                return int(re.findall(r"[np]dc\D+(\d+)\-",(os.getenv('HOSTNAME')))[0])
        except:
            Display().warning("To-output-dat: unable to resolve server domain number")
            return ""
        
    def __resolve_domain_name(self):
        """ resolve domain name based on current server hostname and VZ server name convention """
        try:
            return os.getenv('NODE_NAME') if os.getenv('HOSTNAME') is None else os.getenv('HOSTNAME')
        except:
            Display().warning("To-output-dat: unable to resolve server domain name")
            return ""

# Support classes - FileLock
class FileLockException(Exception):
    pass
 
class FileLock(object):
    """ A file locking mechanism that has context-manager support so 
        you can use it in a with statement. This should be relatively cross
        compatible as it doesn't rely on msvcrt or fcntl for the locking.
    """
 
    def __init__(self, file_name, description, timeout=20, delay=.5):
        """ Prepare the file locker. Specify the file to lock and optionally
            the maximum timeout and the delay between each attempt to lock.
        """
        if timeout is not None and delay is None:
            raise ValueError("If timeout is not None, then delay must not be None.")
        self.is_locked = False
        self.description = description
        self.lockfile =  file_name + ".lock"
        self.file_name = file_name
        self.timeout = timeout
        self.delay = delay
        self.debug = True
 
 
 
    # Public methods
    def acquire(self):
        """ Acquire the lock, if possible. If the lock is in use, it check again
            every `wait` seconds. It does this until it either gets the lock or
            exceeds `timeout` number of seconds, in which case it throws 
            an exception.
        """
        start_time = time.time()
        while True:
            try:
                self.fd = os.open(self.lockfile, os.O_CREAT|os.O_EXCL|os.O_RDWR)
                self.is_locked = True
                if self.debug:
                    Display().warning("To-output-dat: lock file for " + self.description + " -- " + str(time.time()))
                break
            except OSError as e:
                if self.debug:
                    Display().warning("To-output-dat: wait for file for " + self.description + " -- " + str(time.time()))
                if e.errno != errno.EEXIST:
                    raise
                if self.timeout is None:
                    Display().warning("To-output-dat: not possible to do file lock")
                    break
                if (time.time() - start_time) >= self.timeout:
                    Display().warning("To-output-dat: file lock time exceeded")
                    break
                time.sleep(self.delay)
 
    def release(self):
        """ Get rid of the lock by deleting the lockfile. 
            When working in a `with` statement, this gets automatically 
            called at the end.
        """
        if self.is_locked:
            os.close(self.fd)
            os.unlink(self.lockfile)
            self.is_locked = False
            if self.debug:
                Display().warning("To-output-dat: unlock file for " + self.description + " -- " + str(time.time()))


    # Private methods
    def __enter__(self):
        """ Activated when used in the with statement. 
            Should automatically acquire a lock to be used in the with block.
        """
        if not self.is_locked:
            self.acquire()
        return self
 
    def __exit__(self, type, value, traceback):
        """ Activated at the end of the with statement.
            It automatically releases the lock if it isn't locked.
        """
        if self.is_locked:
            self.release()

    def __del__(self):
        """ Make sure that the FileLock instance doesn't leave a lockfile
            lying around.
        """
        self.release()