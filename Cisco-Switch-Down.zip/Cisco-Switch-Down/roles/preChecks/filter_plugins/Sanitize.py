#!/usr/bin/python

# vCats / Module / Global / Sanitize - custom filter plugin
# Version: 0.1
# Author: Daniel Smycek
# GIT: https://gitlab.verizon.com/ges-automation-team/vcats/module/global/sanitize

import os
import json
import re
from ansible.parsing.ajson import AnsibleJSONEncoder
from ansible.errors import AnsibleError, AnsibleFilterError, AnsibleFilterTypeError
# from ansible.utils.display import Display
from collections import OrderedDict



class FilterModule(object):
    ''' Sanitize filters module '''
    # Class variables
    currentDirectory = os.path.dirname(os.path.abspath(__file__))
    sanitizePatternsFilePath = currentDirectory + "/files/sanitize_patterns.txt"
    debug = False



    # Public methods
    def filters(self):
        return {
            'sanitize': self.sanitize
        }



    def sanitize(self, inputData):
        """ check inputData passed as string, array, dict and try to encrypt well known senzitive values """
        # Load inputData as string
        if (self.debug): print("- debug:  inputData type is: " + str(type(inputData)))
        if (type(inputData) is str):
            inputDataNormalized = [inputData]
        elif (type(inputData) is dict):
            inputDataNormalized = [json.dumps(inputData)]
        elif (type(inputData) is list):
            inputDataNormalized = inputData
        else:
            raise AnsibleFilterError("Sanitize: unsuported input type: " + str(type(inputData)))
        
        # Load patterns
        patternsList = self.__load_file_as_array(self.sanitizePatternsFilePath)
        
        # Sanitize
        replaceDict = {}
        for pattern in patternsList:
            if (self.debug): print("\n\n\n- debug:    pattern: " + pattern) 
            regEx = re.compile(pattern)
            for line in inputDataNormalized:
                match = regEx.findall(line)
                if match:
                    if (self.debug): print("- debug:      line match: " + line)
                    if (self.debug): print(match)
                    # Extract uniq list for replacement
                    for item in match:   
                        if (type(item) is str):
                            if (self.debug): print("- debug:      item type is 1: " + str(type(item)))
                            if (self.debug): print("- debug:        match item: " + item)
                            item = item.replace("\"", "");
                            item = item.replace(",", "");
                            if (self.debug): print("- debug:        match item with replace: " + item)
                            replaceDict.update({item: self.__encrypt_value(item)})
                            if (self.debug): print("- debug:        match item with encrypt: " + self.__encrypt_value(item))
                        else:
                            if (self.debug): print("- debug:      item type is 2 : " + str(type(item)))
                            if (self.debug): print("- debug:        match item: " + ";".join(item))
                            item = map(lambda rec: rec.replace("\"", ""), item)
                            item = map(lambda rec: rec.replace(",", ""), item)
                            if (self.debug): print("- debug:        match item with replace: " + ";".join(item))
                            map(lambda rec: replaceDict.update({rec: self.__encrypt_value(rec)}), item)
                    
        # Replace uniq values
        if (self.debug): print("\n\n\n- debug:  replace values \n\n\n") 
        for item in replaceDict:
            if (self.debug): print("- debug:    item-value: " + item + " -- " + replaceDict[item]) 
            if (type(inputData) is str or type(inputData) is dict):
                if (self.debug): print("- debug:      input type is 1: ")
                inputDataNormalized[0] = inputDataNormalized[0].replace(item, replaceDict[item])
            else:
                if (self.debug): print("- debug:      input type is 2 : ")
                inputDataNormalized = map(lambda rec: rec.replace(item, replaceDict[item]), inputDataNormalized)
                
        # Return
        if (type(inputData) is str or type(inputData) is dict):
            return inputDataNormalized[0]
        else:
            return inputDataNormalized

      

    # Private methods       
    def __load_file_as_array(self, path):
        """ load file as array """
        try:
            lines = []
            fs = open(path)
            for line in fs:
                temp = line.rstrip()
                if temp != "":
                    lines.append(temp)
            return lines
        except:
            raise AnsibleFilterError("Sanitize: unable to open static input file: '" +  path + "'")
            
    def __encrypt_value(self, item):
        """ replace all characters except first one and last one with * """
        return item[0] + "".join("*" for x in range(len(item) - 2)) + item[len(item) - 1]


def main():
    """ for standalone testing """
    fil = FilterModule()
    fil.debug = True
    
    StandardIOSFS = open("../Cisco_Standard-IOS_full_pre-check_output.dat.json") 
    JunosOSFS = open("../Juniper_Junos-OS_full_pre-check_output.dat.json") 
    StandardIOSDict = json.loads(StandardIOSFS.read())
    JunosOSDict = json.loads(JunosOSFS.read())
    
    ## List input / output test
    ## Standard-IOS
    #showRunLines = StandardIOSDict["Devices"][0]["Actions"][1]["Commands"][12]["CommandLines"]  
    #print("List input / output: \n\t" + "\n\t".join(fil.sanitize(showRunLines)))
    ## Junos-OS
    #showRunLines = JunosOSDict["Devices"][0]["Actions"][1]["Commands"][7]["CommandLines"]  
    #print("List input / output: \n" + "\n\t".join(fil.sanitize(showRunLines)))
    
    ## Dict input / output test
    ## Standard-IOS  
    #print("Dict input / output: \n\t" + fil.sanitize(StandardIOSDict["Devices"][0]["Actions"][1]["Commands"][12]))
    ## Junos-OS
    #print("Dict input / output: \n\t" + fil.sanitize(JunosOSDict["Devices"][0]["Actions"][1]["Commands"][7]))
    
    ## String input / output test
    #print("String input / output: \n\t" + fil.sanitize("enable secret 5 ciscocisco .. enable secret ciscocisco"))
    
    
    
    

if __name__ == "__main__":
    #main()
    pass
    
    
