#!/usr/bin/python

# vCats / Module / Cisco / Standard-IOS / Health-check - custom filter plugin
# Version: 0.1
# Author: Daniel Smycek (based on standalone script version from Libor Slavata)

import json
import os
import re
from datetime import datetime
from ansible.parsing.ajson import AnsibleJSONEncoder
from ansible.errors import AnsibleError, AnsibleFilterError, AnsibleFilterTypeError
from ansible.utils.display import Display

class HealthCheckReturnException(Exception):
    pass

class FilterModule(object):
    ''' Health-check filter module '''
    # Class variables
    healthCheckDict = {
        "Name": "Health-check",
        "Status": "OK",
        "Message": "All health tests passed.",
        "Tests": []
    }
    
    

    # Public methods
    def filters(self):
        return {
            'health_check': self.health_check
        }
       
    def health_check(self, inputDict, deviceType):
        """ proceed with all base health check tests """
        try:   
            if ("Name" not in inputDict):
                self.__update_action_message_status_and_return("ERROR", "Health-check: invalid input data structure (missing 'Name' key)")
            if (inputDict["Name"] != "Pre-check" and inputDict["Name"] != "Post-check"):
                self.__update_action_message_status_and_return("ERROR", "Health-check: invalid input data structure (it's not 'Pre-check' or 'Post-check' structure)")
            if (deviceType != "Router" and deviceType != "Switch" and deviceType != "Routing VM"):
                self.__update_action_message_status_and_return("ERROR", "Health-check: invalid input device type: " + deviceType)
            
            # inputDict to cmdToCommandLinesDict
            commandToLinesDict = self.__get_command_to_command_lines_dict(inputDict)
            
            # Mapping to source and function per device type 
            mapping = []
            if (deviceType == "Router" or deviceType == "Switch" or deviceType == "Routing VM"):
                mapping += [
                    {"name":"Pending Reloads","cmd":"show version | include Reload scheduled","function":self.__check_pending_reloads},
                    {"name":"Config Comparison","cmd":"show running-config | include (Last|NVRAM)","function":self.__compare_config_dates},
                    {"name":"CPU Utilization","cmd":"show proc cpu | i utilization","function":self.__cpuUtilization},
                    {"name":"Environment","cmd":"show environment","function":self.__environment},
                    {"name":"Environment All","cmd":"show environment all","function":self.__environmentAll},
                    {"name":"Interface Description","cmd":"show int description","function":self.__interfaceDescription},
                    {"name":"Interface","cmd":"show interface","function":self.__interface},
                    {"name":"Interface Status","cmd":"show int status","function":self.__interfaceStatus},
                    {"name":"Clock","cmd":"show clock","function":self.__clock},
                    {"name":"Proc Memory Free","cmd":"show proc memory | i Free","function":self.__procMemoryFree},
                    {"name":"IP BGP Sum","cmd":"show ip bgp sum","function":self.__ipBgpSum},
                    {"name":"NTP Status","cmd":"show ntp status","function":self.__ntpStatus},
                    {"name":"Platform Environment Variables","cmd":"show platform environment variables","function":self.__platformEnvironmentVariables},  
                    {"name":"Serial Number","cmd":"show inventory","function":self.__inventory},
                    {"name":"Management IP","cmd":"show ip int brief","function":self.__managementIPs},
                    {"name":"Cell Hardware","cmd":"show cell 0/2/0 hardware","function":self.__cellHardware},
                    {"name":"Banner Info","cmd":"show banner exec","function":self.__banner},
                    {"name":"Host name","cmd":"show run","function":self.__hostName}

                    
            ]
            if (deviceType == "Switch"):     
                mapping += [
                    {"name":"Etherchannel Summary","cmd":"show etherchannel summary","function":self.__etherchannelSummary},
                    {"name":"Switch Virtual Dual Active Fast Hello","cmd":"show switch virtual dual-active fast-hello","function":self.__switchVirtualDualActiveFastHello},
                    {"name":"UDLDP Neighbors","cmd":"show udld neighbors","function":self.__udlpNeighbors},
                    {"name":"Switch Virtual Role","cmd":"show switch virtual role","function":self.__switchVirtualRole},
                    {"name":"Redundancy","cmd":"show redundancy","function":self.__redundancy},
                    {"name":"Switch Virtual Link","cmd":"show switch virtual link","function":self.__switchVirtualLink},
                    {"name":"Switch Virtual Link Port Channel","cmd":"show switch virtual link port-channel","function":self.__switchVirtualLinkPortChannel},
                    {"name":"Switch Virtual Redundancy","cmd":"show switch virtual redundancy","function":self.__switchVirtualRedundancy}
               ]
               
            # Proceed with tests
            for test in mapping: 
                self.healthCheckDict['Tests'].append(test['function'](test['name'], test['cmd'], commandToLinesDict[test['cmd']]))
                
            # Update global status and message
            if(len(list(filter(lambda test: test['Status'] != "OK", self.healthCheckDict['Tests']))) > 0):
                self.healthCheckDict['Status'] = "WARNING"
                self.healthCheckDict['Message'] = "Some health tests failed."
                
            if(len(list(filter(lambda test: test['Status'] == "OK", self.healthCheckDict['Tests']))) == 0):
                self.healthCheckDict['Status'] = "ERROR"
                self.healthCheckDict['Message'] = "All health tests failed."
                
        except HealthCheckReturnException:
            return self.healthCheckDict
        return self.healthCheckDict
        
        
        
    # Private methods
    def __update_action_message_status_and_return(self, status, message):
        """ central function responsible for exit from main plugin function (for all types of return) """
        if (status != "OK"):
            Display().warning(message)
        self.healthCheckDict["Status"] = status
        self.healthCheckDict["Message"] = message
        raise HealthCheckReturnException()
        
    def __get_command_to_command_lines_dict(self, inputDict):
        """ deserialize input structure to dict where key will be command name and value will be list of lines from output """
        if ("Commands" not in inputDict): 
            self.__update_action_message_status_and_return("ERROR", "Health-check: invalid input data structure (missing 'Commands' key)")
        commandToLinesDict = {}
        try:
            for item in inputDict["Commands"]:
                commandToLinesDict[item["Command"]] = item["CommandLines"]
        except:
            self.__update_action_message_status_and_return("ERROR", "Health-check: unable to deserialize input structure to commands with lines")
        return commandToLinesDict
    
    def __is_valid(self, CommandLines):
        if CommandLines:
            return True
        else:
            return False

    # over 80 message
    def __over_80_lines(self):
        return ["The command output is too long. You can find whole output in json file stored as attachment."]
    
    def __cpuUtilization(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = 'CPU Utilization is in order\n'
        ret['Name'] = name
        ret['CommandLines'] = []
    
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
        else:
            out = "\n".join(CommandLines)            
    
            if len([x for x in re.findall("five minutes: ([0-9])", out) if int(x) >= 60]) > 0:
                ret['Status'] = "WARNING"
                ret['Message'] = 'Utilization of CPU/s is above 60 percent\n'
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Environment
    def __environment(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = 'System Temperatures are below 80C\n'
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)  
    
            pattern = r'\d{1,3}(?=\s+Celsius)' #Matches temperature in celsius
            out = re.findall(pattern, out)
            # ret['output'] = out
    
            threshold = [x for x in out if int(x) >= 80]
            if len(threshold) > 0:
                ret['Status'] = "WARNING"
                ret['Message'] = 'System Temperatures are above 80C\n' + out
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Environment All
    def __environmentAll(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = 'FANs alongside PWR are operating as expected\n'
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = CommandLines
            # ret['output'] = out
    
            # Check if FANs are OK
            for line in out:
                line = line.lower()
    
                if "fan" in line:
                    if not "ok" in line:
                        ret['Status'] = "WARNING"
                        ret['Message'] = 'Not all FANs are OK\n'
                else:
                    break
    
            # Check is PWR is OK
            out.reverse()
            for line in out:
                line = line.lower()
    
                if "pwr" in line:
                    if len(re.findall("good", line)) != 2:
                        if ret['Status'] == "WARNING":
                            ret['Message'] += " and not all PWRs are in Good state\n"
                        else:
                            ret['Status'] = "WARNING"
                            ret['Message'] = "Not all PWRs are OK\n"
                elif "--------" in line:
                    break
    
            if len(CommandLines) < 80:
                new_msg = "\\n".join(out)
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Etherchannel Summary
    def __etherchannelSummary(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Port are in a functional status\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = CommandLines
            # ret['output'] = out
    
            out.reverse()
            for line in out:
                if len(re.findall(r"\(P\)|\(R\)", line)) != 2:
                    ret['Status'] = "WARNING"
                    ret['Message'] = "Not all ports are either in 'P' or 'R' status\n"
                    break
                elif "---------" in line:
                    break
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Interface Description
    def __interfaceDescription(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "All Ports with description are UP\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines).lower()
            # ret['output'] = out
    
            if "down" in out:
                ret['Status'] = "WARNING"
                ret['Message'] = "Not all described ports are UP\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Inventory Description
    def __inventory(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "No serial number info\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "WARNING"
            ret['Message'] = "Zero output or not supported"
        else:
            out = "\n".join(CommandLines).lower()
    
            m = re.search(r'name:\s+\"chassis\".*?sn:\s+(\S+)', out, flags=re.DOTALL)
            if m:
                ret['Message'] = "Found serial number info"
                ret['CommandLines'].append(m.group(1).upper())
      
        return ret

    # --- Management IP Description
    def __managementIPs(self, name, cmd, CommandLines):
        ret = {}
        interf_ip = []
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "No management IP info\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "WARNING"
            ret['Message'] = "Zero output or not supported"
        else:
            for data in CommandLines:
              if re.match('Loopback', data, flags=re.I):
                ret['Message'] = "Found management IP's"
                ret['CommandLines'].append(data.split()[1])
      
        return ret

    # --- Cell hardware Description
    def __cellHardware(self, name, cmd, CommandLines):
        ret = {}
        cell_info = []
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "No cell hardware info\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "WARNING"
            ret['Message'] = "Zero output or not supported"
        else:
            for data in CommandLines:
              if data.startswith('International Mobile') or data.startswith('Integrated Circuit'):
                ret['Message'] = "Found cell hardware info"
                cell_info = data.split()
                ret['CommandLines'].append(cell_info[-3] + cell_info[-1])
      
        return ret

    # --- banner Description
    def __banner(self, name, cmd, CommandLines):
        ret = {}
        cell_info = []
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "No banner branch info\n"
        ret['Name'] = name
        ret['CommandLines'] = []
        cap_data = ''
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "WARNING"
            ret['Message'] = "Zero output or not supported"
        else:
            for data in CommandLines:
              if data.startswith('FAD'):
                 cap_data = data.split('|')[1].lstrip(' ') + '/'

              if data.startswith('Branch'):
                 ret['Message'] = "Found banner branch info"
                 ret['CommandLines'].append(cap_data + data.split('|')[1].lstrip(' '))
                 break
      
        return ret

    # --- hostName Description
    def __hostName(self, name, cmd, CommandLines):
        ret = {}
        cell_info = []
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "No host name info\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "WARNING"
            ret['Message'] = "Zero output or not supported"
        else:
            for data in CommandLines:
              if data.startswith('hostname'):
                ret['Message'] = "Found host name info"
                ret['CommandLines'].append(data.split(' ')[1])
                break
      
        return ret

    # --- Interface
    def __interface(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Interfaces are operating as expected\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)  
            # ret['output'] = out
    
            inputErrs = [match for match in re.findall(r'(\d+) input errors', out) if int(match) > 0]
            crcrErrs = [match for match in re.findall(r'(\d+) crc', out) if int(match) > 0]
            frameErrs = [match for match in re.findall(r'(\d+) frame', out) if int(match) > 0]
            overrrunErrs = [match for match in re.findall(r'(\d+) overrun', out) if int(match) > 0]
            ignErrs = [match for match in re.findall(r'(\d+) ignored', out) if int(match) > 0]
            totalDrops = [match for match in re.findall(r'total output drops[ :]*(\d+)', out) if int(match) > 0]
    
            if (len(inputErrs) > 0 or len(crcrErrs) > 0 or len(frameErrs) > 0 or  len(overrrunErrs) > 0 or len(ignErrs) > 0
                    or len(totalDrops) > 0):
                ret['Status'] = "WARNING"
                ret['Message'] = 'Interface links have failed operation checks\n'
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Interface
    def __interfaceStatus(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "All Ports are OK\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            out = os.linesep.join([s for s in out if s and not "---" in s])
    
            if len(re.findall("notconnect", out)) > 0:
                ret['Status'] = "WARNING"
                ret['Message'] = 'Ports with undesirable notconnect status were detected\n'
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Switch Virtual Dual Active Fast Hello
    def __switchVirtualDualActiveFastHello(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Dual Active detection is OK\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            if len(out) == 0 or "link down" in out.lower():
                ret['Status'] = "WARNING"
                ret['Message'] = "Dual Active detection is either not configured or contains ports in DOWN status\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- UDLDP Neighbors
    def __udlpNeighbors(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "All is OK\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            if len(out) == 0 or "bidirectional" in out.lower():
                ret['Status'] = "WARNING"
                ret['Message'] = "Dual Active detection is either not configured or contains ports in DOWN status\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Clock
    def __clock(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Clock is set correctly\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            if not "GMT" in out:
                ret['Status'] = "WARNING"
                ret['Message'] = "Clock is not set to show time in GMT format\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Proc Memory Free
    def __procMemoryFree(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Device has enough free memory\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            if len(out) != 0:
                totalUsed = float(re.findall(r"Total:\s+([0-9]+)", out)[0])
                totalFree = float(re.findall(r"Free:\s+([0-9]+)", out)[0])
                #totalUsed = float(re.findall("([0-9]+)K total", out)[0])
                #totalFree = float(re.findall("([0-9]+)K free", out)[0])
    
                if (totalFree / totalUsed) >= 0.9:
                    ret['Status'] = "WARNING"
                    ret['Message'] = "{}% of memory is used\\n".format(round((totalFree / totalUsed) * 100, 2)) + out
            else:
                ret['Status'] = "WARNING"
                ret['Message'] = "No memory info is available\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Switch Virtual Role
    def __switchVirtualRole(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Virtual Role is properly working\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            if len(out) == 0 or "down" in out.lower():
                ret['Status'] = "WARNING"
                ret['Message'] = "Virtual Switch role is invalid\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- IP BGP Sum
    def __ipBgpSum(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "BGP Table has zero alerts\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines).lower()
            # ret['output'] = out
    
            if "active" in out[str(out).find("neighbor")::]:
                ret['Status'] = "WARNING"
                ret['Message'] = "Not all neighbors are in Active status\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- NTP Status
    def __ntpStatus(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "NTP has no alerts\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines).lower()
            # ret['output'] = out
    
            if not "clock is synchronized" in out:
                ret['Status'] = "WARNING"
                ret['Message'] = "NTP is not synchronized\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Platform Environment Variables
    def __platformEnvironmentVariables(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "BootStatus was successful\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines).lower()
            # ret['output'] = out
    
            if not "BootStatus=\"Success\"" in out:
                ret['Status'] = "WARNING"
                ret['Message'] = "Successful BootStatus is not present\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Redundancy
    def __redundancy(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Redundancy doesn't display any alerts / errors\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines).lower()
            # ret['output'] = out
    
            if (len(out) == 0 or not "configured redundancy mode = sso" in out
                    or not "operating redundancy node = sso" in out or not "current software state = active" in out
                    or not "communications = up" in out):
    
                ret['Status'] = "WARNING"
                ret['Message'] = "Redundancy displays an alert/s\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Switch Virtual Link
    def __switchVirtualLink(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Virtual Link is properly working\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines)
            # ret['output'] = out
    
            if len(out) == 0 or not "vsl status : up" in out.lower():
                ret['Status'] = "WARNING"
                ret['Message'] = "Virtual link doesn't have VSL UP\n"
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Switch Virtual Link Port Channel
    def __switchVirtualLinkPortChannel(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Port are in a functional status\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = CommandLines
            # ret['output'] = out
    
            out.reverse()
            for line in out:
                if len(re.findall(r"\(P\)", line)) != 2:
                    ret['Status'] = "WARNING"
                    ret['Message'] = "Not all ports are either in 'P' or 'R' status\n"
                    break
                elif "---------" in line:
                    break
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret
    
    # --- Switch Virtual Redundancy
    def __switchVirtualRedundancy(self, name, cmd, CommandLines):
        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Redundancy doesn't display any alerts / errors\n"
        ret['Name'] = name
        ret['CommandLines'] = []
    
        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            # ret['output'] = "N/A"
        else:
            out = "\n".join(CommandLines).lower()
            # ret['output'] = out
    
            ids = re.findall(r'switch[ ]+id[ ]+=[ ]+(\d+)', out)
            states = re.findall(r'current[ ]+software[ ]+state[ ]+=[ ]+(.+)', out)
            if len(ids) > 0 and len(states) > 0:
                if states[0] != "active":
                    ret['Status'] = "WARNING"
                    ret['Message'] = "States are not in a correct order but instead show:\n"
                    for i in range(0, len(ids)):
                        ret['Message'] += "Switch ID {}: {}\n".format(ids[i], states[i])
    
            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = self.__over_80_lines()
    
        return ret

    def __compare_config_dates(self, name, cmd, CommandLines):
        ''' compare running-config and startup-config dates '''

        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "Configuration comparison is OK\n"
        ret['Name'] = name
        ret['CommandLines'] = []

        if len(CommandLines) == 2:
            raw_output = CommandLines[0] + CommandLines[1]
        elif len(CommandLines) == 0:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
            raw_output = ''
        else:
            raw_output = CommandLines[0]

        # get the date and time of running/startup pattern
        find_value = r'\d+:\d+:\d+\s\w+\s\w+\s\w+\s\d+\s\d{4}'
        conf_values = re.findall(find_value, raw_output)

        if self.__is_valid(CommandLines) == False:
            ret['Status'] = "ERROR"
            ret['Message'] = "Zero output or not supported"
        elif len(conf_values) != 2:
            ret['Status'] = "Warning"
            ret['Message'] = "Configuration date  not found, please validate and save if needed\n"
            ret['CommandLines'] = CommandLines
        else:
            conf_vals = []
            for tim_value in conf_values:
                tm = tim_value.split(':')
                conf_vals.append(tm[2][11:] + ' ' + tm[0] + ' ' + tm[1])

            # create the datetime objects from dates for comparing dates
            runn_date = datetime.strptime(conf_vals[0], "%b %d %Y %H %M")
            start_date = datetime.strptime(conf_vals[1], "%b %d %Y %H %M")
            delta_val = start_date - runn_date

            if delta_val.days < 0:
                ret['Status'] = "ERROR"
                ret['Message'] = "Running config was not saved, please validate and save the config\n"

            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines
            else:
                ret['CommandLines'] = over_80_lines()

        return ret

    # --- Pending Reload Description
    def __check_pending_reloads(self, name, cmd, CommandLines):
        ''' Check for a pending reload in show version '''

        found_pending = ''

        ret = {}
        ret['Command'] = cmd
        ret['Status'] = "OK"
        ret['Message'] = "No pending reloads are scheduled\n"
        ret['Name'] = name
        ret['CommandLines'] = []

        if CommandLines:
            # Is a reload pending?
            found_pending = re.match('Reload scheduled', CommandLines[0])

            if found_pending:
                ret['Status'] = "Warning"
                ret['Message'] = "Reload pending, please validate and cancel if needed\n"

            if len(CommandLines) < 80:
                ret['CommandLines'] = CommandLines 
            else:
                ret['CommandLines'] = over_80_lines()

        return ret

    
def main():
    # For standalone testing
    fil = FilterModule()
    fi = open("../output.dat") 
    outputDatDict = json.loads(fi.read()) 
    preCheckDict = outputDatDict["Devices"][0]["Actions"][1]
    #print(json.dumps(preCheckDict))
    #fil.health_check(preCheckDict, "Router")
    print(json.dumps(fil.health_check(preCheckDict, "Router")))
    fi.close()
    
if __name__ == "__main__":
    #main()
    pass
