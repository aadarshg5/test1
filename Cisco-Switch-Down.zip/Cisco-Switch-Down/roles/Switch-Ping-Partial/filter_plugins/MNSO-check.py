#!/usr/bin/python

# vCats / Module / Cisco / Standard-IOS / MNSO-check - custom filter plugin
# Version: 0.2
# Author: Daniel Smycek


import json
import os
import re
import pprint
from ansible.parsing.ajson import AnsibleJSONEncoder
from ansible.errors import AnsibleError, AnsibleFilterError, AnsibleFilterTypeError
from ansible.utils.display import Display

class MNSOCheckReturnException(Exception):
    pass

class FilterModule(object):
    ''' MNSO-check filter module '''
    # Class variables
    currentDirectory = os.path.dirname(os.path.abspath(__file__))
    domainsDataFilePath = currentDirectory + "/files/domains_data.json"
    testsTemplateFilePath = currentDirectory + "/files/tests_template.json"
    mnsoCheckDict = {
        "Name": "MNSO-check",
        "Status": "OK",
        "Message": "All MNSO tests passed.",
        "MissingCommands": [],
        "Tests": []
    }
    
    

    # Public methods
    def filters(self):
        return {
            'mnso_check': self.mnso_check
        }
       
    def mnso_check(self, inputDict, host):
        """ validation if device management configuration follows VZ MNSO standards """
        try:   
            if ("Name" not in inputDict):
                self.__update_action_message_status_and_return("ERROR", "MNSO-check: invalid input data structure (missing 'Name' key)")
            if (inputDict["Name"] != "Pre-check" and inputDict["Name"] != "Post-check"):
                self.__update_action_message_status_and_return("ERROR", "MNSO-check: invalid input data structure (it's not 'Pre-check' or 'Post-check' structure)")
                
            commandToLinesDict = self.__get_command_to_command_lines_dict(inputDict)
            showRunSectionToLinesDict = self.__broke_show_run_to_sections_to_command_lines_dict(commandToLinesDict['show run'])

            domainDataDict = self.__load_json_file_to_dict(self.domainsDataFilePath)["Base"][str(self.__resolve_domain_number())]  
            domainDataDict["ansible_host"] = host   # extra append of one more variable which will be used in replace part later
                    
            testsTemplate = self.__load_json_file_to_dict(self.testsTemplateFilePath)
            testsTemplate = self.__replace_all_tags_in_tests_template_dict(domainDataDict, testsTemplate)
            
            self.__proceedWithTests(showRunSectionToLinesDict, testsTemplate)
            
        except MNSOCheckReturnException:
            return self.mnsoCheckDict
        return self.mnsoCheckDict
        
        
        
    # Private methods
    def __resolve_domain_number(self):
        """ resolve domain number based on current server hostname and VZ server name convention """
        try:
            # override for lab env
            if (os.getenv('HOSTNAME') == "dxsrv1" or os.getenv('HOSTNAME') == "ndctc01-cmds1.mso.mci.com"):
                return 3
            return int(re.findall(r"[np]dc\D+(\d+)\-",(os.getenv('NODE_NAME') if os.getenv('HOSTNAME') is None else os.getenv('HOSTNAME')))[0])
        except:
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: unable to resolve server 'domain number'")
            
    def __load_json_file_to_dict(self, path):
        """ load JSON from file and converse it to dict """
        try:
            f = open(path);
        except:
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: unable to open static input file: '" +  path + "'")
        try:
            return json.loads(f.read())     
        except:
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: unable to parse static input file: '" +  path + "'")
            
    def __replace_all_tags_in_tests_template_dict(self, inputDict, targetDict):
        """ replace all <key> tags in targetDict based on <value> in inputDict """
        regEx = re.compile('<')
        for test in targetDict['Tests']:
            if regEx.search(test['CommandPattern']):
                for key, val in inputDict.items():
                    test['CommandPattern'] = test['CommandPattern'].replace('<' + key + '>', val)   # replace all dynamic variables in rule       
        return targetDict
        
    def __get_command_to_command_lines_dict(self, inputDict):
        """ deserialize input structure to dict where key will be command name and value will be list of lines from output """
        if ("Commands" not in inputDict): 
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: invalid input data structure (missing 'Commands' key)")
        commandToLinesDict = {}
        try:
            for item in inputDict["Commands"]:
                commandToLinesDict[item["Command"]] = item["CommandLines"]
        except:
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: unable to deserialize input structure to commands with lines")
        return commandToLinesDict
        
    def __broke_show_run_to_sections_to_command_lines_dict(self, showRunLines):
        """ deserialize show run to dict where key will be command from global configuraiton and value will be list of lines for this config sub-section """
        if ("Building configuration..." not in showRunLines): 
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: invalid input data structure (show run lines))")
        sectionToLinesDict = {"show run": showRunLines}
        buffLines = []
        currentSection = ""
        
        try:
            for line in showRunLines:
                if (line.startswith(" ")):
                    buffLines.append(line)
                else:
                    if (len(buffLines) > 0):
                        sectionToLinesDict[currentSection] = buffLines
                        buffLines = []
                    currentSection = line
        except:
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: unable to deserialize 'show run' to section with lines dict")
        return sectionToLinesDict 
            
    def __proceedWithTests(self, showRunSectionToLinesDict, testsTemplate):
        """ proceed with all tests in tests template and update class MNSO-check structure """
        try:
            for test in testsTemplate["Tests"]:
                newTestStructure = {
                    "CommandPattern": test["CommandPattern"],
                    "Category": test["Category"],
                    "Command": test["Command"],
                    "Type": test["Type"],
                    "Section": test["Section"],
                    "Status": "OK",
                    "Message": ""
                }
                self.mnsoCheckDict["Tests"].append(newTestStructure)
                regEx = re.compile(test["CommandPattern"])
                isFound = False
                
                # Check if we have data source (lines from output for specific command) for test
                if (test["Section"] not in showRunSectionToLinesDict):
                    newTestStructure["Status"] = "ERROR"
                    newTestStructure["Message"] = "This data source command '" + test["Section"] + "' not found in input structure."
                    
                    # Update of summary status and message (absolute ERROR)
                    self.mnsoCheckDict["Status"] = "WARNING"
                    self.mnsoCheckDict["Message"] = "Input data are missing for some 'MNSO-check' tests."
                    continue
                    
                for line in showRunSectionToLinesDict[test["Section"]]:
                    if (regEx.search(line)):
                        isFound = True
                
                if test["Type"] == "REQUIRED":
                    if (isFound):
                        newTestStructure["Message"] = "Required command '" + test["CommandPattern"] + "' found in configuration."
                    else:
                        newTestStructure["Status"] = "WARNING"
                        newTestStructure["Message"] = "Required command '" + test["CommandPattern"] + "' not found in configuration."
                        self.mnsoCheckDict["MissingCommands"].append(test["Section"] + ": '" + test["CommandPattern"] + "'")
                elif test["Type"] == "OBSOLETE":
                    if (isFound):
                        newTestStructure["Status"] = "WARNING"
                        newTestStructure["Message"] = "Obsolete command '" + test["CommandPattern"] + "' is obsolete."
                    else:
                        newTestStructure["Message"] = "Obsolete command '" + test["CommandPattern"] + "' not found in configuration."
                elif test["Type"] == "FORBIDDEN":
                    if (isFound):
                        newTestStructure["Status"] = "WARNING"
                        newTestStructure["Message"] = "Forbidden command '" + test["CommandPattern"] + "' should not be in configuration."
                    else:
                        newTestStructure["Message"] = "Forbidden command '" + test["CommandPattern"] + "' not found in configuration."
                elif test["Type"] == "CUSTOMER":
                    newTestStructure["Message"] = "Optional customer command '" + test["CommandPattern"] + "' " + ("found" if (isFound) else "not found") + " in configuration."
                
                # Update of summary status and message (absolute WARNING)
                if (newTestStructure["Status"] == "WARNING" and self.mnsoCheckDict["Status"] != "ERROR"):
                    self.mnsoCheckDict["Status"] = "WARNING"
                    self.mnsoCheckDict["Message"] = "Some MNSO tests didn't pass."
                    
        except:
            self.__update_action_message_status_and_return("ERROR", "MNSO-check: unexpected issue during tests evaulation")
        
    def __update_action_message_status_and_return(self, status, message):
        """ central function responsible for exit from main plugin function (for all types of return) """
        if (status != "OK"):
            Display().warning(message)
        self.mnsoCheckDict["Status"] = status
        self.mnsoCheckDict["Message"] = message
        raise MNSOCheckReturnException()
               
    

# For standalone testing in lab        
def main():
    fil = FilterModule()
    fi = open("../../../output.dat") 
    outputDatDict = json.loads(fi.read())
    #pprint.pprint(outputDatDict) 
    preCheckDict = outputDatDict["Devices"][1]["Actions"][1]
    #print(json.dumps(preCheckDict))
    #print(json.dumps(fil.mnso_check(preCheckDict, "192.168.31.138")))
    pprint.pprint(fil.mnso_check(preCheckDict, "192.168.31.138"))
    

if __name__ == "__main__":
    #main()
    pass
    
