"""Jinja2 filter plugin for BGP_UP_DOWN_Viptela automation package."""

from __future__ import annotations

import re
from typing import Any


# ─── Platform detection ───────────────────────────────────────────────────────

def detect_platform(show_version_output: str) -> str:
    """Return 'vedge', 'ios_xe', or 'unknown' from show version output."""
    out = show_version_output or ""
    if re.search(r"IOS[ -]XE", out, re.IGNORECASE):
        return "ios_xe"
    if re.search(r"vEdge|vedge|SD-WAN|viptela", out, re.IGNORECASE):
        return "vedge"
    if re.match(r"^\d+\.\d+[\d\.]*\s*$", out.strip()):
        return "vedge"
    return "unknown"


# ─── Problem Summary parsing ──────────────────────────────────────────────────

def extract_text_field(problem_summary: str) -> str:
    """Extract TEXT: value from ETMS Problem Summary string."""
    m = re.search(r"TEXT:\s*(.+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_assure1_alarm_id(problem_summary: str) -> str:
    """Extract ASSURE1 ALARM ID from Problem Summary string."""
    m = re.search(r"ASSURE1 ALARM ID:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_hostname_from_summary(problem_summary: str) -> str:
    """Extract HOSTNAME field from Problem Summary string."""
    m = re.search(r"HOSTNAME:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_neid_from_summary(problem_summary: str) -> str:
    """Extract NEID field from Problem Summary string."""
    m = re.search(r"NEID:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


def extract_ip_from_summary(problem_summary: str) -> str:
    """Extract IP ADDRESS field from Problem Summary string."""
    m = re.search(r"IP ADDRESS:\s*(\S+)", problem_summary or "")
    return m.group(1).strip() if m else ""


# ─── BGP neighbor parsing ─────────────────────────────────────────────────────

def parse_bgp_neighbors(bgp_summary_output: str) -> list[dict]:
    """Parse BGP summary output into list of neighbor state dicts.

    Works for both cEdge (show ip bgp summary) and vEdge (show bgp summary).
    Returns list of dicts: [{neighbor_ip, as_number, state, uptime, prefixes}]
    """
    neighbors: list[dict] = []
    for line in (bgp_summary_output or "").splitlines():
        line_s = line.strip()
        if not line_s:
            continue
        m = re.match(
            r"^(\d+\.\d+\.\d+\.\d+)\s+(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+"
            r"(\S+)\s+(\S+)",
            line_s,
        )
        if m:
            uptime_or_state = m.group(3)
            state_or_pfx = m.group(4)
            if re.match(r"^\d+$", state_or_pfx):
                state = "Established"
                prefixes = state_or_pfx
            else:
                state = state_or_pfx
                prefixes = "0"
            neighbors.append(
                {
                    "neighbor_ip": m.group(1),
                    "as_number": m.group(2),
                    "uptime": uptime_or_state,
                    "state": state,
                    "prefixes": prefixes,
                }
            )
    return neighbors


def get_down_neighbors(neighbors: list[dict]) -> list[dict]:
    """Return neighbors not in Established state."""
    return [n for n in (neighbors or []) if n.get("state", "") != "Established"]


def get_up_neighbors(neighbors: list[dict]) -> list[dict]:
    """Return neighbors in Established state."""
    return [n for n in (neighbors or []) if n.get("state", "") == "Established"]


def all_bgp_established(neighbors: list[dict]) -> bool:
    """Return True if all neighbors are Established and list is non-empty."""
    if not neighbors:
        return False
    return all(n.get("state", "") == "Established" for n in neighbors)


def any_bgp_down(neighbors: list[dict]) -> bool:
    """Return True if any neighbor is not Established."""
    return any(n.get("state", "") != "Established" for n in (neighbors or []))


# ─── VRF parsing ─────────────────────────────────────────────────────────────

def parse_vrf_list(show_vrf_output: str) -> list[str]:
    """Parse show vrf output and return list of VRF names."""
    vrfs: list[str] = []
    for line in (show_vrf_output or "").splitlines():
        line_s = line.strip()
        if not line_s or re.match(r"^Name\s+Default", line_s, re.IGNORECASE):
            continue
        parts = line_s.split()
        if parts and not parts[0].startswith("-"):
            vrfs.append(parts[0])
    return vrfs


# ─── Interface identification ─────────────────────────────────────────────────

def parse_neighbor_interface(
    ip_brief_output: str,
    bgp_config_output: str,
    int_desc_output: str,
    down_neighbors: list[dict],
) -> list[dict]:
    """Identify interface for each down BGP neighbor and classify LAN or WAN.

    Returns list of dicts: [{neighbor_ip, interface, ip_address, peer_type}]
    peer_type is 'LAN' or 'WAN' based on interface description keywords.
    """
    wan_keywords = re.compile(
        r"wan|mpls|internet|isp|circuit|biz|transport|vpn0|ge0|t1|ds|serial",
        re.IGNORECASE,
    )
    results: list[dict] = []
    ip_to_intf: dict[str, str] = {}

    for line in (ip_brief_output or "").splitlines():
        line_s = line.strip()
        m = re.match(r"^(\S+)\s+(\d+\.\d+\.\d+\.\d+)\s+YES", line_s)
        if m:
            ip_to_intf[m.group(2)] = m.group(1)

    intf_desc: dict[str, str] = {}
    for line in (int_desc_output or "").splitlines():
        line_s = line.strip()
        parts = line_s.split(None, 2)
        if len(parts) >= 3 and not re.match(r"^Interface|^-", parts[0], re.IGNORECASE):
            intf_desc[parts[0]] = parts[2]

    for neighbor in (down_neighbors or []):
        n_ip = neighbor.get("neighbor_ip", "")
        matched_intf = ""
        matched_local_ip = ""

        n_parts = n_ip.split(".")
        if len(n_parts) == 4:
            n_subnet = ".".join(n_parts[:3])
            for local_ip, intf in ip_to_intf.items():
                l_parts = local_ip.split(".")
                if len(l_parts) == 4 and ".".join(l_parts[:3]) == n_subnet:
                    matched_intf = intf
                    matched_local_ip = local_ip
                    break

        desc = intf_desc.get(matched_intf, "")
        peer_type = "WAN" if wan_keywords.search(desc) else "LAN"

        results.append(
            {
                "neighbor_ip": n_ip,
                "interface": matched_intf,
                "local_ip": matched_local_ip,
                "description": desc,
                "peer_type": peer_type,
            }
        )
    return results


# ─── Interface state parsing ──────────────────────────────────────────────────

def parse_interface_status(output: str, interface_name: str) -> str:
    """Return 'up', 'down', 'admin-down', or 'unknown' for named interface."""
    pattern = re.escape(interface_name)
    for line in (output or "").splitlines():
        if re.search(pattern, line, re.IGNORECASE):
            low = line.lower()
            if "admin" in low and "down" in low:
                return "admin-down"
            if "down" in low:
                return "down"
            if "up" in low:
                return "up"
    return "unknown"


# ─── Ping result parsing ──────────────────────────────────────────────────────

def parse_ping_result(output: str) -> bool:
    """Return True if ping shows 0% packet loss or 100% success rate."""
    out = output or ""
    return bool(re.search(r"\b0% packet loss", out)) or "Success rate is 100" in out


# ─── Assure1 alarm evaluation ─────────────────────────────────────────────────

def evaluate_assure1_cleared(assure1_response: Any) -> bool:
    """Return True if Assure1 alarm is cleared based on API response.

    Covers both known Assure1 response formats.
    """
    if not assure1_response:
        return True
    if isinstance(assure1_response, dict):
        if not assure1_response.get("success", True):
            return True
        data = assure1_response.get("data", [])
        if not data:
            return True
        if any(
            str(item.get("Severity", "")).lower() == "normal" for item in data
        ):
            return True
    return False


# ─── vManage alarm evaluation ─────────────────────────────────────────────────

def filter_vmanage_alarms(
    alarms_data: list[dict], hostname: str, alarm_name: str = "BGP"
) -> list[dict]:
    """Filter vManage alarm list to those matching hostname and alarm type."""
    matched: list[dict] = []
    for alarm in alarms_data or []:
        values = alarm.get("values", [{}])
        if isinstance(values, list) and values:
            values = values[0]
        host = values.get("host-name", "")
        rule = alarm.get("rule_name_display", "")
        if hostname.lower() in host.lower() and alarm_name.lower() in rule.lower():
            matched.append(
                {
                    "uuid": alarm.get("uuid", ""),
                    "host_name": host,
                    "rule_name": rule,
                    "active": alarm.get("active", True),
                    "cleared": alarm.get("cleared", False),
                    "raw": alarm,
                }
            )
    return matched


def extract_alarm_uuids(filtered_alarms: list[dict]) -> list[str]:
    """Extract UUID list from filtered vManage alarms."""
    return [a["uuid"] for a in (filtered_alarms or []) if a.get("uuid")]


# ─── FilterModule entry point ─────────────────────────────────────────────────

class FilterModule:
    """Ansible filter plugin entry point."""

    def filters(self) -> dict:
        """Return filter function map."""
        return {
            "detect_platform": detect_platform,
            "extract_text_field": extract_text_field,
            "extract_assure1_alarm_id": extract_assure1_alarm_id,
            "extract_hostname_from_summary": extract_hostname_from_summary,
            "extract_neid_from_summary": extract_neid_from_summary,
            "extract_ip_from_summary": extract_ip_from_summary,
            "parse_bgp_neighbors": parse_bgp_neighbors,
            "get_down_neighbors": get_down_neighbors,
            "get_up_neighbors": get_up_neighbors,
            "all_bgp_established": all_bgp_established,
            "any_bgp_down": any_bgp_down,
            "parse_vrf_list": parse_vrf_list,
            "parse_neighbor_interface": parse_neighbor_interface,
            "parse_interface_status": parse_interface_status,
            "parse_ping_result": parse_ping_result,
            "evaluate_assure1_cleared": evaluate_assure1_cleared,
            "filter_vmanage_alarms": filter_vmanage_alarms,
            "extract_alarm_uuids": extract_alarm_uuids,
        }
