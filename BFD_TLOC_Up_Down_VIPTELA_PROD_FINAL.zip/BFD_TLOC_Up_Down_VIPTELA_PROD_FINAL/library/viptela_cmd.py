#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Ansible custom module — run commands on Cisco vEdge/cEdge via Netmiko.

Bypasses ansible_connection entirely. Runs on the Ansible controller
(delegate_to: localhost) and connects directly to the device via Netmiko.
Supports old SSH algorithms required by Cisco vEdge (vtedge 20.12.x).
"""

from __future__ import annotations

from ansible.module_utils.basic import AnsibleModule

try:
    from netmiko import ConnectHandler
    HAS_NETMIKO = True
except ImportError:
    HAS_NETMIKO = False


VIPTELA_SSH_CONFIG = {
    "disabled_algorithms": {
        "kex": [],
        "pubkeys": [],
    },
    "conn_timeout": 30,
    "auth_timeout": 30,
    "banner_timeout": 30,
    "blocking_timeout": 180,
}

DEVICE_TYPE_MAP = {
    "vedge":  "cisco_ios",
    "ios_xe": "cisco_ios",
    "ios":    "cisco_ios",
}


def run_module() -> None:
    module_args = dict(
        host=dict(type="str", required=True),
        username=dict(type="str", required=True),
        password=dict(type="str", required=True, no_log=True),
        device_type=dict(type="str", default="cisco_ios"),
        commands=dict(type="list", elements="str", required=True),
        timeout=dict(type="int", default=180),
        secret=dict(type="str", default="", no_log=True),
    )

    result = dict(changed=False, stdout=[], stdout_lines=[], failed=False)
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)

    if not HAS_NETMIKO:
        module.fail_json(msg="netmiko is not installed on the Ansible controller.")

    raw_device_type = module.params["device_type"]
    device_type = DEVICE_TYPE_MAP.get(raw_device_type, raw_device_type)

    connection_params = {
        "device_type": device_type,
        "host": module.params["host"],
        "username": module.params["username"],
        "password": module.params["password"],
        "secret": module.params["secret"],
        "conn_timeout": module.params["timeout"],
        "auth_timeout": 30,
        "banner_timeout": 30,
        "blocking_timeout": module.params["timeout"],
        # Legacy SSH algorithm support for vEdge 20.12.x
        "disabled_algorithms": {"pubkeys": ["rsa-sha2-256", "rsa-sha2-512"]},
    }

    try:
        net_connect = ConnectHandler(**connection_params)

        stdout_list = []
        stdout_lines_list = []

        for cmd in module.params["commands"]:
            output = net_connect.send_command(
                cmd,
                read_timeout=module.params["timeout"],
                strip_prompt=True,
                strip_command=True,
            )
            stdout_list.append(output)
            stdout_lines_list.append(output.splitlines())

        net_connect.disconnect()

        result["stdout"] = stdout_list
        result["stdout_lines"] = stdout_lines_list
        module.exit_json(**result)

    except Exception as exc:
        module.fail_json(msg=str(exc), **result)


if __name__ == "__main__":
    run_module()
