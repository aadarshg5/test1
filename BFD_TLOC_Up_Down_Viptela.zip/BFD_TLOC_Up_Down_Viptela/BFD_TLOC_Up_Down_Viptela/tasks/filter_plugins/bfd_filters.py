"""
Ansible filter plugin: BFD TLOC Up/Down — Viptela SD-WAN.
All parsing logic lives here; playbook tasks remain clean.
"""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

import re
from datetime import datetime, timedelta
from typing import Any


# ---------------------------------------------------------------------------
# Problem Summary parsers
# ---------------------------------------------------------------------------

def parse_problem_summary(raw: str) -> dict:
    """Parse the iAutomate Problem Summary string into a structured dict."""
    result = {
        "incident_start_time": "",
        "neid": "",
        "hostname": "",
        "ip_address": "",
        "product_type": "",
        "equipment_type": "",
        "incident_type": "",
        "assure1_alarm_id": "",
        "text": "",
    }
    if not raw:
        return result
    field_map = {
        r"INCIDENT START TIME\s*:\s*(.+)": "incident_start_time",
        r"NEID\s*:\s*(\S+)": "neid",
        r"HOSTNAME\s*:\s*(\S+)": "hostname",
        r"IP ADDRESS\s*:\s*(\S+)": "ip_address",
        r"PRODUCT TYPE\s*:\s*(.+)": "product_type",
        r"EQUIPMENT TYPE\s*:\s*(.+)": "equipment_type",
        r"INCIDENT TYPE\s*:\s*(.+)": "incident_type",
        r"ASSURE1 ALARM ID\s*:\s*(\S+)": "assure1_alarm_id",
        r"TEXT\s*:\s*(.+)": "text",
    }
    for pattern, key in field_map.items():
        match = re.search(pattern, raw, re.IGNORECASE)
        if match:
            result[key] = match.group(1).strip()
    return result


def extract_tloc_color(raw: str) -> str:
    """Extract TLOC color from Problem Summary TEXT field.

    TEXT: All BFD sessions for the tloc are down- public-internet spdway-...
    Returns: 'public-internet'
    """
    if not raw:
        return ""
    text_match = re.search(r"TEXT\s*:\s*(.+)", raw, re.IGNORECASE)
    if not text_match:
        return ""
    text = text_match.group(1)
    color_match = re.search(r"down[-\s]+(\S+)", text, re.IGNORECASE)
    return color_match.group(1).strip().rstrip(",.:;") if color_match else ""


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

def detect_platform(show_version_output: str) -> str:
    """Detect vEdge or cEdge from show version output.

    cEdge (IOS-XE SD-WAN): contains 'uptime' or 'image' keywords.
    vEdge (Viptela OS): does not contain those keywords.
    Returns: 'vedge' or 'cedge'
    """
    if not show_version_output:
        return "vedge"
    lower = show_version_output.lower()
    if "uptime" in lower or "cisco ios" in lower or "ios-xe" in lower:
        return "cedge"
    return "vedge"


# ---------------------------------------------------------------------------
# BFD session parsers
# ---------------------------------------------------------------------------

def parse_bfd_sessions(raw_output: Any, color: str) -> list:
    """Parse BFD sessions from show bfd sessions or show sdwan bfd sessions output.

    Returns list of dicts: [{peer, state, color, src_ip, dst_ip}]
    """
    sessions = []
    if not raw_output or not color:
        return sessions

    # Accept either a dict (module output) or a plain string
    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    color_lower = color.lower()
    for line in text.splitlines():
        line_lower = line.lower()
        if color_lower not in line_lower:
            continue
        # Skip header lines
        if re.search(r"^\s*(system|peer|src|dst|local|remote|--)", line, re.IGNORECASE):
            continue

        state = "unknown"
        if re.search(r"\bup\b", line_lower):
            state = "up"
        elif re.search(r"\bdown\b", line_lower):
            state = "down"

        # Extract IPs: first and second IPv4 on line
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        src_ip = ips[0] if len(ips) > 0 else ""
        dst_ip = ips[1] if len(ips) > 1 else ""
        peer = ips[0] if ips else ""

        sessions.append({
            "peer": peer,
            "state": state,
            "color": color,
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "raw_line": line.strip(),
        })
    return sessions


def parse_bfd_history(raw_output: Any, color: str) -> list:
    """Parse BFD history entries for state transition tracking.

    Returns list of dicts: [{timestamp, state, color}]
    """
    history = []
    if not raw_output or not color:
        return history

    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    color_lower = color.lower()
    # Timestamp patterns: 2024-10-30 19:39:07 or Oct 30 19:39:07
    ts_pattern = re.compile(
        r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}|\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})"
    )

    for line in text.splitlines():
        if color_lower not in line.lower():
            continue
        ts_match = ts_pattern.search(line)
        state = "unknown"
        if re.search(r"\bup\b", line, re.IGNORECASE):
            state = "up"
        elif re.search(r"\bdown\b", line, re.IGNORECASE):
            state = "down"
        history.append({
            "timestamp": ts_match.group(1).strip() if ts_match else "",
            "state": state,
            "raw_line": line.strip(),
        })
    return history


def is_flapping(history: list, window_minutes: int = 60) -> bool:
    """Return True if BFD state changed more than once in the given window.

    Uses the last N entries if timestamps cannot be parsed.
    """
    if not history:
        return False

    # Try to parse timestamps and filter to window
    cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
    windowed = []
    for entry in history:
        ts_str = entry.get("timestamp", "")
        parsed = None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%b %d %H:%M:%S"):
            try:
                parsed = datetime.strptime(ts_str, fmt)
                if fmt == "%b %d %H:%M:%S":
                    parsed = parsed.replace(year=datetime.utcnow().year)
                break
            except ValueError:
                continue
        if parsed and parsed >= cutoff:
            windowed.append(entry)

    # Fall back to last 10 entries if timestamps unparseable
    if not windowed:
        windowed = history[-10:]

    transitions = sum(
        1 for i in range(1, len(windowed))
        if windowed[i]["state"] != windowed[i - 1]["state"]
    )
    return transitions > 1


# ---------------------------------------------------------------------------
# Control connections parser
# ---------------------------------------------------------------------------

def parse_control_connections(raw_output: Any, platform: str) -> dict:
    """Parse show control connections / show sdwan control connections.

    Returns: {up: [list of peer dicts], down: [list of peer dicts]}
    """
    result = {"up": [], "down": []}
    if not raw_output:
        return result

    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    for line in text.splitlines():
        if re.search(r"^\s*(system|peer|type|remote|local|--|\s*$)", line, re.IGNORECASE):
            continue
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        if not ips:
            continue
        peer_entry = {"peer": ips[0], "raw_line": line.strip()}
        if re.search(r"\bup\b", line, re.IGNORECASE):
            result["up"].append(peer_entry)
        elif re.search(r"\bdown\b", line, re.IGNORECASE):
            result["down"].append(peer_entry)
    return result


# ---------------------------------------------------------------------------
# Local properties parser
# ---------------------------------------------------------------------------

def parse_local_properties(raw_output: Any, color: str) -> dict:
    """Parse show control local-properties / show sdwan control local-properties.

    Returns: {pub_ip, priv_ip, color}
    Compares public and private IPs to determine if TLOC terminates locally.
    """
    result = {"pub_ip": "", "priv_ip": "", "color": color}
    if not raw_output:
        return result

    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    color_lower = color.lower()
    in_color_block = False

    for line in text.splitlines():
        if color_lower in line.lower():
            in_color_block = True
        if not in_color_block:
            continue

        pub_match = re.search(r"public[- _]ip\s*[:\s]+(\d{1,3}(?:\.\d{1,3}){3})", line, re.IGNORECASE)
        priv_match = re.search(r"private[- _]ip\s*[:\s]+(\d{1,3}(?:\.\d{1,3}){3})", line, re.IGNORECASE)

        if pub_match:
            result["pub_ip"] = pub_match.group(1)
        if priv_match:
            result["priv_ip"] = priv_match.group(1)

        # Stop after we have both
        if result["pub_ip"] and result["priv_ip"]:
            break

    return result


# ---------------------------------------------------------------------------
# Interface status parser
# ---------------------------------------------------------------------------

def parse_interface_status(raw_output: Any, color: str) -> dict:
    """Parse show interface / show sdwan interface for TLOC-bearing interface.

    Returns: {name, state, pub_ip, priv_ip}
    """
    result = {"name": "", "state": "unknown", "pub_ip": "", "priv_ip": ""}
    if not raw_output:
        return result

    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    # Look for interface block containing the color or 'biz-internet' / 'public' keywords
    color_lower = color.lower().replace("-", "[ -]?")
    iface_match = re.search(
        r"(GigabitEthernet\S+|ge-\S+|eth\S+|tunnel\S+|vpn\S+)",
        text, re.IGNORECASE
    )
    if iface_match:
        result["name"] = iface_match.group(1)

    if re.search(r"\bup\b.*\bup\b", text, re.IGNORECASE):
        result["state"] = "up"
    elif re.search(r"\bdown\b", text, re.IGNORECASE):
        result["state"] = "down"

    ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", text)
    if len(ips) >= 1:
        result["pub_ip"] = ips[0]
    if len(ips) >= 2:
        result["priv_ip"] = ips[1]

    return result


# ---------------------------------------------------------------------------
# OMP peers parser
# ---------------------------------------------------------------------------

def parse_omp_peers(raw_output: Any) -> dict:
    """Parse show omp peers / show sdwan omp peers.

    Returns: {up: [peer_ips], down: [peer_ips]}
    """
    result = {"up": [], "down": []}
    if not raw_output:
        return result

    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    for line in text.splitlines():
        if re.search(r"^\s*(peer|system|address|--|\s*$)", line, re.IGNORECASE):
            continue
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        if not ips:
            continue
        if re.search(r"\bup\b", line, re.IGNORECASE):
            result["up"].append(ips[0])
        elif re.search(r"\bdown\b", line, re.IGNORECASE):
            result["down"].append(ips[0])
    return result


# ---------------------------------------------------------------------------
# IPsec tunnel parser
# ---------------------------------------------------------------------------

def parse_ipsec_tunnels(raw_output: Any) -> dict:
    """Parse show sdwan ipsec sa / show tunnel connections.

    Returns: {formed: [tunnel_dicts], missing: [tunnel_dicts]}
    """
    result = {"formed": [], "missing": []}
    if not raw_output:
        return result

    if isinstance(raw_output, dict):
        text = " ".join(str(v) for v in raw_output.values())
    else:
        text = str(raw_output)

    for line in text.splitlines():
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        if not ips:
            continue
        tunnel = {"peer": ips[0], "raw_line": line.strip()}
        lower = line.lower()
        if any(kw in lower for kw in ("established", "up", "active", "ipsec-sa")):
            result["formed"].append(tunnel)
        elif any(kw in lower for kw in ("down", "inactive", "missing", "failed")):
            result["missing"].append(tunnel)
    return result


# ---------------------------------------------------------------------------
# Peer IP extractor
# ---------------------------------------------------------------------------

def extract_peer_ips(bfd_sessions: list) -> list:
    """Extract {src_ip, dst_ip} from list of BFD session dicts (down sessions only)."""
    return [
        {"src_ip": s.get("src_ip", ""), "dst_ip": s.get("dst_ip", "")}
        for s in bfd_sessions
        if s.get("src_ip") and s.get("dst_ip")
    ]


# ---------------------------------------------------------------------------
# Ansible FilterModule registration
# ---------------------------------------------------------------------------

class FilterModule:
    """Register all filters for use in Ansible playbook tasks."""

    def filters(self):
        return {
            "parse_problem_summary": parse_problem_summary,
            "extract_tloc_color": extract_tloc_color,
            "detect_platform": detect_platform,
            "parse_bfd_sessions": parse_bfd_sessions,
            "parse_bfd_history": parse_bfd_history,
            "is_flapping": is_flapping,
            "parse_control_connections": parse_control_connections,
            "parse_local_properties": parse_local_properties,
            "parse_interface_status": parse_interface_status,
            "parse_omp_peers": parse_omp_peers,
            "parse_ipsec_tunnels": parse_ipsec_tunnels,
            "extract_peer_ips": extract_peer_ips,
        }
