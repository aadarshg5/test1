#!/usr/bin/python3
"""Ansible custom module: vManage REST API — alarm query/clear, redundant router lookup, interface bounce."""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

DOCUMENTATION = r"""
module: sdwan_vmanage
short_description: Interact with vManage REST API for SD-WAN alarm and device operations.
options:
  action:
    description: Action to perform.
    required: true
    choices: [query_alarm, clear_alarm, get_redundant_router, bounce_interface]
  system_ip:
    description: Device system/management IP.
    required: true
  alarm_id:
    description: Assure1 alarm ID (required for query_alarm, clear_alarm).
    required: false
  neid:
    description: DNS entity name (required for get_redundant_router, bounce_interface).
    required: false
  interface_name:
    description: Interface name to bounce (required for bounce_interface).
    required: false
"""

import os
import traceback
import subprocess
import re

from ansible.module_utils.basic import AnsibleModule

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def _get_vmanage_output():
    """Invoke the vManage sub-playbook via iAutomate's VCATS_PLAYBOOK env pattern and return output."""
    playbook_id = os.environ.get("VMANAGE_PLAYBOOK_ID", "")
    env_var = f"VCATS_PLAYBOOK_{playbook_id}" if playbook_id else None

    if env_var and os.environ.get(env_var):
        pb_dir = os.environ[env_var]
        working_dir = os.getcwd()
        new_dir = pb_dir.replace("main.sh", "")
        main_file = pb_dir.replace("main.sh", "script.py")

        try:
            os.chdir(new_dir)
            subprocess.Popen(f"/usr/bin/python3.12 {main_file}", shell=True).communicate()
            os.chdir(working_dir)
            out_path = pb_dir.replace("main.sh", "output/output.dat")
            with open(out_path, "r") as fh:
                return fh.read()
        except Exception as exc:
            raise RuntimeError(f"vManage sub-playbook failed: {exc}") from exc
    return None


def query_alarm(system_ip, alarm_id):
    """Check if alarm is still active in vManage."""
    vmanage_out = _get_vmanage_output()
    if vmanage_out is None:
        return {"alarm_active": False, "raw": "vManage sub-playbook not configured"}
    alarm_status = re.search(r"Alarm status:.*", vmanage_out, re.IGNORECASE)
    active = alarm_status is not None and "true" in alarm_status.group().lower()
    return {"alarm_active": active, "raw": vmanage_out[:500]}


def clear_alarm(system_ip, alarm_id):
    """Clear alarm in vManage — delegates to sub-playbook."""
    vmanage_out = _get_vmanage_output()
    cleared = vmanage_out is not None
    return {"cleared": cleared, "raw": (vmanage_out or "")[:500]}


def get_redundant_router(system_ip, neid):
    """Query vManage for redundant router IP using VRRP / system IP lookup."""
    vmanage_out = _get_vmanage_output()
    redundant_ip = ""
    if vmanage_out:
        ip_match = re.search(r"[Rr]edundant.*?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", vmanage_out)
        if ip_match:
            redundant_ip = ip_match.group(1)
    return {"redundant_ip": redundant_ip, "raw": (vmanage_out or "")[:500]}


def bounce_interface(system_ip, neid, interface_name):
    """Trigger interface shut/no-shut via vManage template push."""
    vmanage_out = _get_vmanage_output()
    status = "submitted" if vmanage_out is not None else "vManage sub-playbook not available"
    return {"status": status, "raw": (vmanage_out or "")[:500]}


def main():
    module = AnsibleModule(
        argument_spec=dict(
            action=dict(type="str", required=True,
                        choices=["query_alarm", "clear_alarm", "get_redundant_router", "bounce_interface"]),
            system_ip=dict(type="str", required=True),
            alarm_id=dict(type="str", required=False, default=""),
            neid=dict(type="str", required=False, default=""),
            interface_name=dict(type="str", required=False, default=""),
        ),
        supports_check_mode=False,
    )

    action = module.params["action"]
    system_ip = module.params["system_ip"]
    alarm_id = module.params["alarm_id"]
    neid = module.params["neid"]
    interface_name = module.params["interface_name"]

    try:
        if action == "query_alarm":
            result = query_alarm(system_ip, alarm_id)
        elif action == "clear_alarm":
            result = clear_alarm(system_ip, alarm_id)
        elif action == "get_redundant_router":
            result = get_redundant_router(system_ip, neid)
        elif action == "bounce_interface":
            result = bounce_interface(system_ip, neid, interface_name)
        else:
            module.fail_json(msg=f"Unknown action: {action}")
            return

        module.exit_json(changed=False, **result)

    except RuntimeError as exc:
        module.fail_json(msg=str(exc), traceback=traceback.format_exc())
    except Exception as exc:
        module.fail_json(msg=f"Unexpected error in sdwan_vmanage ({action}): {exc}",
                         traceback=traceback.format_exc())


if __name__ == "__main__":
    main()
