#!/usr/bin/python3
"""Ansible custom module: Assure1 REST API — alarm status query and clear."""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

DOCUMENTATION = r"""
module: sdwan_assure1
short_description: Query and clear alarms in Assure1 monitoring platform.
options:
  action:
    description: Action to perform.
    required: true
    choices: [query, clear]
  alarm_id:
    description: Assure1 alarm event ID.
    required: true
  base_url:
    description: Assure1 base URL e.g. https://146.170.59.26
    required: true
  credentials:
    description: List of credential dicts from host_info['credentials']['assure1'].
    required: true
    no_log: true
"""

import base64
import traceback

from ansible.module_utils.basic import AnsibleModule

try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


_ASSURE1_HOST_HEADER = "pdcc01-asp1.mso.mci.com"


def _get_auth_header(credentials):
    """Find domain-level credentials and return Basic auth header."""
    for cred in credentials:
        if cred.get("level", "").lower() == "domain":
            token = base64.b64encode(f"{cred['username']}:{cred['password']}".encode()).decode()
            return {"Authorization": f"Basic {token}", "Host": _ASSURE1_HOST_HEADER}
    raise RuntimeError("No domain-level Assure1 credentials found in inventory.")


def _make_session(base_url):
    """Create requests session with SNI override for Assure1."""
    session = requests.Session()
    adapter = session.get_adapter("https://")
    if hasattr(adapter, "poolmanager"):
        adapter.poolmanager.connection_pool_kw["server_hostname"] = _ASSURE1_HOST_HEADER
        adapter.poolmanager.connection_pool_kw["assert_hostname"] = _ASSURE1_HOST_HEADER
    return session


def query_alarm(base_url, alarm_id, credentials):
    """Check if alarm is still active in Assure1."""
    headers = _get_auth_header(credentials)
    session = _make_session(base_url)
    url = f"{base_url}/api/event/events/{alarm_id}"
    resp = session.get(url, headers=headers, verify=False, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    active = data.get("success", False)
    return {"alarm_active": active, "alarm_id": alarm_id, "response_code": resp.status_code}


def clear_alarm(base_url, alarm_id, credentials):
    """Clear alarm in Assure1 via API."""
    headers = _get_auth_header(credentials)
    headers["Content-Type"] = "application/json"
    session = _make_session(base_url)
    url = f"{base_url}/api/event/events/{alarm_id}/clear"
    resp = session.post(url, headers=headers, json={"eventId": alarm_id}, verify=False, timeout=30)
    cleared = resp.status_code in (200, 204)
    return {"cleared": cleared, "alarm_id": alarm_id, "response_code": resp.status_code}


def main():
    module = AnsibleModule(
        argument_spec=dict(
            action=dict(type="str", required=True, choices=["query", "clear"]),
            alarm_id=dict(type="str", required=True),
            base_url=dict(type="str", required=True),
            credentials=dict(type="list", elements="dict", required=True, no_log=True),
        ),
        supports_check_mode=False,
    )

    if not HAS_REQUESTS:
        module.fail_json(msg="requests library is required. Install via: pip install requests")

    action = module.params["action"]
    alarm_id = module.params["alarm_id"]
    base_url = module.params["base_url"]
    credentials = module.params["credentials"]

    if not credentials:
        module.exit_json(changed=False, alarm_active=False, cleared=False,
                         msg="No Assure1 credentials provided — skipping.")
        return

    try:
        if action == "query":
            result = query_alarm(base_url, alarm_id, credentials)
        elif action == "clear":
            result = clear_alarm(base_url, alarm_id, credentials)
        else:
            module.fail_json(msg=f"Unknown action: {action}")
            return

        module.exit_json(changed=False, **result)

    except RuntimeError as exc:
        module.fail_json(msg=str(exc), traceback=traceback.format_exc())
    except Exception as exc:
        module.fail_json(msg=f"Unexpected error in sdwan_assure1 ({action}): {exc}",
                         traceback=traceback.format_exc())


if __name__ == "__main__":
    main()
