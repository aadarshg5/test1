#!/bin/sh
# iAutomate legacy stub — execution is driven by main.yaml
