#!/usr/bin/python3
"""Ansible custom module: vManage REST API integration for SD-WAN alarm management.

Alarm clear process per NOC SOP:
  1. UUID is the Assure1 alarm ID from Problem Summary.
  2. Check alarm state: GET /dataservice/alarms/{uuid}
  3. Clear alarm:      POST /dataservice/alarms/clear  body={"uuid": ["<uuid>"]}
  4. Verify cleared:   GET /dataservice/alarms/{uuid}  confirm cleared=true

Redundant router lookup uses the vManage sub-playbook pattern registered on iAutomate.
Interface bounce uses the vManage sub-playbook pattern registered on iAutomate.
"""

from __future__ import absolute_import, division, print_function

__metaclass__ = type

import logging
import os
import re
import subprocess
import traceback

from ansible.module_utils.basic import AnsibleModule

try:
    import requests
    import urllib3

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

DOCUMENTATION = r"""
module: sdwan_vmanage
short_description: vManage REST API — alarm query/clear, redundant router lookup, interface bounce.
options:
  action:
    description: Operation to perform.
    required: true
    choices: [query_alarm, clear_alarm, get_redundant_router, bounce_interface]
  system_ip:
    description: Device management/system IP address.
    required: true
  alarm_id:
    description: Assure1 alarm UUID (used as vManage alarm UUID per NOC SOP).
    required: false
  neid:
    description: DNS entity name — required for get_redundant_router.
    required: false
  interface_name:
    description: Interface to bounce — required for bounce_interface.
    required: false
  vmanage_ip:
    description: vManage IP address for direct REST API calls.
    required: false
  vmanage_user:
    description: vManage API username.
    required: false
    no_log: true
  vmanage_password:
    description: vManage API password.
    required: false
    no_log: true
  vmanage_playbook_id:
    description: iAutomate-registered playbook ID for vManage sub-playbook operations.
    required: true
"""

log = logging.getLogger(__name__)

_SESSION_CACHE: dict = {}


def _get_vmanage_session(vmanage_ip: str, username: str, password: str) -> requests.Session:
    """Establish and cache an authenticated vManage REST session.

    Args:
        vmanage_ip: vManage server IP address.
        username: vManage API username.
        password: vManage API password.

    Returns:
        requests.Session: Authenticated session with XSRF token set.

    Raises:
        RuntimeError: If session authentication fails.
    """
    cache_key = f"{vmanage_ip}:{username}"
    if cache_key in _SESSION_CACHE:
        return _SESSION_CACHE[cache_key]

    session = requests.Session()
    session.verify = False
    base = f"https://{vmanage_ip}"

    try:
        login_resp = session.post(
            f"{base}/j_security_check",
            data={"j_username": username, "j_password": password},
            timeout=30,
        )
        if login_resp.status_code != 200 or "html" in login_resp.text.lower():
            raise RuntimeError(f"vManage login failed — status {login_resp.status_code}")

        token_resp = session.get(f"{base}/dataservice/client/token", timeout=30)
        if token_resp.status_code == 200:
            session.headers.update({"X-XSRF-TOKEN": token_resp.text.strip()})

        _SESSION_CACHE[cache_key] = session
        log.debug("vManage session established for %s", vmanage_ip)
        return session

    except RuntimeError:
        raise
    except Exception as exc:
        log.error("vManage session error for %s: %s", vmanage_ip, exc)
        raise RuntimeError(f"vManage session failed for {vmanage_ip}: {exc}") from exc


def _query_alarm_direct(vmanage_ip: str, username: str, password: str, alarm_uuid: str) -> dict:
    """Query vManage for alarm status using direct REST API.

    Per NOC SOP: GET https://{vManageIP}/dataservice/alarms/{uuid}

    Args:
        vmanage_ip: vManage server IP address.
        username: vManage API username.
        password: vManage API password.
        alarm_uuid: Assure1/vManage alarm UUID.

    Returns:
        dict: {alarm_active: bool, cleared: bool, response_code: int}

    Raises:
        RuntimeError: On authentication or network failure.
    """
    try:
        session = _get_vmanage_session(vmanage_ip, username, password)
        resp = session.get(
            f"https://{vmanage_ip}/dataservice/alarms/{alarm_uuid}",
            timeout=30,
        )
        alarm_active = False
        if resp.status_code == 200:
            data = resp.json()
            cleared = data.get("cleared", False)
            alarm_active = not cleared
            log.debug("vManage alarm %s active=%s", alarm_uuid, alarm_active)
        return {
            "alarm_active": alarm_active,
            "response_code": resp.status_code,
        }
    except RuntimeError:
        raise
    except Exception as exc:
        log.error("vManage query_alarm error for UUID %s: %s", alarm_uuid, exc)
        raise RuntimeError(f"vManage alarm query failed: {exc}") from exc


def _clear_alarm_direct(vmanage_ip: str, username: str, password: str, alarm_uuid: str) -> dict:
    """Clear a vManage alarm using the NOC-documented REST API.

    Per NOC SOP: POST /dataservice/alarms/clear with body {"uuid": ["<uuid>"]}
    Verifies clearance with subsequent GET per NOC SOP final check step.

    Args:
        vmanage_ip: vManage server IP address.
        username: vManage API username.
        password: vManage API password.
        alarm_uuid: Assure1/vManage alarm UUID to clear.

    Returns:
        dict: {cleared: bool, verified: bool, response_code: int}

    Raises:
        RuntimeError: On authentication or network failure.
    """
    try:
        session = _get_vmanage_session(vmanage_ip, username, password)

        clear_resp = session.post(
            f"https://{vmanage_ip}/dataservice/alarms/clear",
            json={"uuid": [alarm_uuid]},
            timeout=30,
        )
        log.debug("vManage clear alarm %s — status %s", alarm_uuid, clear_resp.status_code)

        cleared = clear_resp.status_code in (200, 204)
        if clear_resp.status_code == 200:
            body = clear_resp.json()
            cleared = body if isinstance(body, bool) else body.get("cleared", cleared)

        # NOC SOP final check: verify alarm is now cleared
        verified = False
        if cleared:
            verify_result = _query_alarm_direct(vmanage_ip, username, password, alarm_uuid)
            verified = not verify_result.get("alarm_active", True)
            log.debug("vManage alarm %s verified cleared=%s", alarm_uuid, verified)

        return {
            "cleared": cleared,
            "verified": verified,
            "response_code": clear_resp.status_code,
        }
    except RuntimeError:
        raise
    except Exception as exc:
        log.error("vManage clear_alarm error for UUID %s: %s", alarm_uuid, exc)
        raise RuntimeError(f"vManage alarm clear failed: {exc}") from exc


def _invoke_vmanage_playbook(playbook_id: str) -> tuple:
    """Invoke a registered vManage sub-playbook via iAutomate VCATS_PLAYBOOK env pattern.

    Args:
        playbook_id: iAutomate-registered playbook ID string.

    Returns:
        tuple: (output_text, error_message) — one will be None.
    """
    env_var = f"VCATS_PLAYBOOK_{playbook_id}"
    pb_dir = os.environ.get(env_var)
    if not pb_dir:
        return None, f"Environment variable {env_var} not set — vManage sub-playbook not registered."

    working_dir = os.getcwd()
    try:
        new_dir = pb_dir.replace("main.sh", "")
        main_file = pb_dir.replace("main.sh", "script.py")
        saved_ws = os.environ.get("VCATS_INV_WS", ".")
        os.environ["VCATS_INV_WS"] = "."
        os.chdir(new_dir)
        subprocess.Popen(f"/usr/bin/python3.12 {main_file}", shell=True).communicate()
        os.chdir(working_dir)
        os.environ["VCATS_INV_WS"] = saved_ws
        out_path = pb_dir.replace("main.sh", "output/output.dat")
        with open(out_path, "r") as fh:
            return fh.read(), None
    except Exception as exc:
        os.chdir(working_dir)
        log.error("vManage sub-playbook invocation failed: %s", exc)
        return None, f"vManage sub-playbook invocation failed: {exc}"


def _get_redundant_router(playbook_id: str, system_ip: str, neid: str) -> dict:
    """Retrieve redundant router IP via vManage sub-playbook.

    Args:
        playbook_id: iAutomate-registered vManage playbook ID.
        system_ip: Primary device system/management IP.
        neid: DNS entity name of the primary device.

    Returns:
        dict: {redundant_ip: str, msg: str}
    """
    raw, err = _invoke_vmanage_playbook(playbook_id)
    redundant_ip = ""
    if raw:
        ip_match = re.search(
            r"[Rr]edundant[^:]*?[:\s]+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", raw
        )
        if ip_match:
            redundant_ip = ip_match.group(1)
    return {"redundant_ip": redundant_ip, "msg": err or ""}


def _bounce_interface(playbook_id: str, system_ip: str, neid: str, interface_name: str) -> dict:
    """Bounce a TLOC interface via vManage sub-playbook (template-managed devices).

    Args:
        playbook_id: iAutomate-registered vManage playbook ID.
        system_ip: Device system/management IP.
        neid: DNS entity name.
        interface_name: Interface name to shut/no-shut.

    Returns:
        dict: {status: str}
    """
    raw, err = _invoke_vmanage_playbook(playbook_id)
    status = "submitted" if not err else f"failed: {err}"
    log.debug("Interface bounce for %s/%s: %s", neid, interface_name, status)
    return {"status": status}


def main():
    """Ansible module entry point."""
    module = AnsibleModule(
        argument_spec=dict(
            action=dict(
                type="str", required=True,
                choices=["query_alarm", "clear_alarm", "get_redundant_router", "bounce_interface"],
            ),
            system_ip=dict(type="str", required=True),
            alarm_id=dict(type="str", default=""),
            neid=dict(type="str", default=""),
            interface_name=dict(type="str", default=""),
            vmanage_ip=dict(type="str", default=""),
            vmanage_user=dict(type="str", default="", no_log=True),
            vmanage_password=dict(type="str", default="", no_log=True),
            vmanage_playbook_id=dict(type="str", required=True),
        ),
        supports_check_mode=False,
    )

    if not HAS_REQUESTS:
        module.fail_json(msg="requests library required: pip install requests")

    action = module.params["action"]
    system_ip = module.params["system_ip"]
    alarm_id = module.params["alarm_id"]
    neid = module.params["neid"]
    interface_name = module.params["interface_name"]
    vmanage_ip = module.params["vmanage_ip"]
    vmanage_user = module.params["vmanage_user"]
    vmanage_password = module.params["vmanage_password"]
    playbook_id = module.params["vmanage_playbook_id"]

    try:
        if action == "query_alarm":
            if vmanage_ip and vmanage_user and vmanage_password:
                result = _query_alarm_direct(vmanage_ip, vmanage_user, vmanage_password, alarm_id)
            else:
                result = {"alarm_active": False, "msg": "vManage credentials not provided — skipping direct API query."}

        elif action == "clear_alarm":
            if vmanage_ip and vmanage_user and vmanage_password:
                result = _clear_alarm_direct(vmanage_ip, vmanage_user, vmanage_password, alarm_id)
            else:
                raw, err = _invoke_vmanage_playbook(playbook_id)
                result = {"cleared": err is None, "verified": False, "msg": err or ""}

        elif action == "get_redundant_router":
            result = _get_redundant_router(playbook_id, system_ip, neid)

        elif action == "bounce_interface":
            result = _bounce_interface(playbook_id, system_ip, neid, interface_name)

        else:
            module.fail_json(msg=f"Unknown action: {action}")
            return

        module.exit_json(changed=False, **result)

    except RuntimeError as exc:
        module.fail_json(msg=str(exc), traceback=traceback.format_exc())
    except Exception as exc:
        log.error("Unexpected error in sdwan_vmanage (%s): %s", action, exc)
        module.fail_json(
            msg=f"Unexpected error in sdwan_vmanage ({action}): {exc}",
            traceback=traceback.format_exc(),
        )


if __name__ == "__main__":
    main()
