#!/usr/bin/python3
"""Ansible custom module: vManage REST API via iAutomate sub-playbook pattern."""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

import os
import re
import subprocess
import traceback

from ansible.module_utils.basic import AnsibleModule


def _invoke_vmanage_playbook(playbook_id):
    """Call the registered vManage sub-playbook via iAutomate VCATS_PLAYBOOK env pattern."""
    env_var = f"VCATS_PLAYBOOK_{playbook_id}"
    pb_dir = os.environ.get(env_var)

    if not pb_dir:
        return None, f"Environment variable {env_var} not set — vManage sub-playbook not registered."

    working_dir = os.getcwd()
    try:
        new_dir = pb_dir.replace("main.sh", "")
        main_file = pb_dir.replace("main.sh", "script.py")
        vcats_inv_ws = os.environ.get("VCATS_INV_WS", ".")
        os.environ["VCATS_INV_WS"] = "."
        os.chdir(new_dir)
        subprocess.Popen(f"/usr/bin/python3.12 {main_file}", shell=True).communicate()
        os.chdir(working_dir)
        os.environ["VCATS_INV_WS"] = vcats_inv_ws
        out_path = pb_dir.replace("main.sh", "output/output.dat")
        with open(out_path, "r") as fh:
            return fh.read(), None
    except Exception as exc:
        os.chdir(working_dir)
        return None, f"vManage sub-playbook invocation failed: {exc}"


def _query_alarm(playbook_id, alarm_id):
    raw, err = _invoke_vmanage_playbook(playbook_id)
    if err:
        return {"alarm_active": False, "msg": err}
    alarm_match = re.search(r"Alarm status:\s*(\S+)", raw or "", re.IGNORECASE)
    active = alarm_match is not None and "true" in alarm_match.group(1).lower()
    return {"alarm_active": active, "raw_summary": (raw or "")[:500]}


def _clear_alarm(playbook_id, alarm_id):
    raw, err = _invoke_vmanage_playbook(playbook_id)
    if err:
        return {"cleared": False, "msg": err}
    return {"cleared": True, "raw_summary": (raw or "")[:500]}


def _get_redundant_router(playbook_id, system_ip, neid):
    raw, err = _invoke_vmanage_playbook(playbook_id)
    redundant_ip = ""
    if raw:
        ip_match = re.search(
            r"[Rr]edundant[^:]*?[:\s]+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", raw
        )
        if ip_match:
            redundant_ip = ip_match.group(1)
    return {"redundant_ip": redundant_ip, "msg": err or ""}


def _bounce_interface(playbook_id, system_ip, neid, interface_name):
    raw, err = _invoke_vmanage_playbook(playbook_id)
    status = "submitted" if not err else f"failed: {err}"
    return {"status": status}


def main():
    module = AnsibleModule(
        argument_spec=dict(
            action=dict(
                type="str", required=True,
                choices=["query_alarm", "clear_alarm", "get_redundant_router", "bounce_interface"],
            ),
            system_ip=dict(type="str", required=True),
            alarm_id=dict(type="str", default=""),
            neid=dict(type="str", default=""),
            interface_name=dict(type="str", default=""),
            vmanage_playbook_id=dict(type="str", required=True),
        ),
        supports_check_mode=False,
    )

    action = module.params["action"]
    system_ip = module.params["system_ip"]
    alarm_id = module.params["alarm_id"]
    neid = module.params["neid"]
    interface_name = module.params["interface_name"]
    playbook_id = module.params["vmanage_playbook_id"]

    try:
        if action == "query_alarm":
            result = _query_alarm(playbook_id, alarm_id)
        elif action == "clear_alarm":
            result = _clear_alarm(playbook_id, alarm_id)
        elif action == "get_redundant_router":
            result = _get_redundant_router(playbook_id, system_ip, neid)
        elif action == "bounce_interface":
            result = _bounce_interface(playbook_id, system_ip, neid, interface_name)
        else:
            module.fail_json(msg=f"Unknown action: {action}")
            return

        module.exit_json(changed=False, **result)

    except Exception as exc:
        module.fail_json(
            msg=f"Unexpected error in sdwan_vmanage ({action}): {exc}",
            traceback=traceback.format_exc(),
        )


if __name__ == "__main__":
    main()
