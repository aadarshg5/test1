#!/usr/bin/python3
"""Ansible custom module: Assure1 REST API — alarm query and clear."""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

import base64
import traceback

from ansible.module_utils.basic import AnsibleModule

try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def _get_auth_header(credentials, host_header):
    """Find domain-level credential and return Basic auth header dict."""
    for cred in credentials:
        if cred.get("level", "").lower() == "domain":
            token = base64.b64encode(
                f"{cred['username']}:{cred['password']}".encode()
            ).decode()
            return {"Authorization": f"Basic {token}", "Host": host_header}
    raise RuntimeError("No domain-level Assure1 credential found in inventory.")


def _make_session(base_url, host_header):
    """Create requests session with SNI override for Assure1 IP-based URL."""
    session = requests.Session()
    adapter = session.get_adapter("https://")
    if hasattr(adapter, "poolmanager"):
        adapter.poolmanager.connection_pool_kw["server_hostname"] = host_header
        adapter.poolmanager.connection_pool_kw["assert_hostname"] = host_header
    return session


def _query_alarm(base_url, host_header, alarm_id, credentials):
    headers = _get_auth_header(credentials, host_header)
    session = _make_session(base_url, host_header)
    resp = session.get(
        f"{base_url}/api/event/events/{alarm_id}",
        headers=headers, verify=False, timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return {
        "alarm_active": bool(data.get("success", False)),
        "alarm_id": alarm_id,
        "response_code": resp.status_code,
    }


def _clear_alarm(base_url, host_header, alarm_id, credentials):
    headers = _get_auth_header(credentials, host_header)
    headers["Content-Type"] = "application/json"
    session = _make_session(base_url, host_header)
    resp = session.post(
        f"{base_url}/api/event/events/{alarm_id}/clear",
        headers=headers, json={"eventId": alarm_id}, verify=False, timeout=30,
    )
    return {
        "cleared": resp.status_code in (200, 204),
        "alarm_id": alarm_id,
        "response_code": resp.status_code,
    }


def main():
    module = AnsibleModule(
        argument_spec=dict(
            action=dict(type="str", required=True, choices=["query", "clear"]),
            alarm_id=dict(type="str", required=True),
            base_url=dict(type="str", required=True),
            host_header=dict(type="str", required=True),
            credentials=dict(type="list", elements="dict", required=True, no_log=True),
        ),
        supports_check_mode=False,
    )

    if not HAS_REQUESTS:
        module.fail_json(msg="requests library required: pip install requests")

    action = module.params["action"]
    alarm_id = module.params["alarm_id"]
    base_url = module.params["base_url"]
    host_header = module.params["host_header"]
    credentials = module.params["credentials"]

    if not credentials:
        module.exit_json(
            changed=False, alarm_active=False, cleared=False,
            msg="No Assure1 credentials in inventory — skipping.",
        )
        return

    try:
        if action == "query":
            result = _query_alarm(base_url, host_header, alarm_id, credentials)
        else:
            result = _clear_alarm(base_url, host_header, alarm_id, credentials)

        module.exit_json(changed=False, **result)

    except RuntimeError as exc:
        module.fail_json(msg=str(exc), traceback=traceback.format_exc())
    except Exception as exc:
        module.fail_json(
            msg=f"Unexpected error in sdwan_assure1 ({action}): {exc}",
            traceback=traceback.format_exc(),
        )


if __name__ == "__main__":
    main()
