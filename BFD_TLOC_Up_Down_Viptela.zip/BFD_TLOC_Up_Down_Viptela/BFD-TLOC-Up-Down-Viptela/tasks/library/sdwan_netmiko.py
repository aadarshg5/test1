#!/usr/bin/python3
"""Ansible custom module: SSH to SD-WAN devices via Netmiko.

Supports direct SSH, VRF-based SSH (cEdge: ssh -l user -vrf 1 IP),
and vshell VPN SSH (vEdge: request execute vpn 1 ssh).
Returns a dict of {command: output} for each command executed.
"""

from __future__ import absolute_import, division, print_function

__metaclass__ = type

import logging
import traceback

from ansible.module_utils.basic import AnsibleModule

try:
    import paramiko
    from hashlib import md5
    from netmiko import ConnectHandler
    from netmiko.exceptions import NetmikoAuthenticationException, NetmikoTimeoutException

    HAS_NETMIKO = True
except ImportError:
    HAS_NETMIKO = False

DOCUMENTATION = r"""
module: sdwan_netmiko
short_description: Run CLI commands on Viptela SD-WAN devices via Netmiko SSH.
options:
  host:
    description: Device management IP address.
    required: true
  username:
    description: SSH username.
    required: true
  password:
    description: SSH password.
    required: true
    no_log: true
  commands:
    description: Ordered list of CLI commands to execute.
    required: true
  platform:
    description: Device platform — vedge or cedge.
    default: cedge
  jump_host:
    description: IP of target device to reach via jump/primary router.
    required: false
  use_vrf_ssh:
    description: When true, login to jump_host through primary router using VRF-aware SSH.
    default: false
  timeout:
    description: SSH read timeout in seconds.
    default: 60
"""

log = logging.getLogger(__name__)


def _bypass_md5_fips() -> None:
    """Patch paramiko PKey for FIPS-compliant hosts that reject MD5."""

    class _FipsPKey(paramiko.PKey):
        def get_fingerprint_improved(self):
            return md5(self.asbytes(), usedforsecurity=False).digest()

    paramiko.PKey.get_fingerprint = _FipsPKey.get_fingerprint_improved


def _build_device_params(host: str, username: str, password: str, timeout: int) -> dict:
    """Build Netmiko ConnectHandler parameter dict.

    Args:
        host: Target device IP address.
        username: SSH username.
        password: SSH password.
        timeout: Read timeout in seconds.

    Returns:
        dict: Netmiko connection parameters.
    """
    return {
        "device_type": "cisco_ios",
        "host": host,
        "username": username,
        "password": password,
        "secret": password,
        "read_timeout_override": timeout,
        "conn_timeout": 15,
    }


def _connect(host: str, username: str, password: str, timeout: int, _md5_patched: bool = False):
    """Establish a Netmiko SSH connection with FIPS MD5 fallback.

    Args:
        host: Target device IP address.
        username: SSH username.
        password: SSH password.
        timeout: Read timeout in seconds.
        _md5_patched: Internal flag — set True after first MD5 patch attempt.

    Returns:
        BaseConnection: Active Netmiko connection object.

    Raises:
        RuntimeError: On authentication failure, timeout, or unrecoverable error.
    """
    try:
        conn = ConnectHandler(**_build_device_params(host, username, password, timeout))
        try:
            conn.enable()
        except Exception:
            pass
        return conn
    except NetmikoAuthenticationException as exc:
        log.error("Authentication failed for %s: %s", host, exc)
        raise RuntimeError(f"Authentication failed for {host}: {exc}") from exc
    except NetmikoTimeoutException as exc:
        log.error("Timeout connecting to %s: %s", host, exc)
        raise RuntimeError(f"Timeout connecting to {host}: {exc}") from exc
    except ValueError as exc:
        if not _md5_patched:
            log.warning("MD5 error on %s — applying FIPS patch and retrying", host)
            _bypass_md5_fips()
            return _connect(host, username, password, timeout, _md5_patched=True)
        log.error("Value error connecting to %s: %s", host, exc)
        raise RuntimeError(f"Connection value error for {host}: {exc}") from exc
    except Exception as exc:
        log.error("Unexpected connection error for %s: %s", host, exc)
        raise RuntimeError(f"Connection failed for {host}: {exc}") from exc


def _run_commands(conn, commands: list, timeout: int) -> dict:
    """Send each command over an active connection and collect outputs.

    Args:
        conn: Active Netmiko connection object.
        commands: Ordered list of CLI command strings.
        timeout: Per-command read timeout in seconds.

    Returns:
        dict: Mapping of {command_string: output_string}.
    """
    results = {}
    for cmd in commands:
        cmd = cmd.strip()
        if not cmd:
            continue
        try:
            output = conn.send_command_timing(cmd, last_read=3.0, read_timeout=timeout)
            results[cmd] = output
            log.debug("Command '%s' executed successfully", cmd)
        except Exception as exc:
            log.error("Error executing command '%s': %s", cmd, exc)
            results[cmd] = f"ERROR: {exc}"
    return results


def _run_via_vedge_vshell(conn, jump_host: str, username: str, password: str,
                           commands: list, timeout: int) -> dict:
    """Execute commands on a vEdge jump target using vshell VPN SSH.

    vEdge login to peer: vshell → request execute vpn 1 ssh -l <user>@<IP>

    Args:
        conn: Active Netmiko connection to the primary vEdge.
        jump_host: IP address of the target vEdge to reach via VPN 1.
        username: SSH username for the target device.
        password: SSH password for the target device.
        commands: CLI commands to run on the target device.
        timeout: Read timeout in seconds.

    Returns:
        dict: Mapping of {command_string: output_string}.

    Raises:
        RuntimeError: If vshell or VPN SSH session fails to establish.
    """
    try:
        conn.send_command_timing("vshell", last_read=2.0)
        conn.send_command_timing(
            f"request execute vpn 1 ssh -l {username}@{jump_host}",
            last_read=5.0
        )
        conn.send_command_timing(password, last_read=5.0)
        results = _run_commands(conn, commands, timeout)
        conn.send_command_timing("exit", last_read=2.0)
        conn.send_command_timing("exit", last_read=2.0)
        return results
    except Exception as exc:
        log.error("vEdge vshell VPN SSH to %s failed: %s", jump_host, exc)
        raise RuntimeError(f"vEdge vshell VPN SSH to {jump_host} failed: {exc}") from exc


def _run_via_cedge_vrf_ssh(conn, jump_host: str, username: str, password: str,
                            commands: list, timeout: int) -> dict:
    """Execute commands on a cEdge jump target using VRF-based SSH.

    cEdge login to peer: ssh -l <username> -vrf 1 <device IP>

    Args:
        conn: Active Netmiko connection to the primary cEdge.
        jump_host: IP address of the target cEdge to reach via VRF 1.
        username: SSH username for the target device.
        password: SSH password for the target device.
        commands: CLI commands to run on the target device.
        timeout: Read timeout in seconds.

    Returns:
        dict: Mapping of {command_string: output_string}.

    Raises:
        RuntimeError: If VRF SSH session fails to establish.
    """
    try:
        conn.send_command_timing(
            f"ssh -l {username} -vrf 1 {jump_host}",
            last_read=5.0
        )
        conn.send_command_timing(password, last_read=5.0)
        results = _run_commands(conn, commands, timeout)
        conn.send_command_timing("exit", last_read=2.0)
        return results
    except Exception as exc:
        log.error("cEdge VRF SSH to %s failed: %s", jump_host, exc)
        raise RuntimeError(f"cEdge VRF SSH to {jump_host} failed: {exc}") from exc


def main():
    """Ansible module entry point."""
    module = AnsibleModule(
        argument_spec=dict(
            host=dict(type="str", required=True),
            username=dict(type="str", required=True),
            password=dict(type="str", required=True, no_log=True),
            commands=dict(type="list", elements="str", required=True),
            platform=dict(type="str", default="cedge", choices=["vedge", "cedge"]),
            jump_host=dict(type="str", default=""),
            use_vrf_ssh=dict(type="bool", default=False),
            timeout=dict(type="int", default=60),
        ),
        supports_check_mode=False,
    )

    if not HAS_NETMIKO:
        module.fail_json(msg="netmiko and paramiko are required: pip install netmiko")

    host = module.params["host"]
    username = module.params["username"]
    password = module.params["password"]
    commands = module.params["commands"]
    platform = module.params["platform"]
    jump_host = module.params["jump_host"]
    use_vrf_ssh = module.params["use_vrf_ssh"]
    timeout = module.params["timeout"]

    conn = None
    try:
        conn = _connect(host, username, password, timeout)

        if use_vrf_ssh and jump_host:
            if platform == "vedge":
                output = _run_via_vedge_vshell(conn, jump_host, username, password, commands, timeout)
            else:
                output = _run_via_cedge_vrf_ssh(conn, jump_host, username, password, commands, timeout)
        else:
            output = _run_commands(conn, commands, timeout)

        module.exit_json(changed=False, output=output)

    except RuntimeError as exc:
        module.fail_json(msg=str(exc), traceback=traceback.format_exc())
    except Exception as exc:
        log.error("Unexpected error in sdwan_netmiko for %s: %s", host, exc)
        module.fail_json(
            msg=f"Unexpected error on {host}: {exc}",
            traceback=traceback.format_exc()
        )
    finally:
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass


if __name__ == "__main__":
    main()
