#!/usr/bin/python3
"""Ansible custom module: SSH to SD-WAN device via Netmiko and run a list of commands."""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

import traceback
from ansible.module_utils.basic import AnsibleModule

try:
    from netmiko import ConnectHandler
    from netmiko.exceptions import NetmikoTimeoutException, NetmikoAuthenticationException
    import paramiko
    from hashlib import md5
    HAS_NETMIKO = True
except ImportError:
    HAS_NETMIKO = False


def _bypass_md5():
    """Bypass MD5 fingerprint check for FIPS-compliant hosts."""
    class _PkeyChild(paramiko.PKey):
        def get_fingerprint_improved(self):
            return md5(self.asbytes(), usedforsecurity=False).digest()
    paramiko.PKey.get_fingerprint = _PkeyChild.get_fingerprint_improved


def _connect(host, username, password, timeout, md5_attempted=False):
    """Establish Netmiko connection with MD5 FIPS fallback."""
    device = {
        "device_type": "cisco_ios",
        "host": host,
        "username": username,
        "password": password,
        "secret": password,
        "read_timeout_override": timeout,
        "conn_timeout": 15,
    }
    try:
        conn = ConnectHandler(**device)
        try:
            conn.enable()
        except Exception:
            pass
        return conn
    except paramiko.AuthenticationException as exc:
        raise RuntimeError(f"Authentication failed for {host}: {exc}") from exc
    except ValueError as exc:
        if not md5_attempted:
            _bypass_md5()
            return _connect(host, username, password, timeout, md5_attempted=True)
        raise RuntimeError(f"Value error connecting to {host}: {exc}") from exc
    except NetmikoTimeoutException as exc:
        raise RuntimeError(f"Timeout connecting to {host}: {exc}") from exc
    except Exception as exc:
        raise RuntimeError(f"Connection failed for {host}: {exc}") from exc


def _run_commands(conn, commands, timeout):
    """Send each command and collect output into a dict."""
    results = {}
    for cmd in commands:
        cmd = cmd.strip()
        if not cmd:
            continue
        try:
            output = conn.send_command_timing(cmd, last_read=3.0, read_timeout=timeout)
            results[cmd] = output
        except Exception as exc:
            results[cmd] = f"ERROR: {exc}"
    return results


def main():
    module = AnsibleModule(
        argument_spec=dict(
            host=dict(type="str", required=True),
            username=dict(type="str", required=True),
            password=dict(type="str", required=True, no_log=True),
            commands=dict(type="list", elements="str", required=True),
            timeout=dict(type="int", default=60),
        ),
        supports_check_mode=False,
    )

    if not HAS_NETMIKO:
        module.fail_json(msg="netmiko and paramiko are required: pip install netmiko")

    host = module.params["host"]
    username = module.params["username"]
    password = module.params["password"]
    commands = module.params["commands"]
    timeout = module.params["timeout"]

    conn = None
    try:
        conn = _connect(host, username, password, timeout)
        output = _run_commands(conn, commands, timeout)
        module.exit_json(changed=False, output=output)
    except RuntimeError as exc:
        module.fail_json(msg=str(exc), traceback=traceback.format_exc())
    except Exception as exc:
        module.fail_json(msg=f"Unexpected error on {host}: {exc}", traceback=traceback.format_exc())
    finally:
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass


if __name__ == "__main__":
    main()
