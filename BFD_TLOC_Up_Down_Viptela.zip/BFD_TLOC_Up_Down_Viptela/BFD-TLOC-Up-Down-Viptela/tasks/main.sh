#!/bin/sh
# iAutomate legacy stub — execution driven by main.yaml
