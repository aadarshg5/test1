"""Ansible filter plugin: BFD-TLOC-Up-Down-Viptela.

All parsing and transformation logic for the BFD TLOC playbook.
Keeps task YAML files clean of any Python logic.
"""

from __future__ import absolute_import, division, print_function

__metaclass__ = type

import logging
import re
from datetime import datetime, timedelta
from typing import Any, Union

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Problem Summary parsers
# ---------------------------------------------------------------------------

def parse_problem_summary(raw: str) -> dict:
    """Parse iAutomate Problem Summary string into a structured dict.

    Args:
        raw: Full Problem Summary text from iAutomate inventory.

    Returns:
        dict: Keyed fields — incident_start_time, neid, hostname, ip_address,
              product_type, equipment_type, incident_type, assure1_alarm_id, text.
    """
    result = {
        "incident_start_time": "", "neid": "", "hostname": "",
        "ip_address": "", "product_type": "", "equipment_type": "",
        "incident_type": "", "assure1_alarm_id": "", "text": "",
    }
    if not raw:
        return result

    try:
        patterns = {
            r"INCIDENT START TIME\s*:\s*(.+)": "incident_start_time",
            r"NEID\s*:\s*(\S+)": "neid",
            r"HOSTNAME\s*:\s*(\S+)": "hostname",
            r"IP ADDRESS\s*:\s*(\S+)": "ip_address",
            r"PRODUCT TYPE\s*:\s*(.+)": "product_type",
            r"EQUIPMENT TYPE\s*:\s*(.+)": "equipment_type",
            r"INCIDENT TYPE\s*:\s*(.+)": "incident_type",
            r"ASSURE1 ALARM ID\s*:\s*(\S+)": "assure1_alarm_id",
            r"TEXT\s*:\s*(.+)": "text",
        }
        for pattern, key in patterns.items():
            match = re.search(pattern, raw, re.IGNORECASE)
            if match:
                result[key] = match.group(1).strip()
    except Exception as exc:
        log.error("parse_problem_summary error: %s", exc)
        raise

    return result


def extract_tloc_color(raw: str) -> str:
    """Extract TLOC color from TEXT field in Problem Summary.

    Pattern: "All BFD sessions for the tloc are down- public-internet ..."
    Returns the word immediately after "down-".

    Args:
        raw: Full Problem Summary text from iAutomate inventory.

    Returns:
        str: TLOC color string e.g. 'public-internet', 'biz-internet', 'mpls'.
    """
    if not raw:
        return ""

    try:
        text_match = re.search(r"TEXT\s*:\s*(.+)", raw, re.IGNORECASE)
        if not text_match:
            return ""
        color_match = re.search(r"down[-\s]+(\S+)", text_match.group(1), re.IGNORECASE)
        return color_match.group(1).strip().rstrip(",.:;") if color_match else ""
    except Exception as exc:
        log.error("extract_tloc_color error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

def detect_platform(show_version_output: str) -> str:
    """Detect vEdge or cEdge from show version output.

    cEdge (IOS-XE SD-WAN): output contains 'uptime', 'cisco ios', or 'ios-xe'.
    vEdge (Viptela OS): none of the above keywords present.

    Args:
        show_version_output: Raw output of 'show version' command.

    Returns:
        str: 'vedge' or 'cedge'.
    """
    if not show_version_output:
        return "vedge"

    try:
        lower = show_version_output.lower()
        if any(kw in lower for kw in ("uptime", "cisco ios", "ios-xe", "xe software")):
            return "cedge"
        return "vedge"
    except Exception as exc:
        log.error("detect_platform error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# Redundant router discovery
# ---------------------------------------------------------------------------

def parse_redundant_router_ip(raw_output: Any, known_redundant_ip: str) -> str:
    """Derive confirmed redundant router IP from VRRP output and LAN odd/even convention.

    Logic per MOP and NOC email:
      1. If known_redundant_ip is populated (from vManage API), validate and return it.
      2. From 'show vrrp detail', extract VRRP group IP of standby router.
      3. From 'show ip interface brief', extract LAN IP. If odd → use next even; if even → use previous odd.
      4. If VRF present (from 'sh vrf'), use ssh -l <user> -vrf 1 <IP> convention (handled in netmiko module).

    Args:
        raw_output: Dict of {command: output} from sdwan_netmiko module.
        known_redundant_ip: IP already identified via vManage API (may be empty).

    Returns:
        str: Confirmed or derived redundant router IP address.
    """
    if known_redundant_ip:
        return known_redundant_ip

    if not raw_output:
        return ""

    try:
        text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)

        # Try VRRP standby IP
        vrrp_match = re.search(r"[Ss]tandby.*?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})", text)
        if vrrp_match:
            return vrrp_match.group(1)

        # LAN odd/even convention: find LAN interface IP and flip odd/even
        lan_ips = re.findall(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.)(\d+)\b", text)
        for prefix, last_octet in lan_ips:
            octet = int(last_octet)
            if 1 <= octet <= 254:
                peer_octet = octet + 1 if octet % 2 != 0 else octet - 1
                return f"{prefix}{peer_octet}"

        return ""
    except Exception as exc:
        log.error("parse_redundant_router_ip error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# BFD session parsers
# ---------------------------------------------------------------------------

def parse_bfd_sessions(raw_output: Any, color: str) -> list:
    """Parse BFD sessions filtered by TLOC color.

    Args:
        raw_output: Dict of {command: output} or plain string from device.
        color: TLOC color to filter sessions by (e.g. 'public-internet').

    Returns:
        list: List of dicts — each with keys: peer, state, color, src_ip, dst_ip.
    """
    sessions = []
    if not raw_output or not color:
        return sessions

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        color_lower = color.lower()

        for line in text.splitlines():
            if color_lower not in line.lower():
                continue
            if re.search(r"^\s*(system.ip|peer|src|dst|local|remote|--)", line, re.IGNORECASE):
                continue

            state = (
                "up" if re.search(r"\bup\b", line, re.IGNORECASE)
                else "down" if re.search(r"\bdown\b", line, re.IGNORECASE)
                else "unknown"
            )
            ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
            sessions.append({
                "peer": ips[0] if ips else "",
                "state": state,
                "color": color,
                "src_ip": ips[0] if len(ips) > 0 else "",
                "dst_ip": ips[1] if len(ips) > 1 else "",
            })
        return sessions
    except Exception as exc:
        log.error("parse_bfd_sessions error for color '%s': %s", color, exc)
        raise


def parse_bfd_history(raw_output: Any, color: str) -> list:
    """Parse BFD history output for state transition tracking.

    Args:
        raw_output: Dict of {command: output} or plain string from device.
        color: TLOC color to filter history by.

    Returns:
        list: List of dicts — each with keys: timestamp, state.
    """
    history = []
    if not raw_output or not color:
        return history

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        ts_pattern = re.compile(
            r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}|\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})"
        )

        for line in text.splitlines():
            if color.lower() not in line.lower():
                continue
            ts_match = ts_pattern.search(line)
            state = (
                "up" if re.search(r"\bup\b", line, re.IGNORECASE)
                else "down" if re.search(r"\bdown\b", line, re.IGNORECASE)
                else "unknown"
            )
            history.append({
                "timestamp": ts_match.group(1).strip() if ts_match else "",
                "state": state,
            })
        return history
    except Exception as exc:
        log.error("parse_bfd_history error for color '%s': %s", color, exc)
        raise


def is_flapping(history: list, window_minutes: int = 60) -> bool:
    """Determine if BFD state changed more than once within the time window.

    Falls back to the last 10 entries when timestamps cannot be parsed.

    Args:
        history: List of {timestamp, state} dicts from parse_bfd_history.
        window_minutes: Look-back window in minutes.

    Returns:
        bool: True if more than one state transition detected within window.
    """
    if not history:
        return False

    try:
        cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
        windowed = []
        for entry in history:
            parsed = None
            for fmt in ("%Y-%m-%d %H:%M:%S", "%b %d %H:%M:%S"):
                try:
                    parsed = datetime.strptime(entry.get("timestamp", ""), fmt)
                    if fmt == "%b %d %H:%M:%S":
                        parsed = parsed.replace(year=datetime.utcnow().year)
                    break
                except ValueError:
                    continue
            if parsed and parsed >= cutoff:
                windowed.append(entry)

        if not windowed:
            windowed = history[-10:]

        transitions = sum(
            1 for i in range(1, len(windowed))
            if windowed[i]["state"] != windowed[i - 1]["state"]
        )
        return transitions > 1
    except Exception as exc:
        log.error("is_flapping error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# Control connections parser
# ---------------------------------------------------------------------------

def parse_control_connections(raw_output: Any, platform: str) -> dict:
    """Parse show control connections / show sdwan control connections output.

    Args:
        raw_output: Dict of {command: output} or plain string from device.
        platform: Device platform — 'vedge' or 'cedge'.

    Returns:
        dict: {up: [peer_dicts], down: [peer_dicts]} — each peer dict has key 'peer'.
    """
    result = {"up": [], "down": []}
    if not raw_output:
        return result

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        for line in text.splitlines():
            if re.search(r"^\s*(system|peer|type|remote|local|--|\s*$)", line, re.IGNORECASE):
                continue
            ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
            if not ips:
                continue
            entry = {"peer": ips[0]}
            if re.search(r"\bup\b", line, re.IGNORECASE):
                result["up"].append(entry)
            elif re.search(r"\bdown\b", line, re.IGNORECASE):
                result["down"].append(entry)
        return result
    except Exception as exc:
        log.error("parse_control_connections error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# Local properties parser
# ---------------------------------------------------------------------------

def parse_local_properties(raw_output: Any, color: str) -> dict:
    """Parse show control local-properties to compare public vs private IP.

    Used to determine if TLOC terminates locally (pub IP == priv IP)
    or on a redundant router (pub IP != priv IP — TLOC extension).

    Args:
        raw_output: Dict of {command: output} or plain string from device.
        color: TLOC color to locate the correct property block.

    Returns:
        dict: {pub_ip: str, priv_ip: str, color: str}
    """
    result = {"pub_ip": "", "priv_ip": "", "color": color}
    if not raw_output:
        return result

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        in_block = False
        for line in text.splitlines():
            if color.lower() in line.lower():
                in_block = True
            if not in_block:
                continue
            pub = re.search(r"public[- _]ip\s*[:\s]+(\d{1,3}(?:\.\d{1,3}){3})", line, re.IGNORECASE)
            priv = re.search(r"private[- _]ip\s*[:\s]+(\d{1,3}(?:\.\d{1,3}){3})", line, re.IGNORECASE)
            if pub:
                result["pub_ip"] = pub.group(1)
            if priv:
                result["priv_ip"] = priv.group(1)
            if result["pub_ip"] and result["priv_ip"]:
                break
        return result
    except Exception as exc:
        log.error("parse_local_properties error for color '%s': %s", color, exc)
        raise


# ---------------------------------------------------------------------------
# Interface status parser
# ---------------------------------------------------------------------------

def parse_interface_status(raw_output: Any, color: str) -> dict:
    """Parse show interface / show sdwan interface for TLOC-bearing interface.

    Args:
        raw_output: Dict of {command: output} or plain string from device.
        color: TLOC color (used for context, not filtering by line).

    Returns:
        dict: {name: str, state: str} — state is 'up' or 'down'.
    """
    result = {"name": "", "state": "unknown"}
    if not raw_output:
        return result

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        iface_match = re.search(
            r"(GigabitEthernet\S+|TenGigabitEthernet\S+|ge-\S+|eth\S+|Tunnel\S+|vpn\S+)",
            text, re.IGNORECASE,
        )
        if iface_match:
            result["name"] = iface_match.group(1)
        result["state"] = (
            "up" if re.search(r"\bline protocol is up\b|\bup\s+up\b", text, re.IGNORECASE)
            else "down"
        )
        return result
    except Exception as exc:
        log.error("parse_interface_status error for color '%s': %s", color, exc)
        raise


# ---------------------------------------------------------------------------
# OMP peers parser
# ---------------------------------------------------------------------------

def parse_omp_peers(raw_output: Any) -> dict:
    """Parse show omp peers / show sdwan omp peers output.

    Args:
        raw_output: Dict of {command: output} or plain string from device.

    Returns:
        dict: {up: [peer_ip_strings], down: [peer_ip_strings]}
    """
    result = {"up": [], "down": []}
    if not raw_output:
        return result

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        for line in text.splitlines():
            if re.search(r"^\s*(peer|system|address|--|\s*$)", line, re.IGNORECASE):
                continue
            ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
            if not ips:
                continue
            if re.search(r"\bup\b", line, re.IGNORECASE):
                result["up"].append(ips[0])
            elif re.search(r"\bdown\b", line, re.IGNORECASE):
                result["down"].append(ips[0])
        return result
    except Exception as exc:
        log.error("parse_omp_peers error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# IPsec tunnel parser
# ---------------------------------------------------------------------------

def parse_ipsec_tunnels(raw_output: Any) -> dict:
    """Parse show sdwan ipsec sa / show tunnel connections output.

    Args:
        raw_output: Dict of {command: output} or plain string from device.

    Returns:
        dict: {formed: [tunnel_dicts], missing: [tunnel_dicts]} — each with key 'peer'.
    """
    result = {"formed": [], "missing": []}
    if not raw_output:
        return result

    try:
        text = (
            " ".join(str(v) for v in raw_output.values())
            if isinstance(raw_output, dict)
            else str(raw_output)
        )
        for line in text.splitlines():
            ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
            if not ips:
                continue
            entry = {"peer": ips[0]}
            lower = line.lower()
            if any(kw in lower for kw in ("established", "ipsec-sa", "active", " up ")):
                result["formed"].append(entry)
            elif any(kw in lower for kw in ("down", "inactive", "missing", "failed")):
                result["missing"].append(entry)
        return result
    except Exception as exc:
        log.error("parse_ipsec_tunnels error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# Peer IP extractor
# ---------------------------------------------------------------------------

def extract_peer_ips(bfd_sessions: list) -> list:
    """Extract source and destination IP pairs from BFD session dicts.

    Args:
        bfd_sessions: List of session dicts from parse_bfd_sessions.

    Returns:
        list: List of {src_ip: str, dst_ip: str} dicts for sessions with both IPs populated.
    """
    try:
        return [
            {"src_ip": s.get("src_ip", ""), "dst_ip": s.get("dst_ip", "")}
            for s in bfd_sessions
            if s.get("src_ip") and s.get("dst_ip")
        ]
    except Exception as exc:
        log.error("extract_peer_ips error: %s", exc)
        raise


# ---------------------------------------------------------------------------
# Ansible FilterModule registration
# ---------------------------------------------------------------------------

class FilterModule:
    """Register all BFD TLOC filter functions for Ansible Jinja2 templates."""

    def filters(self) -> dict:
        """Return mapping of filter name to callable.

        Returns:
            dict: {filter_name: function} for all registered filters.
        """
        return {
            "parse_problem_summary": parse_problem_summary,
            "extract_tloc_color": extract_tloc_color,
            "detect_platform": detect_platform,
            "parse_redundant_router_ip": parse_redundant_router_ip,
            "parse_bfd_sessions": parse_bfd_sessions,
            "parse_bfd_history": parse_bfd_history,
            "is_flapping": is_flapping,
            "parse_control_connections": parse_control_connections,
            "parse_local_properties": parse_local_properties,
            "parse_interface_status": parse_interface_status,
            "parse_omp_peers": parse_omp_peers,
            "parse_ipsec_tunnels": parse_ipsec_tunnels,
            "extract_peer_ips": extract_peer_ips,
        }
