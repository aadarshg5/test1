"""
Ansible filter plugin: BFD-TLOC-Up-Down-Viptela
All parsing logic is here. Playbook tasks stay clean.
"""

from __future__ import absolute_import, division, print_function
__metaclass__ = type

import re
from datetime import datetime, timedelta


def parse_problem_summary(raw: str) -> dict:
    """Parse iAutomate Problem Summary string into a structured dict."""
    result = {
        "incident_start_time": "",
        "neid": "",
        "hostname": "",
        "ip_address": "",
        "product_type": "",
        "equipment_type": "",
        "incident_type": "",
        "assure1_alarm_id": "",
        "text": "",
    }
    if not raw:
        return result
    patterns = {
        r"INCIDENT START TIME\s*:\s*(.+)": "incident_start_time",
        r"NEID\s*:\s*(\S+)": "neid",
        r"HOSTNAME\s*:\s*(\S+)": "hostname",
        r"IP ADDRESS\s*:\s*(\S+)": "ip_address",
        r"PRODUCT TYPE\s*:\s*(.+)": "product_type",
        r"EQUIPMENT TYPE\s*:\s*(.+)": "equipment_type",
        r"INCIDENT TYPE\s*:\s*(.+)": "incident_type",
        r"ASSURE1 ALARM ID\s*:\s*(\S+)": "assure1_alarm_id",
        r"TEXT\s*:\s*(.+)": "text",
    }
    for pattern, key in patterns.items():
        match = re.search(pattern, raw, re.IGNORECASE)
        if match:
            result[key] = match.group(1).strip()
    return result


def extract_tloc_color(raw: str) -> str:
    """Extract TLOC color from TEXT field in Problem Summary.

    Example TEXT: 'All BFD sessions for the tloc are down- public-internet spdway-...'
    Returns: 'public-internet'
    """
    if not raw:
        return ""
    text_match = re.search(r"TEXT\s*:\s*(.+)", raw, re.IGNORECASE)
    if not text_match:
        return ""
    color_match = re.search(r"down[-\s]+(\S+)", text_match.group(1), re.IGNORECASE)
    return color_match.group(1).strip().rstrip(",.:;") if color_match else ""


def detect_platform(show_version_output: str) -> str:
    """Detect vEdge or cEdge from show version output.

    cEdge (IOS-XE SD-WAN): contains 'uptime', 'cisco ios', or 'ios-xe'.
    vEdge (Viptela OS): none of the above.
    Returns: 'vedge' or 'cedge'
    """
    if not show_version_output:
        return "vedge"
    lower = show_version_output.lower()
    if any(kw in lower for kw in ("uptime", "cisco ios", "ios-xe", "xe software")):
        return "cedge"
    return "vedge"


def parse_bfd_sessions(raw_output, color: str) -> list:
    """Parse BFD sessions from show bfd sessions or show sdwan bfd sessions.

    Returns list of dicts: [{peer, state, color, src_ip, dst_ip}]
    """
    sessions = []
    if not raw_output or not color:
        return sessions

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)
    color_lower = color.lower()

    for line in text.splitlines():
        if color_lower not in line.lower():
            continue
        if re.search(r"^\s*(system.ip|peer|src|dst|local|remote|--)", line, re.IGNORECASE):
            continue

        state = "unknown"
        if re.search(r"\bup\b", line, re.IGNORECASE):
            state = "up"
        elif re.search(r"\bdown\b", line, re.IGNORECASE):
            state = "down"

        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        sessions.append({
            "peer": ips[0] if ips else "",
            "state": state,
            "color": color,
            "src_ip": ips[0] if len(ips) > 0 else "",
            "dst_ip": ips[1] if len(ips) > 1 else "",
        })
    return sessions


def parse_bfd_history(raw_output, color: str) -> list:
    """Parse BFD history for state transition tracking.

    Returns list of dicts: [{timestamp, state}]
    """
    history = []
    if not raw_output or not color:
        return history

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)
    ts_pattern = re.compile(
        r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}|\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})"
    )

    for line in text.splitlines():
        if color.lower() not in line.lower():
            continue
        ts_match = ts_pattern.search(line)
        state = "up" if re.search(r"\bup\b", line, re.IGNORECASE) else \
                "down" if re.search(r"\bdown\b", line, re.IGNORECASE) else "unknown"
        history.append({
            "timestamp": ts_match.group(1).strip() if ts_match else "",
            "state": state,
        })
    return history


def is_flapping(history: list, window_minutes: int = 60) -> bool:
    """Return True if BFD state changed more than once within the window."""
    if not history:
        return False

    cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
    windowed = []
    for entry in history:
        parsed = None
        for fmt in ("%Y-%m-%d %H:%M:%S", "%b %d %H:%M:%S"):
            try:
                parsed = datetime.strptime(entry.get("timestamp", ""), fmt)
                if fmt == "%b %d %H:%M:%S":
                    parsed = parsed.replace(year=datetime.utcnow().year)
                break
            except ValueError:
                continue
        if parsed and parsed >= cutoff:
            windowed.append(entry)

    if not windowed:
        windowed = history[-10:]

    transitions = sum(
        1 for i in range(1, len(windowed))
        if windowed[i]["state"] != windowed[i - 1]["state"]
    )
    return transitions > 1


def parse_control_connections(raw_output, platform: str) -> dict:
    """Parse show control connections / show sdwan control connections.

    Returns: {up: [peer_dicts], down: [peer_dicts]}
    """
    result = {"up": [], "down": []}
    if not raw_output:
        return result

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)

    for line in text.splitlines():
        if re.search(r"^\s*(system|peer|type|remote|local|--|\s*$)", line, re.IGNORECASE):
            continue
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        if not ips:
            continue
        entry = {"peer": ips[0]}
        if re.search(r"\bup\b", line, re.IGNORECASE):
            result["up"].append(entry)
        elif re.search(r"\bdown\b", line, re.IGNORECASE):
            result["down"].append(entry)
    return result


def parse_local_properties(raw_output, color: str) -> dict:
    """Parse show control local-properties / show sdwan control local-properties.

    Compares public vs private IP to determine if TLOC terminates locally.
    Returns: {pub_ip, priv_ip, color}
    """
    result = {"pub_ip": "", "priv_ip": "", "color": color}
    if not raw_output:
        return result

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)
    in_block = False

    for line in text.splitlines():
        if color.lower() in line.lower():
            in_block = True
        if not in_block:
            continue
        pub = re.search(r"public[- _]ip\s*[:\s]+(\d{1,3}(?:\.\d{1,3}){3})", line, re.IGNORECASE)
        priv = re.search(r"private[- _]ip\s*[:\s]+(\d{1,3}(?:\.\d{1,3}){3})", line, re.IGNORECASE)
        if pub:
            result["pub_ip"] = pub.group(1)
        if priv:
            result["priv_ip"] = priv.group(1)
        if result["pub_ip"] and result["priv_ip"]:
            break
    return result


def parse_interface_status(raw_output, color: str) -> dict:
    """Parse show interface / show sdwan interface for the TLOC-bearing interface.

    Returns: {name, state}
    """
    result = {"name": "", "state": "unknown"}
    if not raw_output:
        return result

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)

    iface_match = re.search(
        r"(GigabitEthernet\S+|TenGigabitEthernet\S+|ge-\S+|eth\S+|Tunnel\S+|vpn\S+)",
        text, re.IGNORECASE,
    )
    if iface_match:
        result["name"] = iface_match.group(1)

    result["state"] = "up" if re.search(r"\bline protocol is up\b|\bup\s+up\b", text, re.IGNORECASE) else "down"
    return result


def parse_omp_peers(raw_output) -> dict:
    """Parse show omp peers / show sdwan omp peers.

    Returns: {up: [peer_ips], down: [peer_ips]}
    """
    result = {"up": [], "down": []}
    if not raw_output:
        return result

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)

    for line in text.splitlines():
        if re.search(r"^\s*(peer|system|address|--|\s*$)", line, re.IGNORECASE):
            continue
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        if not ips:
            continue
        if re.search(r"\bup\b", line, re.IGNORECASE):
            result["up"].append(ips[0])
        elif re.search(r"\bdown\b", line, re.IGNORECASE):
            result["down"].append(ips[0])
    return result


def parse_ipsec_tunnels(raw_output) -> dict:
    """Parse show sdwan ipsec sa / show tunnel connections.

    Returns: {formed: [tunnel_dicts], missing: [tunnel_dicts]}
    """
    result = {"formed": [], "missing": []}
    if not raw_output:
        return result

    text = " ".join(str(v) for v in raw_output.values()) if isinstance(raw_output, dict) else str(raw_output)

    for line in text.splitlines():
        ips = re.findall(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        if not ips:
            continue
        entry = {"peer": ips[0]}
        lower = line.lower()
        if any(kw in lower for kw in ("established", "ipsec-sa", "active", " up ")):
            result["formed"].append(entry)
        elif any(kw in lower for kw in ("down", "inactive", "missing", "failed")):
            result["missing"].append(entry)
    return result


def extract_peer_ips(bfd_sessions: list) -> list:
    """Extract {src_ip, dst_ip} pairs from down BFD session dicts."""
    return [
        {"src_ip": s.get("src_ip", ""), "dst_ip": s.get("dst_ip", "")}
        for s in bfd_sessions
        if s.get("src_ip") and s.get("dst_ip")
    ]


class FilterModule:
    """Register all BFD TLOC filters for Ansible."""

    def filters(self):
        return {
            "parse_problem_summary": parse_problem_summary,
            "extract_tloc_color": extract_tloc_color,
            "detect_platform": detect_platform,
            "parse_bfd_sessions": parse_bfd_sessions,
            "parse_bfd_history": parse_bfd_history,
            "is_flapping": is_flapping,
            "parse_control_connections": parse_control_connections,
            "parse_local_properties": parse_local_properties,
            "parse_interface_status": parse_interface_status,
            "parse_omp_peers": parse_omp_peers,
            "parse_ipsec_tunnels": parse_ipsec_tunnels,
            "extract_peer_ips": extract_peer_ips,
        }
