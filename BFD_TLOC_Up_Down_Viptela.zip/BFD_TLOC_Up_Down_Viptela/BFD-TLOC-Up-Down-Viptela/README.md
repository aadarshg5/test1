# BFD-TLOC-Up-Down-Viptela

This playbook automates the process of monitoring and troubleshooting BFD TLOC Up/Down alarms on Viptela SD-WAN devices (vEdge and cEdge platforms).

## What it does

- Parses the ETMS/Assure1 alarm to extract TLOC color and alarm metadata
- Performs ICMP reachability and SSH connectivity checks
- Detects platform (vEdge / cEdge) and runs appropriate SD-WAN commands
- Checks BFD session state for the affected TLOC color
- **BFD UP path:** detects flapping → if stable, checks and clears vManage and Assure1 alarms → assigns to NOC for ticket closure
- **BFD DOWN path:** checks control TLOC connections → interface status → TLOC termination → redundant router → scope (single vs all peers) → interface remediation (CLI or vManage template bounce)
- Writes structured output.dat and triggers AVA closure tag if resolved

## Credential requirements

| Type | Source | Usage |
|---|---|---|
| TACACS | iAutomate (ansible_user / ansible_password) | SSH to SD-WAN device |
| Assure1 | iAutomate (credentials.assure1) | Alarm query and clear |

## Configuration

All variables are in `vars/main.yml`. The only value that may need updating before submission is:

```yaml
vmanage_playbook_id: "644989048"
```

Set this to the iAutomate-registered playbook ID of the vManage alarm-clearing playbook on your instance.

## Package structure

```
BFD-TLOC-Up-Down-Viptela/
├── tasks/
│   ├── main.yml                  ← orchestrator
│   ├── initializeRun.yml
│   ├── inputGathering.yml
│   ├── ping.yml
│   ├── deviceSsh.yml
│   ├── bfdCheck.yml
│   ├── bfdUpPath.yml
│   ├── controlTlocCheck.yml
│   ├── interfaceCheck.yml
│   ├── redundantRouter.yml
│   ├── scopeCheck.yml
│   ├── singlePeerPath.yml
│   ├── allPeersPath.yml
│   ├── interfaceRemediation.yml
│   ├── postRemediation.yml
│   ├── alarmClearance.yml
│   ├── writeOutput.yml
│   ├── library/
│   │   ├── sdwan_netmiko.py      ← SSH via Netmiko
│   │   ├── sdwan_vmanage.py      ← vManage sub-playbook integration
│   │   └── sdwan_assure1.py      ← Assure1 REST API
│   └── filter_plugins/
│       └── bfd_filters.py        ← all parsers
└── vars/
    └── main.yml                  ← all global variables
```
