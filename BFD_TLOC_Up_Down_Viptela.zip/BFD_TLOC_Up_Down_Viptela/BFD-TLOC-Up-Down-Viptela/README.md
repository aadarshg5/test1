# BFD-TLOC-Up-Down-Viptela

Automates BFD TLOC Up/Down alarm remediation on Viptela SD-WAN devices (vEdge and cEdge).

## Workflow
1. Parse Problem Summary → extract TLOC color and Assure1 alarm ID
2. Pre-checks → verify Assure1 alarm status
3. Ping and SSH check → platform detection (vEdge/cEdge)
4. BFD session check for affected TLOC color
5. BFD UP path → flap detection → vManage + Assure1 alarm clear → closure
6. BFD DOWN path → control TLOC check → interface check → TLOC termination
7. Redundant router discovery via vManage API
8. Scope: single peer (underlay ping, tunnel stats) or all peers (OMP/IPsec, Tier 2)
9. Interface remediation → CLI or vManage template bounce → post-remediation BFD check
10. Alarm clearance → AVA closure tag or Tier 2 escalation

## Credentials (declared in config.yaml)
- TACACS: ansible_user / ansible_password — SSH to SD-WAN device
- Assure1: credentials.assure1 — alarm query and clear

## Configuration
One value in vars/main.yaml may need updating before submission:
```yaml
vmanage_playbook_id: "644989048"
```
Set to the iAutomate-registered ID of the vManage alarm-clearing playbook on your instance.
