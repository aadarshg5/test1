# BFD-TLOC-Up-Down-Viptela

Automates BFD TLOC Up/Down alarm remediation on Viptela SD-WAN devices (vEdge and cEdge).

## Workflow
1. Initialize run — output.dat header, SSH host trust
2. Input gathering — parse Problem Summary, extract TLOC color, alarm ID, incident type
3. Pre-checks — initialize device results dict, check Assure1 alarm status
4. If alarm is Active in Assure1:
   - Ping check → SSH check → platform detection (vEdge/cEdge)
   - BFD session check for TLOC color
   - BFD UP path → flap detection → vManage alarm clear → ticket closure
   - BFD DOWN path → control TLOC check → interface check → TLOC termination
   - Redundant router discovery → VRF-aware SSH (cEdge: ssh -vrf 1 / vEdge: vshell vpn 1)
   - Scope analysis → single peer or all peers
   - Interface remediation → CLI or vManage template bounce
   - Post-remediation BFD check → alarm clearance → AVA closure tag
5. Write output.dat — AVA tag or Tier 2 escalation note

## Credentials (declared in config.yaml)
- TACACS (CINFO): ansible_user / ansible_password — SSH to SD-WAN device
- Assure1 (credentials.assure1): alarm status check — injected by iAutomate

## Configuration
- `vmanage_playbook_id` in vars/main.yaml — set to iAutomate-registered vManage playbook ID
- `base_url` in vars/main.yaml — Assure1 REST endpoint
