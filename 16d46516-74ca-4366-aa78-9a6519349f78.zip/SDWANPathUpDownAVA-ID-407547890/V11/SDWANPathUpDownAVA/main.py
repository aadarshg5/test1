#!/usr/bin/python3
import sys
sys.dont_write_bytecode = True
import urllib3
urllib3.disable_warnings()
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
from netmiko import ConnectHandler
import concurrent.futures 
from concurrent.futures import ThreadPoolExecutor
import requests
import subprocess
import re
import os
import json
import time
import logging
import datetime
import getpass
import datetime
import urllib3
from requests.exceptions import ReadTimeout
urllib3.disable_warnings()
import urllib.parse
## Added for AS1 Alarm Clearing ##
import base64

def as1_clear(alarm_id):
    as1_enc= ["bW5zbm9jYXBpdXNlcg==", "VmVyaXpvbjEyIQ=="]
    headers = {'Accept': 'application/json'}
    auth = base64.b64decode(as1_enc[0]).decode("utf-8"), base64.b64decode(as1_enc[1]).decode("utf-8")
    s = requests.Session()
    s.get_adapter('https://').poolmanager.connection_pool_kw['server_hostname'] = "pdcc01-asp1.mso.mci.com"
    s.get_adapter('https://').poolmanager.connection_pool_kw['assert_hostname'] = "pdcc01-asp1.mso.mci.com"
    r = s.get(f"https://146.170.59.26/api/event/tools/executeSQLTool/3?Events={alarm_id}", headers={"Host": "pdcc01-asp1.mso.mci.com", "Accept": "application/json"}, verify=False, auth=auth)
    r.close()
    status = "N/A"
    updated_row = "N/A"
    data = r.json()
    if 'success' in data:
        if data['success'] == True:
            status = 'success'
        else:
            status = 'failed'
    if 'message' in data:
        pattern = r'modified\s+(\d+)\s+rows'
        match = re.search(pattern, data['message'])
        if match:
            updated_row = int(match.group(1))
    return status, updated_row

## END for AS1 Alarm Clearing ##

class BreakException(Exception):
    def __init__(self, message="Custom exception occurred"):
        self.message = message
        super().__init__(self.message)

## IMPORT THE VARIABLES FROM THE ENVIRONMENT ( DO NOT EDIT)
if 'VCATS_INV_WS' in os.environ:
    path = os.environ['VCATS_INV_WS'] ## IMPORT VCATS PATH / FOLDER
    audit_log_filename = f'{path}/output/logs.dat'
    debug_log_filename = f'{path}/errors.log'
else:
    print("Error: 'VCATS_INV_WS' is not present in the environment\n   > Closing program.")
    sys.exit()

if 'TAC_USER' in os.environ:
    uname = os.environ['TAC_USER'] ## IMPORT USERNAME
else:
    print("Error: 'TAC_USER' is not present in the environment\n   > Closing program.")
    sys.exit()

if 'TAC_PW_ENC' in os.environ:
    encps = os.environ['TAC_PW_ENC'] ## IMPORT ENCRYPTED PASSWORD
else:
    print("Error: 'TAC_PW_ENC' is not present in the environment\n   > Closing program.")
    sys.exit()

if 'CINFO_USERS' in os.environ:
    cinfo_uname = os.environ['CINFO_USERS'] ## IMPORT CINFO USERNAMES
else:
    print("Error: 'CINFO_USERS' is not present in the environment\n   > Closing program.")
    sys.exit()

if 'CINFO_ENC' in os.environ:
    cinfo_encpass = os.environ['CINFO_ENC'] ## IMPORT CINFO ENCRYPTED PASSWORD
else:
    print("Error: 'CINFO_ENC' is not present in the environment\n   > Closing program.")
    sys.exit()

if 'VCATS_PROBLEM' in os.environ:
    problem = os.environ['VCATS_PROBLEM'] ## IMPORT PROBLEM SUMMARY
else:
    print("Error: 'VCATS_PROBLEM' is not present in the environment\n   > Closing program.")
    sys.exit()

if 'DNS_ENTITY' in os.environ:
    dns_entity = os.environ['DNS_ENTITY'] ## IMPORT DNS_ENTITY
else:
    print("Error: 'DNS_ENTITY' is not present in the environment.\n   > Closing program.")
    sys.exit()

if 'DOMAIN' in os.environ:
    domain = os.environ['DOMAIN'] ## IMPORT DNS_ENTITY
else:
    print("Error: 'DOMAIN is not present in the environment.\n   > Closing program.")
    sys.exit()

if 'VCATS_DEVICE_ATTRS_BASE_URL' in os.environ:
    esp_api_url = os.environ['VCATS_DEVICE_ATTRS_BASE_URL'] ## IMPORT DNS_ENTITY
else:
    print("Error: 'VCATS_DEVICE_ATTRS_BASE_URL' is not present in the environment.\n   > Closing program.")
    sys.exit()
## END OF IMPORT THE VARIABLES FROM THE ENVIRONMENT
current_datetime = datetime.datetime.now()
formatted_datetime = current_datetime.strftime("%Y-%m-%d_%H-%M-%S")
### TIME AND DATE
currentdate = os.popen('date \'+%Y-%m-%d'" "'%H:%M:%S\'').readlines()
strcdate = ''.join(currentdate)
strcdate = strcdate.strip()
### TIME AND DATE FOR FILENAME
currentdate_for_filename = os.popen('date \'+%Y%m%d%H%M%S\'').readlines()
strfilename = ''.join(currentdate_for_filename)
strfilename = strfilename.strip()
user_run = getpass.getuser() ### GET USERNAME OF THE USER ON CMDS
# INITIALIZE LOGGING ###
logger = logging.getLogger('Automated Script')
ch = logging.StreamHandler(sys.stdout)
ch.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)
#########################
ch = logging.FileHandler(debug_log_filename)
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)
logger.setLevel(logging.DEBUG)
############################
audit_logger = logging.getLogger('Audit trail')
ch = logging.FileHandler(audit_log_filename)
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(levelname)s %(message)s')
ch.setFormatter(formatter)
audit_logger.addHandler(ch)
audit_logger.setLevel(logging.DEBUG)
############################
# logger.debug("TEST - logger.debug")
# audit_logger.error("TEST - audit_logger.error")
# audit_logger.info("TEST - audit_logger.info") ## For output
## logger.debug >> errors.log
## audit_logger.error >> stdout.log
## audit_logger.info >> stdout.log
## DECRYPT THE PASSWORD ENTERED ( DO NOT EDIT)
def dec_pass(encpass):
    secret_file = f"{path}/secret.txt"
    cmd = ["openssl", "aes-256-cbc", "-d", "-a", "-pass", f"file:{secret_file}"]
    p1 = subprocess.Popen(["echo", encpass],stdout=subprocess.PIPE)
    p2 = subprocess.check_output(cmd, stdin=p1.stdout)
    p3 = p2.decode().strip()
    return p3

## CONVERT PROBLEM SUMMARY INTO A DICT VARIABLE ( DO NOT EDIT)
global_obs = "Observation:\n"
global_npoa = "Next Plan of Action:\n"
global_peer = []

def update_final_string(type, new_line):
    global global_obs
    global global_npoa
    if type == 'obs':
        if global_obs:
            global_obs += f"\t- {new_line}\n"
        else:
            global_obs = f"\t- {new_line}\n"
    elif type == 'npoa':
        if global_npoa:
            global_npoa += f"\t- {new_line}\n"
        else:
            global_npoa = f"\t- {new_line}\n"

# def prob_summ_dict(problem):
#     problem_dict = {}
#     lines = problem.split('\n')
#     for line in lines:
#         key_value = line.split(': ')
#         if len(key_value) == 2:
#             key = key_value[0]
#             value = key_value[1]
#             problem_dict[key] = value
#     return problem_dict

def prob_summ_dict(problem):
    problem_dict = {}
    lines = problem.split('\n')
    for line in lines:
        key_value = line.split(': ')
        if len(key_value) >= 2:
            key = key_value[0]
            if len(key_value) == 2:
                value = key_value[1]
            elif len(key_value) >= 3:
                value = key_value[-1]
            else:
                value = ''
            problem_dict[key] = value
    return problem_dict

def remove_some_strings(output):
    if '--- WARNING' in output:
        output = output.split('--- WARNING')[0].strip()
    lines = output.split('\n')
    lines = [line for line in lines if '[ok][' not in line and 'cli>' not in line and '~] $' not in line and '[error][' not in line and '~] #' not in line and 'free -h' not in line and 'logout' not in line and 'shell' not in line and 'display json' not in line and 'last-n 100' not in line and '| match' not in line and '| display' not in line and 'Caught' not in line and ':~$' not in line and 'grep' not in line ]
    new_output = '\n'.join(lines)
    return new_output 

def api_esp_dns(device_type, shortName, dns):
    url = f"{esp_api_url}inventory-search"
    devices = []
    params = {
        'invlvl': 'OPS',
        'shortName': shortName,
        'pageSize': 100,
        'dnsEntityName': dns,
        'deviceType': device_type
        
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        devices = data['devices']
    return devices

def api_esp(device_type, shortName, url):
    devices = []
    params = {
        'invlvl': 'OPS',
        'shortName': shortName,
        'pageSize': 1000000,
        'deviceType': device_type
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        devices = data['devices']
    return devices

def api_esp_list(device_types, shortName, url):
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(api_esp, device_type, shortName, url): device_type for device_type in device_types}
        for future in concurrent.futures.as_completed(futures):
            device_list = future.result(timeout=600)
            results += device_list
    return results

def get_neid(hostname):
    devices = []
    neid = ''
    url = f"{esp_api_url}inventory-search"
    if 'wbacntrl' in hostname.lower():
        shortName = 'wbacntrl'
        dev_types = ['Versa SDWAN Controller']
        devices = api_esp_list(dev_types, shortName, url)
    else:
        shortName = dns_entity.split("-")[0]
        dev_types = ['Versa SDWAN Controller','Router', 'Versa SD-WAN VM']
        devices = api_esp_list(dev_types, shortName, url)
    if devices:
        for device in devices:
            if hostname.lower() == device['device'].get('entityHostName', '').lower():
                neid = device['device'].get('dnsEntityName', 'N/A-1')
                break
    else:
        neid = "N/A-2"
    return neid

def ping_host(host, count=10):
    try:
        ping_command = ['ping', '-c', str(count), host]
        result = subprocess.run(ping_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        ping_result = ''.join([line.strip() for line in result.stdout.decode('utf-8').splitlines() if line.strip() and 'transmitted' in line])
        audit_logger.info(f"ping_host: {host} result - {result}")
        audit_logger.info(f"ping_host: {host} result - {ping_result}")
        stderr_output = result.stderr.decode('utf-8')
        audit_logger.info(f"ping_host: {host} stderr_output - {stderr_output}")
        if ping_result:
            errors = re.search(r'(\d+) errors', ping_result)
            transmitted = re.search(r'(\d+) packets transmitted', ping_result)
            received = re.search(r'(\d+) received', ping_result)
            packet_loss = re.search(r'(\d+)% packet loss', ping_result)
            time_ms = re.search(r'time (\d+)ms', ping_result)
            if errors:
                ping_errors = int(errors.group(1)) if errors and errors.group(1) else ""
            else:
                ping_errors = ""
            if transmitted and received and packet_loss and time_ms:
                packets_transmitted = int(transmitted.group(1)) if transmitted and transmitted.group(1) else "N/A"
                packets_received = int(received.group(1)) if received and received.group(1) else "N/A"
                packet_loss = int(packet_loss.group(1)) if packet_loss and packet_loss.group(1) else "N/A"
                time = int(time_ms.group(1)) if time_ms and time_ms.group(1) else "N/A"
            return result.returncode == 0, packets_transmitted, packets_received, packet_loss, time, ping_errors
        elif stderr_output:
            return False, "Ping failed", "Ping failed", "Ping failed", "Ping failed", f"failed-{stderr_output}"
        else:
            return False, "Ping failed", "Ping failed", "Ping failed", "Ping failed", "failed"
    except subprocess.CalledProcessError:
        return False, "Ping failed", "Ping failed", "Ping failed", "Ping failed", "failed"

def create_table(data):
    if not data:
        return "No data provided."
    headers = list(data[0].keys())
    column_widths = {header: max(len(header), max(len(str(row[header])) for row in data)) for header in headers}
    table = " | ".join(header.ljust(column_widths[header]) for header in headers) + "\n"
    separator = "+".join(["-" * width for width in column_widths.values()]) + "\n"
    for row in data:
        row_values = [str(row[header]).ljust(column_widths[header]) for header in headers]
        table += " | ".join(row_values) + "\n"
    return table

def validate_output(conn, conn_output, target):
    json_output = {}
    try:
        json_output = json.loads(remove_some_strings(conn_output))
    except:
        conn_output = remove_some_strings(conn_output)
        while True:
            output = conn.send_command_timing("")
            if output:
                conn_output += output
            else:
                try:
                    json_output = json.loads(remove_some_strings(conn_output))
                except:
                    update_final_string('obs',f'Failed to capture {target} value due to device slow performance.')
                    json_output['json-status'] = 'failed'
                    return json_output
                else:
                    json_output['json-status'] = 'success'
                    return json_output
    else:
        json_output['json-status'] = 'success'
        return json_output

def capture_data(dns_entity, to_path, passwd, peer_sdwan, peer_sdwan_path, fwdClass): #Capture tenant/routing_ins/remote_interface_list
    global global_peer
    interface_list_up_ip_add = []
    interface_list_up_ip_add_st = "NO"
    interface_list = []
    interface_list_up = []
    interface_list_sdwan_nat = []
    tenant = "Failed"
    routing_ins = "Failed"
    to_sdwanpath_dict = {}
    data_sdwanpath_cnt = "N/A"
    status = "SUCCESS"
    try:
        conn = ConnectHandler(host=dns_entity, username=uname, password=passwd, device_type="flexvnf", global_delay_factor=2, timeout=40)
    except Exception as e:
        update_final_string('obs', f'Unable to SSH to {dns_entity}.')
        update_final_string('npoa', f'Check {dns_entity} as it is pingable from domain but unable to SSH to it.')
        audit_logger.error(f"Function: capture_data {dns_entity}: Check {dns_entity} as it is pingable from domain but unable to SSH to it! (001)")
        return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat
    else:
        audit_logger.info(f"Function: capture_data {dns_entity} - Login Success!\n")
        temp_clear_buffer = conn.clear_buffer()
        try:
            ### Capture device tenant
            audit_logger.info(f"capture_data: show configuration orgs org sd-wan site site-name | display json | nomore")
            conn_tenant = conn.send_command_timing('show configuration orgs org sd-wan site site-name | display json | nomore', max_loops=100000, last_read=3.0)
            # audit_logger.info(f"Function: capture_data {dns_entity}\n conn_tenant: {conn_tenant}\n")
            json_tenant = validate_output(conn, conn_tenant, 'Tenant')
            audit_logger.info(f"Function: capture_data {dns_entity}\njson_tenant: {json_tenant}\n")
            if json_tenant['json-status'] == 'success':
                for tnt in json_tenant['data']['org:orgs']['org']:
                    if 'name' in tnt and 'erizon' not in tnt['name']:
                        tenant = str(tnt['name'].strip())
                        audit_logger.info(f"Function: capture_data {dns_entity}\ntenant: {tenant}\n")
                        break
                else:
                    update_final_string('obs', f'Unable to get the proper tenant from the device.')
                    status = "FAILED-00"
                    audit_logger.error(f"Function: capture_data {dns_entity}: Unable to get the proper tenant from the device (002)")
                    return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat
            ## Check device site-type
            # conn_site_type = conn.send_command_timing('show configuration | display set | match "site site-type" | nomore', max_loops=100000, last_read=3.0)
            # print(f"conn_site_type: {conn_site_type}") ## TEST
            # # conn_site_type = conn.send_command_timing('show configuration | display set | match "site site-type" | nomore', max_loops=100000, last_read=3.0)
            # site_type = "N/A"
            # if conn_site_type:
            #     output_site_type = remove_some_strings(conn_site_type).strip()
            #     if output_site_type:
            #         site_type = output_site_type.split()[-1]
            # Get necessary routing instance related to the alarm
            # TEST
            # interface_list_up_ip_add = []
            # interface_list_up_ip_add_st = "NO"
            # interface_list = []
            # interface_list_up = []
            # interface_list_sdwan_nat = []
            # TEST
            ## Capture routing_ins
            audit_logger.info(f"capture_data: show configuration routing-instances | display json | nomore")
            conn_routing_ins = conn.send_command_timing(f'show configuration routing-instances | display json | nomore', max_loops=100000, last_read=3.5)
            # audit_logger.info(f"Function: capture_data {dns_entity}\n conn_routing_ins: {conn_routing_ins}\n")
            json_routing_ins = validate_output(conn, conn_routing_ins, 'specific routing instance')
            audit_logger.info(f"Function: capture_data {dns_entity}\njson_routing_ins: {json_routing_ins}\n")
            if json_routing_ins['json-status'] == 'success':
                for instance in json_routing_ins['data']['routing-module:routing-instances']['routing-instance']:
                    if 'ansport' in instance['name'].lower() and f'{to_path}-tra'.lower() in instance['name'].lower():
                        routing_ins = instance['name']
                        break
                else:
                    routing_ins = "FAILED"
                    update_final_string('obs', f'Unable to gather the correct routing instance related to {to_path} from {dns_entity}.')
                    audit_logger.error(f"Function: capture_data {dns_entity}: Unable to gather the correct routing instance related to {to_path} (003).")
                    status = "FAILED-0"
                    return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat
            else:
                routing_ins = "FAILED"
                update_final_string('obs', f'Unable to gather the correct routing instance related to {to_path} from {dns_entity}.')
                audit_logger.error(f"Function: capture_data {dns_entity}: {dns_entity} - Unable to gather the correct routing instance related to {to_path} (004).")
                status = "FAILED-0"
                return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat
            audit_logger.info(f"Function: capture_data {dns_entity}\nrouting_ins: {routing_ins}\n")
            if tenant != "Failed":
                ## Caprture SDWAN Peer status
                # Validate the SDWAN path vs the device affected
                audit_logger.info(f"capture_data: show orgs org {tenant} sd-wan sla-monitor status {peer_sdwan} | display json | nomore")
                conn_sdwanpath = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor status {peer_sdwan} | display json | nomore', max_loops=100000, last_read=2.5)
                # audit_logger.info(f"Function: capture_data {dns_entity}\n conn_sdwanpath: {conn_sdwanpath}\n")
                json_sdwanpath = validate_output(conn, conn_sdwanpath, 'specific sdwan path')
                # audit_logger.info(f"Function: capture_data {dns_entity}\n json_sdwanpath: {json_sdwanpath}\n")
                if json_sdwanpath['json-status'] == 'success':
                    if ('data' in json_sdwanpath
                        and 'org:orgs' in json_sdwanpath['data']
                        and 'org' in json_sdwanpath['data']['org:orgs']
                        and json_sdwanpath['data']['org:orgs']['org']
                        and 'sdwan:sd-wan' in json_sdwanpath['data']['org:orgs']['org'][0]
                        and 'sla-monitor' in json_sdwanpath['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                        and 'status' in json_sdwanpath['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']
                        and json_sdwanpath['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status']
                        and 'path-status' in json_sdwanpath['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'][0]
                    ):
                        for path in json_sdwanpath['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'][0]['path-status']:
                            if path['local-wan-link'] == to_path and path['remote-wan-link'] == peer_sdwan_path and path['fwd-class'] == fwdClass:
                                to_sdwanpath_dict['fwd-class'] = path.get('fwd-class', '')
                                to_sdwanpath_dict['conn-state'] = path.get('conn-state', '')
                                to_sdwanpath_dict['flaps'] = path.get('flaps', '')
                                to_sdwanpath_dict['last-flapped'] = path.get('last-flapped', '')
                                to_sdwanpath_dict['local-wan-link'] = path.get('local-wan-link', '')
                                to_sdwanpath_dict['remote-wan-link'] = path.get('remote-wan-link', '')
                                break
                        if to_sdwanpath_dict:
                            global_peer.append(to_sdwanpath_dict.get('conn-state','N/A'))
                        else:
                            global_peer.append('N/A')
                        # else:
                        #     update_final_string('obs', f'Peer sdwan: {peer_sdwan}/{peer_sdwan_path} is not present on device {dns_entity}/{to_path}.')
                    else:
                        global_peer.append('N/A')
                else:
                    global_peer.append('N/A')
                audit_logger.info(f"Function: capture_data {dns_entity}\n to_sdwanpath_dict: {to_sdwanpath_dict}\n")
                audit_logger.info(f"Function: capture_data {dns_entity}\n global_peer: {global_peer}\n")
                ## SDWAN Path count
                audit_logger.info(f"capture_data: show orgs org {tenant} sd-wan sla-monitor brief | display json | nomore")
                conn_sdwanpath_cnt = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor brief | display json | nomore', max_loops=100000, last_read=3.0)
                # audit_logger.info(f"Function: capture_data {dns_entity}\n conn_sdwanpath_cnt: {conn_sdwanpath_cnt}\n")
                json_sdwanpath_cnt = validate_output(conn, conn_sdwanpath_cnt, 'specific sdwan path')
                audit_logger.info(f"Function: capture_data {dns_entity}\n json_sdwanpath_cnt: {json_sdwanpath_cnt}\n")
                if json_sdwanpath_cnt['json-status'] == 'success':
                    if ('data' in json_sdwanpath_cnt
                        and 'org:orgs' in json_sdwanpath_cnt['data']
                        and 'org' in json_sdwanpath_cnt['data']['org:orgs']
                        and json_sdwanpath_cnt['data']['org:orgs']['org']
                        and 'sdwan:sd-wan' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]
                        and 'sla-monitor' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                        and 'brief' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']
                        and json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief']
                        and 'up-path-cnt' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0]
                        and json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0]['up-path-cnt']
                    ):
                        data_sdwanpath_cnt = json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0].get('up-path-cnt','N/A')
                    else:
                        data_sdwanpath_cnt = "N/A"
                else:
                    data_sdwanpath_cnt = "N/A"
                audit_logger.info(f"Function: capture_data {dns_entity}\n data_sdwanpath_cnt: {data_sdwanpath_cnt}\n")
            ###HERE###
            # get interface from transport vrf (BRANCH)
            conn_interface = conn.send_command_timing(f'show interfaces brief | display json | nomore', max_loops=100000, last_read=3.0)
            # audit_logger.info(f"Function: capture_data {dns_entity}\n conn_interface: {conn_interface}\n")
            json_interface = validate_output(conn, conn_interface, 'Interface')
            audit_logger.info(f"Function: capture_data {dns_entity}\n json_interface: {json_interface}\n")
            if json_interface['json-status'] == 'success':
                for intf in json_interface['data']['interfaces:interfaces']['brief']:
                    if 'vrf' in intf and intf['vrf'].lower().strip() == routing_ins.lower().strip() and 'vni' in intf['name'].lower().strip():
                        interface_list.append(intf)
                        if intf['if-oper-status'].lower().strip() == 'up' and intf['if-admin-status'].lower().strip() == 'up':
                            interface_list_up.append(intf)
                            # if interface_list_up_ip_add_st == "NO":
                            #     interface_list_up_ip_add.append(intf['address'][0]['ip'].split('/')[0])
            if interface_list_sdwan_nat:
                if interface_list and interface_list_sdwan_nat:
                    for interface in interface_list:
                        for nat in interface_list_sdwan_nat:
                            if nat['intf-name'].lower().strip() == interface['name'].lower().strip():
                                interface['public-ip'] = nat['public-ip']
                                interface['nat-status'] = nat['nat-status']
                            else:
                                interface['public-ip'] = interface['address'][0]['ip'].split('/')[0]
                                interface['nat-status'] = 'false'
            if len(interface_list_up) == 0:
                # update_final_string('obs',f"No interface linked to {routing_ins} is UP on device {dns_entity}.")
                # update_final_string('npoa',f"No interface linked to {routing_ins} is UP. Check the transport or isp related to routing-instance {routing_ins} of {dns_entity}.")
                audit_logger.error(f"Function: capture_data {dns_entity}: No interface linked to {routing_ins} is UP. Check the transport or isp related to routing instance {routing_ins} (005).")
                status = "FAILED-1"
                return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat
            else:
                audit_logger.info(f"capture_data: show orgs org {tenant} sd-wan wan-interfaces | display json | nomore")
                conn_controller_interface = conn.send_command_timing(f'show orgs org {tenant} sd-wan wan-interfaces | display json | nomore', max_loops=100000, last_read=2.5)
                # audit_logger.info(f"Function: capture_data {dns_entity}\n conn_controller_interface: {conn_controller_interface}\n")
                json_controller_interface = validate_output(conn, conn_controller_interface, "Controller's ip address")
                audit_logger.info(f"Function: capture_data {dns_entity}\n json_controller_interface: {json_controller_interface}\n")
                if json_controller_interface['json-status'] == 'success':
                    if ('data' in json_controller_interface
                        and 'org:orgs' in json_controller_interface['data']
                        and 'org' in json_controller_interface['data']['org:orgs']
                        and json_controller_interface['data']['org:orgs']['org']
                        and 'sdwan:sd-wan' in json_controller_interface['data']['org:orgs']['org'][0]
                        and 'wan-interfaces' in json_controller_interface['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                    ):
                        for wan in json_controller_interface['data']['org:orgs']['org'][0]['sdwan:sd-wan']['wan-interfaces']:
                            if to_path.lower() == wan['circuit-name'].lower():
                                if 'public-ip' in wan:
                                    interface_list_up_ip_add.append(wan['public-ip'])
                                interface_list_sdwan_nat.append({
                                    'intf-name': wan.get('intf-name',''),
                                    'circuit-name': wan.get('circuit-name',''),
                                    'nat-status': wan.get('nat-status',''),
                                    'public-ip': wan.get('public-ip',''),
                                })
                                interface_list_up_ip_add_st = "YES"
                audit_logger.info(f"Function: capture_data {dns_entity}\n interface_list_sdwan_nat: {interface_list_sdwan_nat}\n")
                audit_logger.info(f"Function: capture_data {dns_entity}\n interface_list_up_ip_add: {interface_list_up_ip_add}\n")
                audit_logger.info(f"Function: capture_data {dns_entity}\n interface_list_up_ip_add_st: {interface_list_up_ip_add_st}\n")
        except Exception as e:
            update_final_string('obs',f'Failed to capture initial data due to device slow performance of {dns_entity}.')
            status = "FAILED-2"
            audit_logger.error(f"Function: capture_data {dns_entity}: Failed to capture initial data due to device slow performance (006).")
            return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat
        else:
            conn.disconnect()
            # tenant: wbacntrl
            # routing_ins: INET-Transport-VR
            # interface_list_up_ip_add: ['166.60.74.210']
            # interface_list: [{'name': 'vni-0/0.0', 'mac': 'fa:16:3e:42:88:7e', 'if-oper-status': 'up', 'if-admin-status': 'up', 'tenant-id': 1, 'vrf': 'INET-Transport-VR', 'address': [{'ip': '166.60.74.210/30'}]}]
            # interface_list_up: [{'name': 'vni-0/0.0', 'mac': 'fa:16:3e:42:88:7e', 'if-oper-status': 'up', 'if-admin-status': 'up', 'tenant-id': 1, 'vrf': 'INET-Transport-VR', 'address': [{'ip': '166.60.74.210/30'}]}]
            # status: SUCCESS
            # site_type: controller
            # or
            # tenant: wbacntrl
            # routing_ins: INET1-Transport-VR
            # interface_list_up_ip_add: ['24.158.10.110']
            # interface_list: [{'name': 'vni-0/3.0', 'mac': '00:90:0b:b3:ee:48', 'if-oper-status': 'up', 'if-admin-status': 'up', 'tenant-id': 2, 'vrf': 'INET1-Transport-VR', 'address': [{'ip': '24.158.10.110/30'}]}]
            # interface_list_up: [{'name': 'vni-0/3.0', 'mac': '00:90:0b:b3:ee:48', 'if-oper-status': 'up', 'if-admin-status': 'up', 'tenant-id': 2, 'vrf': 'INET1-Transport-VR', 'address': [{'ip': '24.158.10.110/30'}]}]
            # status: SUCCESS
            # site_type: branch
            return tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, status, to_sdwanpath_dict, data_sdwanpath_cnt, interface_list_sdwan_nat

def intf_error(conn, tenant, intf_name):
    intf_error_count = 0
    audit_logger.info(f"capture_data: show interfaces statistics {intf_name} | display json | nomore")
    conn_interface = conn.send_command_timing(f'show interfaces statistics {intf_name} | display json | nomore', max_loops=100000, last_read=3.0)
    json_interface = validate_output(conn, conn_interface, f'interface errors related to {intf_name}')
    audit_logger.info(f"Function: intf_error\n json_interface: {json_interface}\n")
    rx_errors = "N/A"
    tx_errors = "N/A"
    tx_dropped = "N/A"
    intf_cos = "NO"
    if json_interface['json-status'] == 'success':
        if ('data' in json_interface
            and 'interfaces:interfaces' in json_interface['data']
            and 'statistics' in json_interface['data']['interfaces:interfaces']
            and json_interface['data']['interfaces:interfaces']['statistics']
            and 'rx-stats' in json_interface['data']['interfaces:interfaces']['statistics'][0]
            and 'rx-errors' in json_interface['data']['interfaces:interfaces']['statistics'][0]['rx-stats']
        ):
            rx_errors = int(json_interface['data']['interfaces:interfaces']['statistics'][0]['rx-stats']['rx-errors'])
        else:
            update_final_string('obs',f"Unable to capture interface receive errors for {intf_name}.")
            intf_error_count += 1
        if ('data' in json_interface
            and 'interfaces:interfaces' in json_interface['data']
            and 'statistics' in json_interface['data']['interfaces:interfaces']
            and json_interface['data']['interfaces:interfaces']['statistics']
            and 'tx-stats' in json_interface['data']['interfaces:interfaces']['statistics'][0]
            and 'tx-errors' in json_interface['data']['interfaces:interfaces']['statistics'][0]['tx-stats']
        ):
            tx_errors = int(json_interface['data']['interfaces:interfaces']['statistics'][0]['tx-stats']['tx-errors'])
        else:
            update_final_string('obs',f"Unable to capture interface transmit errors for {intf_name}.")
            intf_error_count += 1
    else:
        update_final_string('obs',f"Unable to capture interface statisctics errors for {intf_name}.")
        intf_error_count += 1
    if tenant != "Failed":
        audit_logger.info(f"capture_data: show orgs org-services {tenant} class-of-service interfaces brief {intf_name} | display json | nomore")
        conn_interface_cos = conn.send_command_timing(f'show orgs org-services {tenant} class-of-service interfaces brief {intf_name} | display json | nomore', max_loops=100000, last_read=3.0)
        # audit_logger.info(f"Function: intf_error\n conn_interface_cos: {conn_interface_cos}\n")
        intf_cos = "NO"
        if "incomplete path" not in conn_interface_cos.lower() and "unknown argument" not in conn_interface_cos.lower():
            json_interface_cos = validate_output(conn, conn_interface_cos, f'interface COS errors related to {intf_name}')
            if json_interface_cos['json-status'] == 'success':
                if (
                    'data' in json_interface_cos
                    and 'org:orgs' in json_interface_cos
                    and 'org-services' in json_interface_cos
                    ):
                    json_interface_cos_data = json_interface_cos['data']['org:orgs']['org-services']
                else:
                    json_interface_cos_data = []
                if json_interface_cos_data:
                    for data in json_interface_cos_data:
                        if 'name' in data:
                            if str(data['name']).lower() == tenant.lower() and 'cos:class-of-service' in data:
                                if (
                                    'cos:class-of-service' in data
                                    and 'interfaces' in data['cos:class-of-service']
                                    and 'brief' in data['cos:class-of-service']['interfaces']
                                ):
                                    for intf_cos in data['cos:class-of-service']['interfaces']['brief']:
                                        if 'traffic-stats' in intf_cos:
                                            intf_cos = "YES"
                                            tx_dropped=  intf_cos['traffic-stats'].get('tx-dropped','')
                                            break
                                        else:
                                            intf_cos = "NO"
                                    else:
                                        intf_cos = "NO"
                                else:
                                    intf_cos = "NO"
                            else:
                                intf_cos = "NO"
                        else:
                            intf_cos = "NO"
                else:
                    intf_cos = "NO"
            else:
                intf_cos = "NO"
        else:
            intf_cos = "NO"
    return intf_name, rx_errors, tx_errors, tx_dropped, intf_cos, intf_error_count

def intf_error_list(conn, intf_list, tenant):
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        futures = {executor.submit(intf_error, conn, tenant, intf): intf for intf in intf_list}
        for future in concurrent.futures.as_completed(futures):
            intf_name, rx_errors, tx_errors, tx_dropped, intf_cos, intf_error_count = future.result(timeout=600)
            results[intf_name] = {'rx-errors': rx_errors ,'tx-errors': tx_errors ,'tx-dropped': tx_dropped, 'intf-cos': intf_cos, 'intf-error-count': intf_error_count}
    return results

def triage_process(dns_entity, from_match, from_path, to_match, to_path, fwdClass, passwd, tenant, routing_ins, interface_list_up_ip_add, interface_list, interface_list_up, other_rt_ins, sdwanpeer, sdwanpath_cnt, interface_list_sdwan_nat, operation):
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} from_match {from_match}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} from_path {from_path}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} to_match {to_match}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} to_path {to_path}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} fwdClass {fwdClass}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} tenant {tenant}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} routing_ins {routing_ins}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} interface_list_up_ip_add {interface_list_up_ip_add}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} interface_list {interface_list}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} interface_list_up {interface_list_up}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} other_rt_ins {other_rt_ins}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} sdwanpeer {sdwanpeer}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} sdwanpath_cnt {sdwanpath_cnt}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} operation {operation}")
    audit_logger.info(f"Function: INITIAL-triage_process {dns_entity} interface_list_sdwan_nat {interface_list_sdwan_nat}")
    global global_peer
    failed_count = 0
    internet_failed_count = 0
    circuit_failed_count = 0
    to_sdwanpath_dict = sdwanpeer
    cont_ping_int = "NO"
    cont_ping_pe = "NO"
    check_int_errors = "NO"
    interface_list_up_name = []
    try:
        conn = ConnectHandler(host=dns_entity, username=uname, password=passwd, device_type="flexvnf", global_delay_factor=2, timeout=40)
    except Exception as e:
        print(f"\n=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+\n***** Output for {dns_entity} ***** ")
        print(f"\n        - SSH failed: Unable to connect to device -> {dns_entity}.")
        failed_count  = 1000
        audit_logger.error(f"Function: triage_process {dns_entity}: SSH failed - Unable to connect to device (007).\n\nError: {e}\n\n")
        return failed_count, internet_failed_count, circuit_failed_count
    else:
        audit_logger.info(f"Function: triage_process {dns_entity} Login success!")
        temp_clear_buffer = conn.clear_buffer()
        try:
            print(f"\n=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+\n***** Output for {dns_entity} ***** ")
            audit_logger.info(f"Function: triage_process {dns_entity} tenant-1 {tenant}")
            update_final_string('obs',f'For: {dns_entity}:')
            ### PARTIAL OPS
            # if operation == "PARTIAL":
            ### Capture device tenant
            if not tenant:
                audit_logger.info(f"Function: triage_process {dns_entity} - show configuration orgs org sd-wan site site-name | display json | nomore")
                conn_tenant = conn.send_command_timing('show configuration orgs org sd-wan site site-name | display json | nomore', max_loops=100000, last_read=3.0)
                json_tenant = validate_output(conn, conn_tenant, 'Tenant')
                audit_logger.info(f"Function: triage_process {dns_entity}\n json_tenant: {json_tenant}\n")
                tenant = "Failed"
                if json_tenant['json-status'] == 'success':
                    for tnt in json_tenant['data']['org:orgs']['org']:
                        if 'name' in tnt and 'erizon' not in tnt['name']:
                            tenant = str(tnt['name'].strip())
                            break
                    else:
                        update_final_string('obs', f'Unable to get the proper tenant from the device.')
                        failed_count = 100
                        audit_logger.error(f"Function: triage_process {dns_entity}: Unable to get the proper tenant from the device. (008).")
                        return failed_count, internet_failed_count, circuit_failed_count
                else:
                    update_final_string('obs', f'Unable to get the proper tenant from the device.')
                    failed_count = 100
                    audit_logger.error(f"Function: triage_process {dns_entity}: Unable to get the proper tenant from the device. (008).")
                    return failed_count, internet_failed_count, circuit_failed_count
            audit_logger.info(f"Function: triage_process {dns_entity} tenant-2 {tenant}")
        except Exception as e:
            failed_count = 9901001
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9901002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try:
            audit_logger.info(f"Function: triage_process {dns_entity} routing_ins {routing_ins}")
            # if operation == "PARTIAL":
            # Get necessary routing instance related to the alarm
            if 'failed' in routing_ins.lower().strip() or 'transport' not in routing_ins.lower().strip() or (routing_ins is None or routing_ins == ''):
                routing_ins = "failed"
                audit_logger.info(f"Function: triage_process {dns_entity} - show configuration routing-instances | display json | nomore")
                conn_routing_ins = conn.send_command_timing(f'show configuration routing-instances | display json | nomore', max_loops=100000, last_read=8.0)
                json_routing_ins = validate_output(conn, conn_routing_ins, 'specific routing instance')
                audit_logger.info(f"Function: triage_process {dns_entity}\n json_routing_ins: {json_routing_ins}\n")
                if json_routing_ins['json-status'] == 'success':
                    for instance in json_routing_ins['data']['routing-module:routing-instances']['routing-instance']:
                        if 'ansport' in instance['name'].lower() and f'{to_path}-tra'.lower() in instance['name'].lower():
                            routing_ins = instance['name']
                            break
                    else:
                        update_final_string('obs', f'Unable to gather the correct routing instance related to {to_path} from {dns_entity}.')
                        audit_logger.error(f"Function: triage_process {dns_entity}: Unable to gather the correct routing instance related to {to_path}. (009).")
                        failed_count = 100
                        return failed_count, internet_failed_count, circuit_failed_count
                else:
                    update_final_string('obs', f'Unable to gather the correct routing instance related to {to_path} from {dns_entity}.')
                    audit_logger.error(f"Function: triage_process {dns_entity}: Unable to gather the correct routing instance related to {to_path}. (009).")
                    failed_count = 100
                    return failed_count, internet_failed_count, circuit_failed_count
        except Exception as e:
            failed_count = 9902001
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9902002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try: 
            audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up {interface_list_up}")
            if routing_ins:
                if not interface_list_up:
                    # get interface from transport vrf
                    audit_logger.info(f"Function: triage_process {dns_entity} - show interfaces brief | display json | nomore")
                    conn_interface = conn.send_command_timing(f'show interfaces brief | display json | nomore', max_loops=100000, last_read=3.0)
                    json_interface = validate_output(conn, conn_interface, 'Interface')
                    audit_logger.info(f"Function: triage_process {dns_entity}\n json_interface: {json_interface}\n")
                    interface_list = []
                    interface_list_up = []
                    interface_list_up_ip_add = []
                    if json_interface['json-status'] == 'success':
                        for intf in json_interface['data']['interfaces:interfaces']['brief']:
                            if 'vrf' in intf and intf['vrf'].lower().strip() == routing_ins.lower().strip() and 'vni' in intf['name'].lower().strip():
                                interface_list.append(intf)
                                if intf['if-oper-status'] == 'up' and intf['if-admin-status'] == 'up':
                                    interface_list_up.append(intf)
                                    interface_list_up_ip_add.append(intf['address'][0]['ip'].split('/')[0])
                        if len(interface_list_up) == 0:
                            update_final_string('obs',f"No interface linked to {routing_ins} is UP.")
                            update_final_string('npoa',f"No interface linked to {routing_ins} is UP. Check the transport or isp related to routing instance {routing_ins} on {dns_entity}.")
                            audit_logger.error(f"Function: triage_process {dns_entity}: No interface linked to {routing_ins} is UP. Check the transport or isp related to routing instance {routing_ins}. (010).")
                            failed_count += 1
                            circuit_failed_count += 1
                        else:
                            update_final_string('obs',f"[UP] Interface linked to {routing_ins} is {len(interface_list_up)}.")
                    else:
                        update_final_string('obs', f'Unable to gather the UP interface linked to {routing_ins} from {dns_entity}.')
                        audit_logger.error(f"Function: triage_process Unable to gather the UP interface linked to {routing_ins} from {dns_entity}. (01022).")
                        failed_count += 1
        except Exception as e:
            failed_count = 9903001
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9903002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try:
            if operation == "PARTIAL":
                if sdwanpath_cnt == "N/A":
                ## SDWAN Path count
                    audit_logger.info(f"Function: triage_process {dns_entity} - show orgs org {tenant} sd-wan sla-monitor brief | display json | nomore")
                    conn_sdwanpath_cnt = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor brief | display json | nomore', max_loops=100000, last_read=3.0)
                    json_sdwanpath_cnt = validate_output(conn, conn_sdwanpath_cnt, 'specific sdwan path')
                    audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_cnt: {json_sdwanpath_cnt}\n")
                    if json_sdwanpath_cnt['json-status'] == 'success':
                        if ('data' in json_sdwanpath_cnt
                            and 'org:orgs' in json_sdwanpath_cnt['data']
                            and 'org' in json_sdwanpath_cnt['data']['org:orgs']
                            and json_sdwanpath_cnt['data']['org:orgs']['org']
                            and 'sdwan:sd-wan' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]
                            and 'sla-monitor' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                            and 'brief' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']
                            and json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief']
                            and 'up-path-cnt' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0]
                            and json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0]['up-path-cnt']
                        ):
                            sdwanpath_cnt = json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0].get('up-path-cnt','N/A')
                        else:
                            sdwanpath_cnt = "N/A"
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpath_cnt-001 {sdwanpath_cnt}")
                audit_logger.info(f"Function: triage_process {dns_entity} show orgs org {tenant} sd-wan sla-monitor status | display json | nomore (002)")
                conn_sdwanpath_status_1 = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor status | display json | nomore', max_loops=100000, last_read=4.0)
                line_count_conn_sdwanpath_status_1 = len(conn_sdwanpath_status_1.splitlines())
                last_3_lines_conn_sdwanpath_status_1 = conn_sdwanpath_status_1.splitlines()[-3:]
                audit_logger.info(f"Function: triage_process {dns_entity}\n line_count_conn_sdwanpath_status_1: 001 {line_count_conn_sdwanpath_status_1}\n")
                audit_logger.info(f"Function: triage_process {dns_entity}\n last_3_lines_conn_sdwanpath_status_1: 001  {last_3_lines_conn_sdwanpath_status_1}\n")
                json_sdwanpath_status_1 = validate_output(conn, conn_sdwanpath_status_1, 'all sdwan path')
                # audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_status_1: {json_sdwanpath_status_1}\n")
                sdwanpath_status_overall = 0
                sdwanpath_status_all_cnt = 0
                sdwanpath_status_all_list = []
                if json_sdwanpath_status_1['json-status'] == 'success':
                    if ('data' in json_sdwanpath_status_1
                        and 'org:orgs' in json_sdwanpath_status_1['data']
                        and 'org' in json_sdwanpath_status_1['data']['org:orgs']
                        and json_sdwanpath_status_1['data']['org:orgs']['org'][0]
                        and 'sdwan:sd-wan' in json_sdwanpath_status_1['data']['org:orgs']['org'][0]
                        and 'sla-monitor' in json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                        and 'status' in json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']
                        and json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status']
                    ):
                        audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'] is Existing.")
                        for sdwan_path in json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status']:
                            if ('path-status' in sdwan_path
                                and sdwan_path['path-status'][0]
                                and 'local-wan-link' in sdwan_path['path-status'][0]
                                and sdwan_path['path-status'][0]['local-wan-link']
                            ):
                                for path in sdwan_path['path-status']:
                                    sdwanpath_status_overall += 1
                                    if to_path.strip().lower() == path['local-wan-link'].lower().strip() and path['conn-state'].lower().strip() == 'up':
                                        sdwanpath_status_all_cnt += 1
                                        sdwanpath_status_all_list.append(sdwan_path)
                    else:
                        audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'] NOT is Existing.")
                audit_logger.info(f"Function: triage_process {dns_entity}\n sdwanpath_cnt: {sdwanpath_cnt}\n")
                audit_logger.info(f"Function: triage_process {dns_entity}\n sdwanpath_status_all_cnt: {sdwanpath_status_all_cnt}\n")
                audit_logger.info(f"Function: triage_process {dns_entity}\n sdwanpath_status_all_list: {sdwanpath_status_all_list}\n")
                audit_logger.info(f"Function: triage_process {dns_entity}\n sdwanpath_status_overall: {sdwanpath_status_overall}\n")
                print(f"\nSDWAN path status:\n=====================================")
                # print(f"\t- SDWAN peer count related to path: [{to_path}]/{routing_ins} that is in UP state: {sdwanpath_status_all_cnt}.")
                if sdwanpath_status_all_cnt:
                    update_final_string('obs',f"SDWAN peer count related to path: [{to_path}]/{routing_ins} that is in UP state: {sdwanpath_status_all_cnt}.")
                    if sdwanpath_status_all_cnt == 0:
                        print(f"\t- SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}: {sdwanpath_status_all_cnt}. <No SDWAN Peers in UP state>")
                        update_final_string('npoa',f"Device {dns_entity} has no SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}. Please check the local circuit of this device.")
                        failed_count += 1
                        circuit_failed_count += 1
                    else:
                        print(f"\t- SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}: {sdwanpath_status_all_cnt}.")
                else:
                    print(f"\t- SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}: {sdwanpath_status_all_cnt}. <No SDWAN Peers in UP state>")
                    update_final_string('npoa',f"Device {dns_entity} has no SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}. Please check the local circuit of this device.")
                    failed_count += 1
                    circuit_failed_count += 1
                if sdwanpath_cnt:
                    if sdwanpath_cnt != "N/A":
                        print(f"\t- All SDWAN peer count that is in UP state: {sdwanpath_cnt}.")
                        update_final_string('obs',f"All SDWAN peer count that is in UP state: {sdwanpath_cnt}.")
                        if sdwanpath_cnt == 0:
                            update_final_string('npoa',f"Device {dns_entity} has no SDWAN Peers in UP state. Please check the local circuit of this device on routing-instance {routing_ins}.")
                            failed_count += 1
                            circuit_failed_count += 1
        except Exception as e:
            failed_count = 9903011
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9903012
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try: 
            audit_logger.info(f"Function: triage_process {dns_entity} operation {operation}")
            ### FULL OPS
            if operation == "FULL":
                audit_logger.info(f"Function: triage_process {dns_entity} interface_list {interface_list}")
                audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up {interface_list_up}")
                update_final_string('obs',f'Routing instance related to path {to_path} from {dns_entity} is {routing_ins}.')
                update_final_string('obs',f"There's {len(interface_list)} interface linked to {routing_ins} and {len(interface_list_up)} interface is UP.")
                ### START - Capture device Up time
                audit_logger.info(f"Function: triage_process {dns_entity} - show system uptime | display json | nomore")
                conn_uptime = conn.send_command_timing('show system uptime | display json | nomore', max_loops=100000, last_read=3.0)
                json_uptime = validate_output(conn, conn_uptime, 'System Uptime')
                audit_logger.info(f"Function: triage_process {dns_entity}\n json_uptime: {json_uptime}\n")
                if json_uptime['json-status'] == 'success':
                    sys_uptime = str(json_uptime['data']['system:system']['uptime'][0]['sysuptime'].strip())
                    update_final_string('obs',f'Tenant is {tenant} and uptime is {sys_uptime}.')
                else:
                    audit_logger.error(f"Function: triage_process {dns_entity}: unable to capture uptime. (01001).")
                ### END - Capture device Up time
                # Validate the SDWAN path vs the device affected
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpeer-1 {sdwanpeer}")
                if not sdwanpeer:
                    audit_logger.info(f"triage_process: show orgs org {tenant} sd-wan sla-monitor status {from_match} | display json | nomore")
                    conn_sdwanpath = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor status {from_match} | display json | nomore', max_loops=100000, last_read=3.0)
                    json_sdwanpath = validate_output(conn, conn_sdwanpath, 'specific sdwan path')
                    if json_sdwanpath['json-status'] == 'success':
                        for path in json_sdwanpath['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'][0]['path-status']:
                            if path['local-wan-link'] == to_path and path['remote-wan-link'] == from_path and path['fwd-class'] == fwdClass:
                                to_sdwanpath_dict['fwd-class'] = path.get('fwd-class', '')
                                to_sdwanpath_dict['conn-state'] = path.get('conn-state', '')
                                to_sdwanpath_dict['flaps'] = path.get('flaps', '')
                                to_sdwanpath_dict['last-flapped'] = path.get('last-flapped', '')
                                to_sdwanpath_dict['local-wan-link'] = path.get('local-wan-link', '')
                                to_sdwanpath_dict['remote-wan-link'] = path.get('remote-wan-link', '')
                                break
                        else:
                            update_final_string('obs', f'SDWAN peer {from_match}/{from_path} from {to_match}/{to_path} is not existing on the device: {dns_entity}.')
                            audit_logger.info(f"Function: triage_process {dns_entity}: Unable to gather sdwan path related to {to_path}. (011111).")
                            if fwdClass.strip().lower() == 'fc_nc':
                                update_final_string('npoa', f'Please check device: {to_match}/{to_path} as connection to it is not longer existing.')
                            else:
                                update_final_string('npoa', f'Please check device: {to_match}/{to_path} as connection to it is not longer existing.')
                    else:
                        audit_logger.info(f"Function: triage_process {dns_entity}: Unable to gather sdwan path related to {to_path}. (01222).")
                        failed_count += 1
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpeer-2 {sdwanpeer}")
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpath_cnt-1 {sdwanpath_cnt}")
                if sdwanpath_cnt == "N/A":
                ## SDWAN Path count
                    audit_logger.info(f"Function: triage_process {dns_entity} - show orgs org {tenant} sd-wan sla-monitor brief | display json | nomore")
                    conn_sdwanpath_cnt = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor brief | display json | nomore', max_loops=100000, last_read=3.0)
                    json_sdwanpath_cnt = validate_output(conn, conn_sdwanpath_cnt, 'specific sdwan path')
                    audit_logger.info(f"Function: capture_data {dns_entity}\n json_sdwanpath_cnt: {json_sdwanpath_cnt}\n")
                    if json_sdwanpath_cnt['json-status'] == 'success':
                        if ('data' in json_sdwanpath_cnt
                            and 'org:orgs' in json_sdwanpath_cnt['data']
                            and 'org' in json_sdwanpath_cnt['data']['org:orgs']
                            and json_sdwanpath_cnt['data']['org:orgs']['org']
                            and 'sdwan:sd-wan' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]
                            and 'sla-monitor' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                            and 'brief' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']
                            and json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief']
                            and 'up-path-cnt' in json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0]
                            and json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0]['up-path-cnt']
                        ):
                            sdwanpath_cnt = json_sdwanpath_cnt['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['brief'][0].get('up-path-cnt','N/A')
                        else:
                            sdwanpath_cnt = "N/A"
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpath_cnt-2 {sdwanpath_cnt}")
                audit_logger.info(f"Function: triage_process {dns_entity} to_sdwanpath_dict-1 {to_sdwanpath_dict}")
                audit_logger.info(f"Function: triage_process {dns_entity} show orgs org {tenant} sd-wan sla-monitor status | display json | nomore (001)")
                conn_sdwanpath_status_1 = conn.send_command_timing(f'show orgs org {tenant} sd-wan sla-monitor status | display json | nomore', max_loops=100000, last_read=5.0)
                line_count_conn_sdwanpath_status_1 = len(conn_sdwanpath_status_1.splitlines())
                last_3_lines_conn_sdwanpath_status_1 = conn_sdwanpath_status_1.splitlines()[-3:]
                audit_logger.info(f"Function: triage_process {dns_entity}\n line_count_conn_sdwanpath_status_1: 002 {line_count_conn_sdwanpath_status_1}\n")
                audit_logger.info(f"Function: triage_process {dns_entity}\n last_3_lines_conn_sdwanpath_status_1: 002 {last_3_lines_conn_sdwanpath_status_1}\n")
                json_sdwanpath_status_1 = validate_output(conn, conn_sdwanpath_status_1, 'all sdwan path')
                # audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_status_1: {json_sdwanpath_status_1}\n")
                sdwanpath_status_all_cnt = 0
                sdwanpath_status_overall = 0
                sdwanpath_status_all_list = []
                if json_sdwanpath_status_1['json-status'] == 'success':
                    if ('data' in json_sdwanpath_status_1
                        and 'org:orgs' in json_sdwanpath_status_1['data']
                        and 'org' in json_sdwanpath_status_1['data']['org:orgs']
                        and json_sdwanpath_status_1['data']['org:orgs']['org'][0]
                        and 'sdwan:sd-wan' in json_sdwanpath_status_1['data']['org:orgs']['org'][0]
                        and 'sla-monitor' in json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                        and 'status' in json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']
                        and json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status']
                    ):
                        audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'] is Existing.")
                        for sdwan_path in json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status']:
                            if ('path-status' in sdwan_path
                                and sdwan_path['path-status'][0]
                                and 'local-wan-link' in sdwan_path['path-status'][0]
                                and sdwan_path['path-status'][0]['local-wan-link']
                            ):
                                for path in sdwan_path['path-status']:
                                    sdwanpath_status_overall += 1
                                    if to_path.strip().lower() == path['local-wan-link'].lower().strip() and path['conn-state'].lower().strip() == 'up':
                                        sdwanpath_status_all_cnt += 1
                                        sdwanpath_status_all_list.append(sdwan_path)
                    else:
                        audit_logger.info(f"Function: triage_process {dns_entity}\n json_sdwanpath_status_1['data']['org:orgs']['org'][0]['sdwan:sd-wan']['sla-monitor']['status'] NOT is Existing.")
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpath_status_all_cnt-2 {sdwanpath_status_all_cnt}")
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpath_status_all_list-2 {sdwanpath_status_all_list}")
                audit_logger.info(f"Function: triage_process {dns_entity} sdwanpath_status_overall-2 {sdwanpath_status_overall}")
                audit_logger.info(f"Function: triage_process {dns_entity} to_sdwanpath_dict-2 {to_sdwanpath_dict}")
                print(f"\nSDWAN path status:\n=====================================")
                if to_sdwanpath_dict:       
                    print(f"\t- Local wan link: {to_sdwanpath_dict.get('local-wan-link','N/A')}/{to_match} to sdwan-peer {from_match}/{to_sdwanpath_dict.get('remote-wan-link','N/A')} is currently {to_sdwanpath_dict.get('conn-state','N/A')} on fwdClass: {to_sdwanpath_dict.get('fwd-class','N/A')}. Flap-count {to_sdwanpath_dict.get('flaps','N/A')} -> Last-flapped: {to_sdwanpath_dict.get('last-flapped','N/A')}.")
                    if to_sdwanpath_dict.get('conn-state','N/A').lower().strip() == 'up':
                        if ':' in to_sdwanpath_dict['last-flapped']:
                            hours, minutes, seconds = map(int, to_sdwanpath_dict['last-flapped'].split(':'))
                            total_minutes = hours * 60 + minutes
                            if 0 <= total_minutes <= 4:
                                update_final_string('obs',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} and last flapped of {to_sdwanpath_dict['last-flapped']} > less than 5 minutes.")
                                update_final_string('npoa',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} last flapped  ({to_sdwanpath_dict['last-flapped']}) less than 5 minutes. Check if this is still flapping.")
                                failed_count += 1
                            elif 5 <= total_minutes <= 30:
                                update_final_string('obs',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} and last flapped of {to_sdwanpath_dict['last-flapped']} > less than 30 minutes.")
                                # update_final_string('npoa',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} last flapped  ({to_sdwanpath_dict['last-flapped']}) less than 30 minutes. Check if this is still flapping.")
                                # failed_count += 1
                            elif 31 <= total_minutes <= 59:
                                update_final_string('obs',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} and last flapped of {to_sdwanpath_dict['last-flapped']} > more than 30 minutes.")
                                # update_final_string('npoa',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} last flapped ({to_sdwanpath_dict['last-flapped']}) less than 60 minutes. Check if this is still flapping.")
                                # failed_count += 1
                            else:
                                update_final_string('obs',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} and last flapped of {to_sdwanpath_dict['last-flapped']} > more than 60 minutes.")
                        else:
                            update_final_string('obs',f"SDWAN Path from {to_match} to {from_match} is currently {to_sdwanpath_dict['conn-state']} and last flapped of {to_sdwanpath_dict['last-flapped']}.")
                    else:
                        update_final_string('obs',f"SDWAN Path from {to_match} to {from_match} is currently in '{to_sdwanpath_dict.get('conn-state','N/A').lower().strip()}' state.")
                        update_final_string('npoa',f"SDWAN Path from {to_match} to {from_match} is currently in '{to_sdwanpath_dict.get('conn-state','N/A').lower().strip()}' state. Check local and remote circuits and the upstream path as well.")
                        failed_count += 1
                        circuit_failed_count += 1
                else:
                    print(f'\t- SDWAN peer {from_match}/{from_path} from {to_match}/{to_path} is not existing on the device: {dns_entity}.')
                    update_final_string('obs', f'Unable to gather sdwan path related to {to_path} from {dns_entity}.')
                    audit_logger.info(f"Function: triage_process {dns_entity}: Unable to gather sdwan path related to {to_path}. (012).")
                    failed_count += 1
                    circuit_failed_count += 1
                if sdwanpath_status_all_cnt:
                    update_final_string('obs',f"SDWAN peer count related to path: [{to_path}]/{routing_ins} that is in UP state: {sdwanpath_status_all_cnt}.")
                    if sdwanpath_status_all_cnt == 0:
                        print(f"\t- SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}: {sdwanpath_status_all_cnt}. <No SDWAN Peers in UP state>")
                        update_final_string('npoa',f"Device {dns_entity} has no SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}. Please check the local circuit of this device.")
                        failed_count += 1
                        circuit_failed_count += 1
                    else:
                        print(f"\t- SDWAN peer count related to path: [{to_path}]/{routing_ins} that is in UP state: {sdwanpath_status_all_cnt}.")
                else:
                    print(f"\t- SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}: {sdwanpath_status_all_cnt}. <No SDWAN Peers in UP state>")
                    update_final_string('npoa',f"Device {dns_entity} has no SDWAN Peers in UP state on path: [{to_path}]/{routing_ins}. Please check the local circuit of this device.")
                    failed_count += 1
                    circuit_failed_count += 1
                if sdwanpath_cnt != "N/A":
                    print(f"\t- All SDWAN peer count that is in UP state: {sdwanpath_cnt}.")
                    update_final_string('obs',f"SDWAN peer [ALL] count that is in UP state: {sdwanpath_cnt}.")
                    if sdwanpath_cnt == 0:
                        update_final_string('npoa',f"Device {dns_entity} has no SDWAN Peers in UP state. Please check the local circuit of this device.")
                        failed_count += 1
                        circuit_failed_count += 1
                cont_ping_int = "NO"
                cont_ping_pe = "NO"
                audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up_ip_add-1 {interface_list_up_ip_add}")
                if interface_list_up_ip_add:
                    for ip in interface_list_up_ip_add:
                        audit_logger.info(f"triage_process: ping {ip} routing-instance {routing_ins} count 3 | grep transmitted | nomore")
                        conn_ping = ""
                        conn_ping = conn.send_command_timing(f"ping {ip} routing-instance {routing_ins} count 3 | grep transmitted | nomore", max_loops=100000, last_read=16.5)
                        output_ping = ""
                        output_ping = remove_some_strings(conn_ping).strip()
                        audit_logger.info(f"Function: triage_process {dns_entity}\n output_ping (ping to sdwan peer): {output_ping}\n")
                        if output_ping:
                            transmitted = ""
                            transmitted = re.search(r'(\d+) packets transmitted', output_ping)
                            received = ""
                            received = re.search(r'(\d+) received', output_ping)
                            packet_loss = ""
                            packet_loss = re.search(r'(\d+)% packet loss', output_ping)
                            time_ms = ""
                            time_ms = re.search(r'time (\d+)ms', output_ping)
                            errors = ""
                            errors = re.search(r'(\d+) errors', output_ping)
                            ping_errors = ""
                            if errors:
                                ping_errors = int(errors.group(1)) if errors and errors.group(1) else ""
                            else:
                                ping_errors = ""
                            if transmitted and received and packet_loss and time_ms:
                                ping_pkts_tx = int(transmitted.group(1)) if transmitted and transmitted.group(1) else "N/A"
                                ping_pkts_rx = int(received.group(1)) if received and received.group(1) else "N/A"
                                ping_pkts_loss = int(packet_loss.group(1)) if packet_loss and packet_loss.group(1) else "N/A"
                                ping_time = int(time_ms.group(1)) if time_ms and time_ms.group(1) else "N/A"
                            output_ping_str = f"\t- Ping to remote router of the SDWAN Path IP {ip}: {ping_pkts_tx} packets transmitted {ping_pkts_rx} received {ping_pkts_loss}% packet loss time {ping_time}ms"
                            if ping_errors:
                                print(f"{output_ping_str} | errors found: {ping_errors}")
                            else:
                                print(output_ping_str)
                            # print(f"\t- Ping to remote router of the SDWAN Path IP {ip}: {ping_pkts_tx} packets transmitted {ping_pkts_rx} received {ping_pkts_loss}% packet loss time {ping_time}ms")
                            if int(ping_pkts_loss) != 0:
                                cont_ping_int = "YES"
                                global_peer_list = [item.lower() for item in global_peer]
                                if 'down'.lower() in global_peer_list or 'n/a'.lower() in global_peer_list or 'init'.lower() in global_peer_list:
                                    down_count = int(global_peer_list.count('down'))
                                    update_final_string('obs',f"Ping packet loss towards SDWAN remote router {ip} is {ping_pkts_loss}% on vrf: {routing_ins}.")
                                    # if down_count == 1:
                                    # update_final_string('npoa',f"Ping packet loss towards SDWAN remote router {ip} is {ping_pkts_loss}% from {dns_entity}. Check further path from vrf: {routing_ins} towards hostname: {from_match}/{other_rt_ins}.")
                                    # failed_count += 1
                                    # else:
                                    #     update_final_string('npoa',f"Ping packet loss towards SDWAN remote router {ip} is {ping_pkts_loss}% from {dns_entity}. Check further path from vrf: {routing_ins} towards hostname: {from_match}/{other_rt_ins}.")
                                    #     failed_count += 1
                                else:
                                    # if 'lte' in other_rt_ins.lower().strip():
                                    # cont_ping_int = "NO"
                                    update_final_string('obs',f"Ping packet loss towards SDWAN remote router {ip} is {ping_pkts_loss}% on vrf: {routing_ins}. Both sdwan peer is up & other end is <{other_rt_ins}>: possible that ICMP is blocked.")
                            else:
                                cont_ping_int = "NO"
                                update_final_string('obs',f"No ping packet loss towards SDWAN remote router {ip} on vrf: {routing_ins}.")
                        else:
                            cont_ping_int = "YES"
                            update_final_string('obs',f"No ping output towards SDWAN remote router {ip} on vrf: {routing_ins}.")
                            failed_count += 1
                else:
                    print(f"\t- No IP address was captured to be Ping/Traceroute to remote router of the SDWAN Path: {to_match} to {from_match}")
                    audit_logger.info(f"Function: triage_process {dns_entity}: No IP address was captured to be Ping/Traceroute to remote router of the SDWAN Path: {to_match} to {from_match}. (013).")
                    update_final_string('obs',f"No IP address was captured to be Ping/Traceroute to remote router of the SDWAN Path: {to_match} to {from_match}")
        except Exception as e:
            failed_count = 9904001
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9904002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try: 
            # Proceed to ping internet address 8.8.8.8
            audit_logger.info(f"Function: triage_process {dns_entity} cont_ping_int-1 {cont_ping_int}")
            if cont_ping_int == "YES" or operation == "PARTIAL":
                # get ping results to internet address 8.8.8.8
                audit_logger.info(f"Function: triage_process {dns_entity} - ping 8.8.8.8 routing-instance {routing_ins} count 3 | grep transmitted | nomore")
                conn_ping = ""
                conn_ping = conn.send_command_timing(f"ping 8.8.8.8 routing-instance {routing_ins} count 3 | grep transmitted | nomore", max_loops=100000, last_read=16.5)
                output_ping = ""
                output_ping = remove_some_strings(conn_ping)
                audit_logger.info(f"Function: triage_process {dns_entity}\n output_ping (ping 8.8.8.8): {output_ping}\n")
                if output_ping:
                    transmitted = ""
                    transmitted = re.search(r'(\d+) packets transmitted', output_ping)
                    received = ""
                    received = re.search(r'(\d+) received', output_ping)
                    packet_loss = ""
                    packet_loss = re.search(r'(\d+)% packet loss', output_ping)
                    time_ms = ""
                    time_ms = re.search(r'time (\d+)ms', output_ping)
                    errors = ""
                    errors = re.search(r'(\d+) errors', output_ping)
                    ping_errors_int = ""
                    if errors:
                        ping_errors_int = int(errors.group(1)) if errors and errors.group(1) else ""
                    else:
                        ping_errors_int = ""
                    if transmitted and received and packet_loss and time_ms:
                        ping_pkts_tx = int(transmitted.group(1)) if transmitted and transmitted.group(1) else "N/A"
                        ping_pkts_rx = int(received.group(1)) if received and received.group(1) else "N/A"
                        ping_pkts_loss = int(packet_loss.group(1)) if packet_loss and packet_loss.group(1) else "N/A"
                        ping_time = int(time_ms.group(1)) if time_ms and time_ms.group(1) else "N/A"
                    output_ping_str_int = f"\t- Ping to to public internet ip 8.8.8.8: {ping_pkts_tx} packets transmitted {ping_pkts_rx} received {ping_pkts_loss}% packet loss time {ping_time}ms"
                    if ping_errors_int:
                        print(f"{output_ping_str_int} | errors found: {ping_errors_int}")
                    else:
                        print(output_ping_str_int)
                    ping_pub_int_str = ""
                    if not interface_list_up:
                        ping_pub_int_str += f"No available interface from this vrf: {routing_ins} that is in UP state"
                    else:
                        ping_pub_int_str += f"Possible that internet is not reachable from this vrf: {routing_ins}"
                    if int(ping_pkts_loss) == 0:
                        # update_final_string('obs',f"Ping packet loss towards public internet ip 8.8.8.8 is {ping_pkts_loss}% on vrf: {routing_ins}.")
                        update_final_string('obs',f"No ping packet loss towards public internet ip 8.8.8.8 on vrf: {routing_ins} - Packet loss: {ping_pkts_loss}%.")
                        # update_final_string('npoa',f"Ping packet loss towards public internet ip 8.8.8.8 is {ping_pkts_loss}% from {dns_entity}. {ping_pub_int_str}.")
                        cont_ping_pe = "NO"
                    elif 1 <= int(ping_pkts_loss) <= 99:
                        update_final_string('obs',f"Ping packet loss towards public internet ip 8.8.8.8 is {ping_pkts_loss}% on vrf: {routing_ins}.")
                        # update_final_string('npoa',f"Ping packet loss towards public internet ip 8.8.8.8 is {ping_pkts_loss}% from {dns_entity}. {ping_pub_int_str}.")
                        # internet_failed_count += 1
                        # circuit_failed_count += 1
                        cont_ping_pe = "YES"
                    elif int(ping_pkts_loss) >= 100:
                        update_final_string('obs',f"Ping packet loss towards public internet ip 8.8.8.8 is {ping_pkts_loss}% on vrf: {routing_ins}. {ping_pub_int_str}.")
                        # update_final_string('npoa',f"Ping packet loss towards public internet ip 8.8.8.8 is {ping_pkts_loss}% from {dns_entity}. {ping_pub_int_str}.")
                        # internet_failed_count += 1
                        cont_ping_pe = "YES"
                    elif str(ping_pkts_loss) == "N/A":
                        update_final_string('obs',f"Unable to reach public internet ip 8.8.8.8 on vrf: {routing_ins}. {ping_pub_int_str}.")
                        # internet_failed_count += 1
                        cont_ping_pe = "YES"
                    else:
                        cont_ping_pe = "NO"
                        # update_final_string('obs',f"No ping packet loss towards public internet ip 8.8.8.8 on vrf: {routing_ins} - Packet loss: {ping_pkts_loss}%.")
                else:
                    cont_ping_pe = "YES"
                    # internet_failed_count += 1
                    update_final_string('obs',f"No ping output towards public internet IP 8.8.8.8 on vrf: {routing_ins}.")
                    audit_logger.error(f"Function: capture_data {dns_entity}: No ping output towards public internet IP 8.8.8.8 on vrf: {routing_ins}. (014).")
                ## Proceed with PE Checking
                audit_logger.info(f"Function: triage_process {dns_entity} cont_ping_pe-1 {cont_ping_pe}")
                if cont_ping_pe == "YES":
                    # if interface_list_up:
                    # get ping results to PE
                    print(f"\nCheck PE router status from {dns_entity}/{routing_ins}:\n=====================================")
                    audit_logger.info(f"Function: triage_process {dns_entity} - show route routing-instance {routing_ins} 0.0.0.0 | display xml")
                    conn_gateway = conn.send_command_timing(f'show route routing-instance {routing_ins} 0.0.0.0 | display xml', max_loops=100000, last_read=3.0)
                    pattern_lastUpdIpAddr = r'<lastUpdIpAddr>(\d+\.\d+\.\d+\.\d+)</lastUpdIpAddr>'
                    match_lastUpdIpAddr = re.search(pattern_lastUpdIpAddr, conn_gateway)
                    if match_lastUpdIpAddr:
                        gateway = match_lastUpdIpAddr.group(1)
                        audit_logger.info(f"Function: triage_process {dns_entity} - show arp routing-instance {routing_ins} | display json | nomore")
                        conn_arp = conn.send_command_timing(f'show arp routing-instance {routing_ins} | display json | nomore', max_loops=100000, last_read=3.0)
                        json_arp = validate_output(conn, conn_arp, 'arp remote ip address (PE ROUTER)')
                        audit_logger.info(f"Function: triage_process {dns_entity}\n json_arp: {json_arp}\n")
                        if json_arp['json-status'] == 'success':
                            data_arp_gw = []
                            if ('data' in json_arp
                                and 'arp:arp' in json_arp['data']
                                and 'routing-instance' in json_arp['data']['arp:arp']
                                and json_arp['data']['arp:arp']['routing-instance']
                                and 'arpentry' in json_arp['data']['arp:arp']['routing-instance'][0]
                                and json_arp['data']['arp:arp']['routing-instance'][0]['arpentry']
                            ):
                                for arp_entry in json_arp['data']['arp:arp']['routing-instance'][0]['arpentry']:
                                    if arp_entry['ip'] == gateway and arp_entry['type'].lower().strip() == 'remote':
                                        data_arp_gw.append(arp_entry)
                                        break
                                if data_arp_gw:
                                    if str(data_arp_gw[0]['age']).lower().strip() == 'expired':
                                        print(f"\t- Peer/gateway of {dns_entity} on {routing_ins} is {data_arp_gw[0]['ip']} [{data_arp_gw[0]['type']}] up but already {data_arp_gw[0]['age']}. << Circuit issue >>")
                                        update_final_string('npoa',f"Need to check the circuit on {routing_ins} for {dns_entity} as PE Router IP {data_arp_gw[0]['ip']} is expired.")
                                        failed_count += 1
                                        circuit_failed_count += 1
                                    else:
                                        print(f"\t- Peer/gateway of {dns_entity} on {routing_ins} is {data_arp_gw[0]['ip']} [{data_arp_gw[0]['type']}] up - Age: {data_arp_gw[0]['age']}.")
                                else:
                                    print(f"\t- Peer/gateway of {dns_entity} on {routing_ins} is {match_lastUpdIpAddr} is not found on the arp table of {routing_ins}.")
                                    update_final_string('obs',f"Default gateway of {dns_entity} on {routing_ins} [{match_lastUpdIpAddr}] is not found on the arp table of {routing_ins}.")
                                    update_final_string('obs',f"Need to check {dns_entity} on {routing_ins} as default gateway [{match_lastUpdIpAddr}] is not found on the arp table of {routing_ins}.")
                                    failed_count += 1
                                    circuit_failed_count += 1
                                    check_int_errors = "NO"
                        else:
                            dg_str = ""
                            if not interface_list_up:
                                dg_str += f" No interface linked to {routing_ins} is UP."
                            else:
                                dg_str += f" There's {len(interface_list_up)} interface linked to {routing_ins} is UP."
                            print(f"\t- There's no default-gateway found on {dns_entity} for routing-instance {routing_ins}.{dg_str} Check the ckt on {routing_ins}")
                            update_final_string('obs',f"There's no default-gateway found on {dns_entity} for routing-instance {routing_ins}.")
                            update_final_string('npoa',f"Need to check {dns_entity} as default-gateway is not found on {routing_ins}.{dg_str} (0001)")
                            failed_count += 1
                            circuit_failed_count += 1
                            check_int_errors = "NO"
                    else:
                        dg_str = ""
                        if not interface_list_up:
                            dg_str += f" No interface linked to {routing_ins} is UP."
                        else:
                            dg_str += f" There's {len(interface_list_up)} interface linked to {routing_ins} is UP."
                        print(f"\t- There's no default-gateway found on {dns_entity} for routing-instance {routing_ins}.{dg_str} Check the ckt on {routing_ins}")
                        update_final_string('obs',f"There's no default-gateway found on {dns_entity} for routing-instance {routing_ins}.{dg_str}")
                        update_final_string('npoa',f"Need to check {dns_entity} as default gateway is not found on {routing_ins}.{dg_str} (0002)")
                        failed_count += 1
                        circuit_failed_count += 1
                        check_int_errors = "NO"
        except Exception as e:
            failed_count = 9905001
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9905002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try: 
            audit_logger.info(f"Function: triage_process {dns_entity} check_int_errors-1 {check_int_errors}")
            # if check_int_errors == "YES":
            audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up-1 {interface_list_up}")
            if interface_list_up: # if not interface_list_up:  (TEST)
                # get interface from transport vrf
                audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up-2 {interface_list_up}")
                audit_logger.info(f"Function: triage_process {dns_entity} interface_list-2{interface_list}")
                if interface_list and interface_list_up:
                    for int_up in interface_list_up:
                        interface_list_up_name.append(int_up['name'])
            else:
                audit_logger.info(f"Function: triage_process {dns_entity} - show interfaces brief | display json | nomore")
                conn_interface = conn.send_command_timing(f'show interfaces brief | display json | nomore', max_loops=100000, last_read=3.0)
                json_interface = validate_output(conn, conn_interface, 'Interface')
                audit_logger.info(f"Function: triage_process {dns_entity}\n json_interface: {json_interface}\n")
                interface_list = []
                interface_list_up = []
                if json_interface['json-status'] == 'success':
                    for intf in json_interface['data']['interfaces:interfaces']['brief']:
                        if 'vrf' in intf and intf['vrf'].lower().strip() == routing_ins.lower().strip() and 'vni' in intf['name'].lower().strip():
                            interface_list.append(intf)
                            if intf['if-oper-status'] == 'up' and intf['if-admin-status'] == 'up':
                                interface_list_up.append(intf)
                                interface_list_up_name.append(intf['name'])
                    update_final_string('obs',f"There's {len(interface_list)} interface linked to {routing_ins} and {len(interface_list_up)} interface is UP.")
                else:
                    audit_logger.error(f"Function: triage_process {dns_entity}: Unable to gather 'show interfaces brief' (012654).")
                audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up-1 {interface_list_up}")
            if interface_list_up: # [{'name': 'vni-0/1.0', 'mac': 'fa:16:3e:7b:40:9e', 'if-oper-status': 'up', 'if-admin-status': 'up', 'tenant-id': 1, 'vrf': 'PIP-Transport-VR', 'address': [{'ip': '166.60.168.134/30'}]}]
                if not interface_list_sdwan_nat: # [{'intf-name': 'vni-0/1.1', 'circuit-name': 'INET', 'nat-status': 'true', 'public-ip': '179.125.173.30'}]
                    if tenant:
                        interface_list_sdwan_nat = []
                        conn_controller_interface = conn.send_command_timing(f'show orgs org {tenant} sd-wan wan-interfaces | display json | nomore', max_loops=100000, last_read=2.5)
                        json_controller_interface = validate_output(conn, conn_controller_interface, "Controller's ip address")
                        audit_logger.info(f"Function: capture_data {dns_entity}\n json_controller_interface: {json_controller_interface}\n")
                        if json_controller_interface['json-status'] == 'success':
                            if ('data' in json_controller_interface
                                and 'org:orgs' in json_controller_interface['data']
                                and 'org' in json_controller_interface['data']['org:orgs']
                                and json_controller_interface['data']['org:orgs']['org']
                                and 'sdwan:sd-wan' in json_controller_interface['data']['org:orgs']['org'][0]
                                and 'wan-interfaces' in json_controller_interface['data']['org:orgs']['org'][0]['sdwan:sd-wan']
                            ):
                                for wan in json_controller_interface['data']['org:orgs']['org'][0]['sdwan:sd-wan']['wan-interfaces']:
                                    if to_path.lower() == wan['circuit-name'].lower():
                                        temp = {}
                                        if 'intf-name' in wan:
                                            temp['intf-name'] = wan.get('intf-name','')
                                        if 'circuit-name' in wan:
                                            temp['circuit-name'] = wan.get('circuit-name','')
                                        if 'nat-status' in wan:
                                            temp['nat-status'] = wan.get('nat-status','')
                                        if 'public-ip' in wan:
                                            temp['public-ip'] = wan.get('public-ip','')
                                        interface_list_sdwan_nat.append(temp)
                        audit_logger.info(f"Function: capture_data {dns_entity}\n interface_list_sdwan_nat: {interface_list_sdwan_nat}\n")
                print(f"\nInterface(s) linked to routing-instance {routing_ins}:\n=====================================")
                if len(interface_list_up) == 0:
                    print(f"\t- There's no interface linked to routing instance {routing_ins}")
                    # update_final_string('obs',f"No interface linked to {routing_ins} is UP.")
                    # update_final_string('npoa',f"No interface linked to {routing_ins} is UP. Check the transport or circuit related to routing instance {routing_ins} (3) {dns_entity}.")
                    intf_error_count += 1
                # else:
                #     update_final_string('obs',f"[UP] Interface linked to {routing_ins} is {len(interface_list_up)}.")
                else:
                    # interface_list: [{'name': 'vni-0/0.0', 'mac': 'c4:00:ad:a4:1e:d5', 'if-oper-status': 'up', 'if-admin-status': 'up', 'tenant-id': 1, 'vrf': 'INET-Transport-VR', 'address': [{'ip': '63.125.98.42/30'}]}]
                    audit_logger.info(f"Function: triage_process {dns_entity} interface_list-1 {interface_list}")
                    # for int_ins in interface_list:
                    #     int_statemet = f"\t- Interface {int_ins['name']} is oper: {int_ins['if-oper-status']} / admin: {int_ins['if-admin-status']} on vrf: {int_ins['vrf']}"
                    #     if 'address' in int_ins:
                    #         int_statemet += f" with IP Address of {int_ins['address'][0]['ip']}"
                    #     if 'nat-status' in int_ins and int_ins['nat-status'].lower().strip() == 'true':
                    #         int_statemet += f" with nat ip add: {int_ins['public-ip']}"
                    #     print(f"{int_statemet}.")
                    int_statemet = ""
                    for int_ins in interface_list:
                        int_statemet = f"\t- Interface {int_ins['name']} is oper: {int_ins['if-oper-status']} / admin: {int_ins['if-admin-status']} on vrf: {int_ins['vrf']}"
                        if 'address' in int_ins:
                            int_statemet += f" with IP Address of {int_ins['address'][0]['ip']}"
                        if interface_list_sdwan_nat:
                            for sdwan_nat in interface_list_sdwan_nat:
                                if sdwan_nat['intf-name'].strip().lower() == int_ins['name'].strip().lower():
                                    if 'public-ip' in sdwan_nat:
                                        int_statemet += f" with nat ip add: {sdwan_nat['public-ip']}"
                                        break
                        print(f"{int_statemet}.")
            if check_int_errors == "YES":
                # get interface errors
                audit_logger.info(f"Function: triage_process {dns_entity} - interface_list_up_name: {interface_list_up_name}")
                audit_logger.info(f"Function: triage_process {dns_entity} - interface_list_up_name-1 {interface_list_up_name}")
                if interface_list_up_name:
                    print(f"\nChecking interface(s) for errors on {dns_entity} / {routing_ins}: (60 secs interval) [{interface_list_up_name}]\n=====================================")
                    interval = 0
                    intf_error_dict = {}
                    while True:
                        interval += 1
                        if interval not in intf_error_dict:
                            intf_error_dict[interval] = {}
                        intf_error_result = intf_error_list(conn, interface_list_up_name, tenant)
                        intf_error_dict[interval] = intf_error_result
                        if interval == 2:
                            break
                        else:
                            time.sleep(60)
                    # intf_error_dict: {
                    # 1: {
                    # 'vni-0/4.3': {'rx-errors': 0, 'tx-errors': 0, 'tx-dropped': 'N/A', 'intf-cos': 'NO', 'intf-error-count': 0},
                    # 'vni-0/6.0': {'rx-errors': 0, 'tx-errors': 0, 'tx-dropped': 'N/A', 'intf-cos': 'NO', 'intf-error-count': 0}},
                    # 2: {'vni-0/4.3': {'rx-errors': 0, 'tx-errors': 0, 'tx-dropped': 'N/A', 'intf-cos': 'NO', 'intf-error-count': 0},
                    # 'vni-0/6.0': {'rx-errors': 0, 'tx-errors': 0, 'tx-dropped': 'N/A', 'intf-cos': 'NO', 'intf-error-count': 0}}}
                    audit_logger.info(f"Function: triage_process {dns_entity} interface_list_up_name-2 {interface_list_up_name}")
                    for intf_name in interface_list_up_name:
                        intf_string = ""
                        if 1 in intf_error_dict and 2 in intf_error_dict and intf_error_dict[1][intf_name]['intf-error-count'] == 0 and intf_error_dict[2][intf_name]['intf-error-count'] == 0 :
                            total_rx_errors = int(intf_error_dict[2][intf_name]['rx-errors']) - int(intf_error_dict[1][intf_name]['rx-errors'])
                            total_tx_errors = int(intf_error_dict[2][intf_name]['tx-errors']) - int(intf_error_dict[1][intf_name]['tx-errors'])
                            audit_logger.info(f"Function: triage_process {dns_entity} - total_rx_errors: {total_rx_errors}")
                            audit_logger.info(f"Function: triage_process {dns_entity} - total_tx_errors: {total_tx_errors}")
                            if total_rx_errors == 0 and total_tx_errors == 0:
                                intf_string += f"No errors seen on both transmit and receive. "
                            elif total_rx_errors != 0 and total_tx_errors == 0:
                                intf_string += f"Only receive errors detected: {total_rx_errors} errors. "
                                update_final_string('obs',f"There are receive errors found on {intf_name}. receive errors: {total_rx_errors}.")
                                update_final_string('npoa',f"Check interface receive errors found on {intf_name}. Check the circuit or the physical interface if there is overutilization.")
                                failed_count += 1
                                circuit_failed_count += 1
                            elif total_rx_errors == 0 and total_tx_errors != 0:
                                intf_string += f"Only transmit errors detected: {total_tx_errors} errors. "
                                update_final_string('obs',f"There are transmit errors found on {intf_name}. transmit errors: {total_tx_errors}.")
                                update_final_string('npoa',f"Check interface transmit errors found on {intf_name}. Check the circuit or the physical interface if there is overutilization.")
                                failed_count += 1
                                circuit_failed_count += 1
                            else:
                                intf_string += f"Both receive and transmit errors detected: Rx Errors: {total_rx_errors}, Tx Errors: {total_tx_errors}. "
                                update_final_string('obs',f"There are transmit and receive errors found on {intf_name}. transmit errors: {total_tx_errors} | receive errors: {total_rx_errors}")
                                update_final_string('npoa',f"Check interface transmit and receive errors found on {intf_name}. Check the circuit or the physical interface if there is overutilization.")
                                failed_count += 1
                                circuit_failed_count += 1
                            if str(intf_error_dict[1][intf_name]['intf-cos']) == "YES":
                                total_tx_dropped = int(intf_error_dict[2][intf_name]['tx-dropped']) - int(intf_error_dict[1][intf_name]['tx-dropped'])
                                if total_tx_dropped == 0:
                                    intf_string += f"No transmit dropped seen on class-of-service. "
                                else:
                                    intf_string += f"Class-of-service transmit dropped detected. COS Tx dropped: {total_tx_dropped}. "
                                    update_final_string('obs',f"There are Class-of-service transmit drops found on {intf_name} / COS Tx dropped: {total_tx_dropped}.")
                                    update_final_string('npoa',f"Check interface class-of-service tx-dropped on {intf_name}. Check the circuit or the physical interface if there is overutilization.")
                                    failed_count += 1
                                    circuit_failed_count += 1
                            else:
                                intf_string += f"Class-of-Service not configured."
                        else:
                            intf_string += f"There's some error on capturing interface stats. This needs to be checked manually"
                            update_final_string('obs',f"There's some error on capturing interface {intf_name} stats.")
                            update_final_string('npoa',f"Interface {intf_name} needs to be checked manually for errors.")
                            failed_count += 1
                            circuit_failed_count += 1
                        print(f"\t- Interface {intf_name} stats: {intf_string}")
        except Exception as e:
            failed_count = 9906001
            conn.disconnect()
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9906002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        try: 
            ## Capture related alarms
            audit_logger.info(f"Function: triage_process {dns_entity} alarm_year {alarm_year}")
            audit_logger.info(f"Function: triage_process {dns_entity} alarm_mon {alarm_mon}")
            print(f"\nSDWAN PATH Alarm on {dns_entity} for {alarm_year}-{alarm_mon} (yyyy-mm):\n=====================================")
            audit_logger.info(f"Function: triage_process {dns_entity} - show alarms last-n 250 | match {from_match}/{from_path} | match {to_match}/{to_path} | match sdwanDatapath | match {alarm_year}-{alarm_mon}")
            conn_alarm = conn.send_command_timing(f"show alarms last-n 250 | match {from_match}/{from_path} | match {to_match}/{to_path} | match sdwanDatapath | match {alarm_year}-{alarm_mon}", max_loops=100000, last_read=4.0)
            output_alarm = remove_some_strings(conn_alarm)
            audit_logger.info(f"Function: triage_process {dns_entity}\n output_alarm: {output_alarm}\n")
            if output_alarm:
                conn_alarm_no = int()
                pathdown = []
                pathup = []
                path_str = ""
                for alarm in output_alarm.splitlines():
                    if alarm.split()[1] == 'sdwanDatapathUp':
                        pathup.append(alarm.split()[2])
                    if alarm.split()[1] == 'sdwanDatapathDown':
                        pathdown.append(alarm.split()[2])
                print(f"\t- There's {len(output_alarm.splitlines())} instance related to sdwanDatapathUpDown alarm on the alarm history of the device for {alarm_year}-{alarm_mon} (yyyy-mm). ")
                if pathup:
                    if not path_str:
                        path_str += "\t   -> Last instance(s): "
                    path_str += f"sdwanDatapathUp - {pathup[-1]}"
                if pathdown:
                    if not path_str:
                        path_str += "\t   -> Last instance(s): "
                    else:
                        path_str += " / "
                    path_str += f"sdwanDatapathDown - {pathdown[-1]}"
                if path_str:
                    print(path_str)
            else:
                print(f"\t- No alarm seen on (show alarm) related to this alarm. Note: Not all devices are capturing the sdwanpath alarm on the show alarm.")
        except Exception as e:
            failed_count = 9907001
            update_final_string('obs',f'Failed to proceed with the triage due to device slow performance of {dns_entity} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to device slow performance of {dns_entity}. ({failed_count}).\n\nError: {e}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        except BreakException as be:
            failed_count = 9907002
            update_final_string('obs',f'Failed to proceed with the triage due to: {be} - {failed_count}')
            audit_logger.error(f"Function: triage_process {dns_entity}: Failed to proceed with the triage due to: {be}. ({failed_count}).\n\nError: {be}\n\n")
            conn.disconnect()
            return failed_count, internet_failed_count, circuit_failed_count
        conn.disconnect()
        return failed_count, internet_failed_count, circuit_failed_count


def populate_headers(req_type):
    if req_type == 'JSON':
        return {'Connection': 'keep-alive', 'Accept': 'application/json',
                'Content-Type': 'application/json'}
    elif req_type == 'XML':
        return {'Connection': 'keep-alive', 'Accept': 'application/xml',
                'Content-Type': 'application/xml'}
    else:
        raise ValueError(f"Valid entry: 'JSON' or 'XML'")


def api_post(ip_address, element, payload, auth=None ,req_type='JSON'):
    url = f'https://{ip_address}:9182/{element}'
    headers = populate_headers(req_type)
    try:
        resp = requests.post(
            url,
            headers = headers,
            auth = auth,
            verify = False,
            data = json.dumps(payload),
        )
        cont = resp.content
        content_str = cont.decode('utf-8') 
        content_json = json.loads(content_str) 
        code = int(resp.status_code)
        return code, content_json
    except requests.exceptions.ConnectionError:
        raise ValueError(f"Unable to connect [POST] to Director: {ip_address}.")

def get_director(ip_add, auth):
    temp_drctr = {}
    directors = []
    uri = f"api/config/vnmsha/actions/_operations/get-vnmsha-details"
    data = {"get-vnmsha-details": {"fetch-peer-vnmsha-details": "true"}}
    drctr_code, drctr_data = api_post(ip_add, uri, data, auth)
    if drctr_code == 200:
        if ('output' in drctr_data
            and 'vnmsha-details' in drctr_data['output']
            and 'mode' in drctr_data['output']['vnmsha-details']
            and drctr_data['output']['vnmsha-details']['mode']
        ):
            temp_drctr['mgmtIPAddress'] = ip_add
            temp_drctr['mode'] = drctr_data['output']['vnmsha-details']['mode']
        return temp_drctr

def api_get(ip_address, element, auth=None, req_type='JSON'):
    url = f'https://{ip_address}:9182/{element}'
    headers = populate_headers(req_type)
    content_json = {}
    try:
        resp = requests.get(
            url,
            headers = headers,
            auth = auth,
            verify = False,
            #timeout = 60
        )
        code = int(resp.status_code)
        if code == 200:
            cont = resp.content
            content_str = cont.decode('utf-8') 
            content_json = json.loads(content_str) 
        return code, content_json
    except requests.exceptions.ConnectionError:
        raise ValueError(f"Unable to connect [GET] to Director: {ip_address}.")



# esp_api_url = 'https://pdcc01-snmcpe2.vzbi.com:9006/rest/vcats-service/' ## TEMP ##
## Clear Versa Director Alarm
def clear_alarm_director(dns_entity, to_tenant, alarm_text, passwd):
    clearOutput = ""
    result = {}
    controller_list = []
    director_all = []
    director_all_list = []
    director_list = []
    director_all_dict = {}
    encoded_string = urllib.parse.quote(alarm_text)
    AlarmText = f"*{encoded_string}*"
    master_ip = ""
    alarm_filter = f'vnms/fault/alarms/page?org={to_tenant}&filtertype=and&lastAlarmText={AlarmText}&showSystemAlarm=false&isCleared=false&sortOrder=dsc&sortColumn=lastStatusChangeTimeStamp&forceRefresh=false&offset=0&limit=100'
    alarm_filter_cleared = f'vnms/fault/alarms/page?org={to_tenant}&filtertype=and&lastAlarmText={AlarmText}&showSystemAlarm=false&isCleared=true&sortOrder=dsc&sortColumn=lastStatusChangeTimeStamp&forceRefresh=false&offset=0&limit=100'
    audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarm_filter = {alarm_filter}")
    audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarm_filter_cleared = {alarm_filter_cleared}")
    auth = (uname, passwd)
    try:
        conn = ConnectHandler(host=dns_entity, username=uname, password=passwd, device_type="flexvnf", global_delay_factor=2, timeout=40)
    except Exception as e:
        result['status'] = 'sshfailed'
        clearOutput += f"\n\t- SSH failed: Unable to connect to device -> {dns_entity}\n"
        failed_count  = 100011
        audit_logger.error(f"Function: clear_alarm_director {dns_entity}: SSH failed - Unable to connect to device (007).\n\nError: {e}\n\n")
        return clearOutput, result
    else:
        audit_logger.info(f"Function: clear_alarm_director {dns_entity} Login success!")
        temp_clear_buffer = conn.clear_buffer()
        try:
            audit_logger.info(f"Function: clear_alarm_director {dns_entity} - show configuration orgs org sd-wan controllers | display json | nomore")
            conn_controllers = conn.send_command_timing('show configuration orgs org sd-wan controllers | display json | nomore', max_loops=100000)
            json_controllers = validate_output(conn, conn_controllers, 'Controllers')
            audit_logger.info(f"Function: clear_alarm_director {dns_entity} json_controllers: {json_controllers}\n")
            if json_controllers['json-status'] == 'success':
                for controller in json_controllers['data']['org:orgs']['org'][0]['sdwan:sd-wan']['controllers']['controller']:
                    controller_list.append('-'.join(controller['name'].split('-')[:2]))
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} controller_list: {controller_list}")
                for controller in controller_list:
                    director_list_temp = api_esp_dns('Versa Director', to_tenant, controller)
                    director_list.append(director_list_temp[0])
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} director_list: {director_list}")
                for director_entry in director_list:
                    director_all.append(director_entry['device']['mgmtIPAddress'])
                    director_all_list.append(get_director(director_entry['device']['mgmtIPAddress'], auth))
                    if director_entry['device']['mgmtIPAddress'] not in director_all_dict:
                        director_all_dict[director_entry['device']['mgmtIPAddress']] = {}
                    director_all_dict[director_entry['device']['mgmtIPAddress']] = {'neid': director_entry['device'].get('dnsEntityName',''), 'hostname': director_entry['device'].get('entityHostName','')}
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} director_all: {director_all}")
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} director_all_dict: {director_all_dict}")
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} director_all_list: {director_all_list}")
        except Exception as e:
            failed_count = 19901005
            conn.disconnect()
            result['status'] = 'processfailed'
            clearOutput += f"\n\t- Unable to identify the Versa Director [Master] -> {dns_entity}\n"
            audit_logger.info(f"Function: clear_alarm_director {dns_entity} Unable to identify the Versa Director [Master]")
            return clearOutput, result
        else:
            if director_all_list:
                for director in director_all_list:
                    if director['mode'] == 'master':
                        master_ip = director['mgmtIPAddress']
            else:
                clearOutput += f"\n\t- Unable to capture Versa Director."
                result['status'] = 'fail'
            if master_ip:
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} master_ip = {master_ip}")
                clearOutput += f"\n\t- Versa Director [Master]: {master_ip} - DNS: {director_all_dict[master_ip]['neid']} / Hostname: {director_all_dict[master_ip]['hostname']}"
                alarm_statuscode, alarm_json = api_get(master_ip, alarm_filter, auth)
                audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarm_statuscode = {alarm_statuscode}")
                if alarm_statuscode == 200:
                    if (alarm_json
                        and 'List' in alarm_json
                        and 'value' in alarm_json['List']
                        and alarm_json['List']['value']
                    ):
                        audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarm_json = {alarm_json}")
                        #### ALARM IS EXISTING AND ACTIVE ###
                        if isinstance(alarm_json['List']['value'], dict):
                            alarm_json_value = alarm_json['List']['value']
                            clearOutput += f"\n\t- AlarmText: {alarm_json_value['lastAlarmText']}"
                            clearOutput += f"\n\t- Severity: {alarm_json_value['lastPerceivedSeverity']}"
                            uri_version = 'api/operational/system/package-info?deep=true'
                            uri_version_statuscode, uri_version_json = api_get(master_ip, uri_version, auth)
                            audit_logger.info(f"Function: clear_alarm_director {dns_entity} uri_version_statuscode = {uri_version_statuscode}")
                            audit_logger.info(f"Function: clear_alarm_director {dns_entity} uri_version_json = {uri_version_json}")
                            clearOutput += f"\n\t- Unable to clear alarm: Versa Director version is: {uri_version_json['package-info'][0]['major-version']}-{uri_version_json['package-info'][0].get('minor-version','')}-{uri_version_json['package-info'][0].get('build-type','')} / {uri_version_json['package-info'][0].get('package-name','')}"
                            return clearOutput, result
                        elif isinstance(alarm_json['List']['value'], list):
                            alarm_json_value = alarm_json['List']['value'][0]
                            clearOutput += f"\n\t- AlarmText: {alarm_json_value['lastAlarmText']}"
                            clearOutput += f"\n\t- Severity: {alarm_json_value['severity']}"
                        audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarm_json_value = {alarm_json_value}")
                        result['status'] = 'success'
                        ### ACTUAL CLEARING OF ALARM ###
                        s = requests.Session()
                        dataPayload = f"deviceName={alarm_json_value['deviceName']}&type={alarm_json_value['type']}&managedObject={alarm_json_value['object']}&org={alarm_json_value['org']}&specific-problem={alarm_json_value['specific-problem']}"
                        r = s.post(f"https://{master_ip}:9182/vnms/fault/alarm/clear?{dataPayload}", headers={'Connection': 'keep-alive', 'Accept': 'application/json',
                        'Content-Type': 'application/json'}, verify=False, auth=auth, data=dataPayload)
                        r.close()
                        audit_logger.info(f"Function: clear_alarm_director {dns_entity} r.status_code: {r.status_code}")
                        if r.status_code == 204:
                            clearOutput += f"\n\t- Clearing of alarm Status: Success! [{r.status_code}]"
                            ### END CLEARING OF ALARM ###
                            ### VALIDATE CLEARING OF ALARM ###
                            alarmCleared_statuscode_1, alarmCleared_json = api_get(master_ip, alarm_filter_cleared, auth)
                            audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarmCleared_statuscode_1 = {alarmCleared_statuscode_1}")
                            if alarmCleared_statuscode_1 == 200:
                                if (alarmCleared_json
                                    and 'List' in alarmCleared_json
                                    and 'value' in alarmCleared_json['List']
                                    and alarmCleared_json['List']['value']
                                ):
                                    alarmCleared_json_value = alarmCleared_json['List']['value'][0]
                                    audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarmCleared_json_value = {alarmCleared_json_value}")
                                    clearOutput += f"\n\t- Current alarm status: {alarmCleared_json_value['severity']}"
                                    result['status'] = 'success'
                            ### END VALIDATE CLEARING OF ALARM ###
                        else:
                            clearOutput += f"\n\t- Alarm Clearing error: {r.text}"
                            result['status'] = 'fail'
                    else:
                        ### ALARM IS ALREADY CLEARED ###
                        alarmCleared_statuscode_2, alarmCleared_json = api_get(master_ip, alarm_filter_cleared, auth)
                        audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarmCleared_statuscode_2 = {alarmCleared_statuscode_2}")
                        audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarmCleared_json = {alarmCleared_json}")
                        if alarmCleared_statuscode_2 == 200:
                            if (alarmCleared_json
                                and 'List' in alarmCleared_json
                                and 'value' in alarmCleared_json['List']
                                and alarmCleared_json['List']['value']
                            ):
                                alarmCleared_json_value = alarmCleared_json['List']['value'][0]
                                audit_logger.info(f"Function: clear_alarm_director {dns_entity} alarmCleared_json_value = {alarmCleared_json_value}")
                                clearOutput += f"\n\t- Unable to clear alarm. Current alarm status: {alarmCleared_json_value['severity']}"
                                result['status'] = 'success'
                            else:
                                ### ALARM IS NO LONGER EXISTING ###
                                clearOutput += f"\n\t- Alarm is no longer existing on the Versa Director [{master_ip}]"
                                result['status'] = 'success'
                                # print("ALARM IS NO LONGER EXISTING ON THE DIRECTOR") ###### TEMPORARY ######
                else:
                    clearOutput += f"\n\t- Unable to query the alarm from the Versa Director [{master_ip}]"
                    result['status'] = 'fail'
            else:
                clearOutput += f"\n\t- Unable to capture Versa Director."
                result['status'] = 'fail'
    return clearOutput, result


## MAIN FUNCTION
def main_function():
    show_time = "YES"
    start_time = time.perf_counter()
    global main_failed_count
    global cont
    global alarm_mon
    global alarm_year
    global global_peer
    main_failed_count_to_neid = 0
    main_failed_count_from_neid = 0
    circuit_failed_count_to_neid = 0
    circuit_failed_count_from_neid = 0
    global_peer = []
    main_failed_count = 0
    cont = 0
    problem_dict = prob_summ_dict(problem)
    if 'INCIDENT START TIME' in problem_dict:
        if problem_dict['INCIDENT START TIME']:
            alarm_mon = problem_dict['INCIDENT START TIME'].split()[0].split('/')[0]
            alarm_year = problem_dict['INCIDENT START TIME'].split()[0].split('/')[2]
        else:
            current_date_today = datetime.datetime.now()
            alarm_mon = current_date_today.month
            alarm_year = current_date_today.year
    else:
        current_date_today = datetime.datetime.now()
        alarm_mon = current_date_today.month
        alarm_year = current_date_today.year
    passwd = dec_pass(encps)
    pText = problem_dict['TEXT']
    from_match = re.search(r'from\s(.*?)/', pText).group(1)
    from_path = re.search(r'/(.*?)\sto', pText).group(1)
    to_match = re.search(r'to\s(.*?)/', pText).group(1)
    to_path = re.search(r'to\s(.*?)\sfor', pText).group(1).split('/')[1]
    fwdClass = re.search(r'for fwdClass\s(.*?)\sis', pText).group(1)
    ### SAMPLE ALARM ## DNS ENTERED: vzvnvcih-sto-35197317e016
    ## PROACTIVE: PRIORITY 2
    ## 
    ## INCIDENT START TIME: 01/14/2024 06:57:05
    ## NEID: vzvnvcih-sto-35197317e016
    ## HOSTNAME: vzvnvcih-sto-35197317e016
    ## PRODUCT TYPE: Managed WAN
    ## EQUIPMENT TYPE: Router
    ## INCIDENT TYPE: SDWANPathUpDown SOURCED FROM ASSURE1
    ## ASSURE1 ALARM ID: 79929170785
    ## TEXT: Datapath from vzvnvcih-dtm-35197319e014/INET-A to vzvnvcih-sto-35197317e016/INET-A for fwdClass fc_ef is down
    print(f"PING TEST from domain {domain}:\n=====================================")
    packt_cnt = 3
    from_neid = get_neid(from_match)
    if 'N/A'.lower() not in from_neid.lower():
        # ping_from_host, ping_from_packets_transmitted, ping_from_packets_received, ping_from_packet_loss, ping_from_time  = ping_host(from_neid,3)
        ping_from_ping_errors = ""
        ping_from_host, ping_from_packets_transmitted, ping_from_packets_received, ping_from_packet_loss, ping_from_time, ping_from_ping_errors  = ping_host(from_neid,packt_cnt)
        audit_logger.info(f"Function: main_function - ping_from_host {ping_from_host}")
        audit_logger.info(f"Function: main_function - ping_from_packets_transmitted {ping_from_packets_transmitted}")
        audit_logger.info(f"Function: main_function - ping_from_packets_received {ping_from_packets_received}")
        audit_logger.info(f"Function: main_function - ping_from_packet_loss {ping_from_packet_loss}")
        audit_logger.info(f"Function: main_function - ping_from_time {ping_from_time}")
        audit_logger.info(f"Function: main_function - ping_from_ping_errors {ping_from_ping_errors}")
        print(f'Ping to {from_neid} < packet count: {packt_cnt} >')
        if ping_from_host:
            print(f'\t- {ping_from_packets_transmitted} packets transmitted {ping_from_packets_received} received {ping_from_packet_loss}% packet loss time {ping_from_time}ms')
        else:
            print(f'\t- Ping failed to {from_neid}.')
        if ping_from_ping_errors:
            #if ping_from_ping_errors != "failed":
            if "failed" not in ping_from_ping_errors:
                print(f'\t- Ping errors found towards {from_neid}. Errors: {ping_from_ping_errors}')
            if 'service not known' in ping_from_ping_errors.lower().strip():
                update_final_string('obs', f"Failed to ping {from_neid} as it's not resolving DNS.")
                update_final_string('npoa', f"Check {from_neid} as it's not resolving DNS.")
                print(f"\t- Failed to ping {from_neid} as it's not resolving DNS.")
    else:
        print(f'Ping to {from_neid} - Failed: Unable to capture the NEID from hostname: {from_match} on ESP.')
        update_final_string('obs', f'Unable to capture the NEID from hostname: {from_match} on ESP.')
        update_final_string('npoa', f'Have NOC check this manually.')
        main_failed_count += 1
        #
    to_neid = get_neid(to_match)
    if 'N/A'.lower() not in to_neid.lower():
        # ping_to_host, ping_to_packets_transmitted, ping_to_packets_received, ping_to_packet_loss, ping_to_time = ping_host(to_neid,3)
        ping_to_ping_errors = ""
        ping_to_host, ping_to_packets_transmitted, ping_to_packets_received, ping_to_packet_loss, ping_to_time, ping_to_ping_errors = ping_host(to_neid,packt_cnt)
        audit_logger.info(f"Function: main_function - ping_to_host {ping_to_host}")
        audit_logger.info(f"Function: main_function - ping_to_packets_transmitted {ping_to_packets_transmitted}")
        audit_logger.info(f"Function: main_function - ping_to_packets_received {ping_to_packets_received}")
        audit_logger.info(f"Function: main_function - ping_to_packet_loss {ping_to_packet_loss}")
        audit_logger.info(f"Function: main_function - ping_to_time {ping_to_time}")
        audit_logger.info(f"Function: main_function - ping_to_ping_errors {ping_to_ping_errors}")
        print(f'Ping to {to_neid} < packet count: {packt_cnt} >')
        if ping_to_host:
            print(f'\t- {ping_to_packets_transmitted} packets transmitted {ping_to_packets_received} received {ping_to_packet_loss}% packet loss time {ping_to_time}ms')
        else:
            print(f'\t- Ping failed to {to_neid}.')
        if ping_to_ping_errors:
            #if ping_to_ping_errors != "failed":
            if "failed" not in ping_to_ping_errors:
                print(f'\t- Ping errors found towards {to_neid}. Errors: {ping_to_ping_errors}')
            if 'service not known' in ping_to_ping_errors.lower().strip():
                update_final_string('obs', f"Failed to ping {to_neid} as it's not resolving DNS.")
                update_final_string('npoa', f"Check {to_neid} as it's not resolving DNS.")
                print(f"\t- Failed to ping {to_neid} as it's not resolving DNS.")
    else:
        print(f'Ping to {from_neid} - Failed: Unable to capture the NEID from hostname: {to_match} on ESP.')
        update_final_string('obs', f'Unable to capture the NEID from hostname: {to_match} on ESP.')
        update_final_string('npoa', f'Have NOC check this manually.')
        main_failed_count += 1
        #
    if ping_from_host == True and ping_to_host == True:
        update_final_string('obs', f'Both ping towards ({from_match}) and ({to_match}) from domain {domain} is successful.')
    elif ping_from_host == False and ping_to_host == True :
        fr_interface_list_up_ip_add = []
        to_routing_ins = ""
        to_tenant = ""
        to_interface_list = []
        to_interface_list_up = []
        fr_routing_ins = ""
        ft_sdwanpeer = {}
        to_sdwanpeer = {}
        to_sdwanpath_cnt = "N/A"
        update_final_string('obs', f'Only ping towards Device ({to_match}) from domain {domain} is successful.')
        update_final_string('npoa', f'Need to check device {from_match} if this should be really unreachable or what is the reason why it\'s unreachable from the domain {domain}.')
        main_failed_count_to_neid_1 = 0
        internet_failed_count_to_neid = 0
        to_interface_list_sdwan_nat = []
        circuit_failed_count_to_neid = 0
        main_failed_count_to_neid_1, internet_failed_count_to_neid, circuit_failed_count_to_neid = triage_process(to_neid, from_match, from_path, to_match, to_path, fwdClass, passwd, to_tenant, to_routing_ins, fr_interface_list_up_ip_add, to_interface_list, to_interface_list_up, fr_routing_ins, to_sdwanpeer, to_sdwanpath_cnt, to_interface_list_sdwan_nat, "PARTIAL")
        main_failed_count += main_failed_count_to_neid_1
        main_failed_count += 1
        main_failed_count_to_neid = main_failed_count_to_neid_1
        main_failed_count_from_neid = 10
    elif ping_from_host == True and ping_to_host == False :
        to_interface_list_up_ip_add = []
        fr_interface_list = []
        fr_interface_list_up = []
        fr_routing_ins = ""
        fr_tenant = ""
        to_routing_ins = ""
        ft_sdwanpeer = {}
        to_sdwanpeer = {}
        ft_sdwanpath_cnt = "N/A"
        update_final_string('obs', f'Only ping towards Device ({from_match}) from domain {domain} is successful.')
        update_final_string('npoa', f'Need to check device {to_match} if this should be really unreachable or what is the reason why it\'s unreachable from the domain ({domain}).')
        main_failed_count_ft_neid_1 = 0
        internet_failed_count_ft_neid = 0
        ft_interface_list_sdwan_nat = []
        circuit_failed_count_from_neid = 0
        main_failed_count_ft_neid_1, internet_failed_count_ft_neid, circuit_failed_count_from_neid = triage_process(from_neid, to_match, to_path, from_match, from_path, fwdClass, passwd, fr_tenant, fr_routing_ins, to_interface_list_up_ip_add, fr_interface_list, fr_interface_list_up, to_routing_ins, ft_sdwanpeer, ft_sdwanpath_cnt, ft_interface_list_sdwan_nat, "PARTIAL")
        main_failed_count += main_failed_count_ft_neid_1
        main_failed_count += 1
        main_failed_count_from_neid = main_failed_count_ft_neid_1
        main_failed_count_to_neid = 10
    else:
        update_final_string('obs', f'Both ping towards ({from_match}) and ({to_match}) from domain {domain} Failed.')
        update_final_string('npoa', f'Need to check both device {from_match} and {to_match} if this should be really unreachable or what is the reason why it\'s unreachable from the domain ({domain}).')
        main_failed_count += 1
    #
    if main_failed_count == 0:
        ### LOGGING IN TO DEVICE
        fr_tenant, fr_routing_ins, fr_interface_list_up_ip_add, fr_interface_list, fr_interface_list_up, ft_status, ft_sdwanpeer, ft_sdwanpath_cnt, ft_interface_list_sdwan_nat = capture_data(from_neid, from_path, passwd, to_match, to_path, fwdClass)
        to_tenant, to_routing_ins, to_interface_list_up_ip_add, to_interface_list, to_interface_list_up, to_status, to_sdwanpeer, to_sdwanpath_cnt, to_interface_list_sdwan_nat = capture_data(to_neid, to_path, passwd, from_match, from_path, fwdClass)
        if "success" in to_status.strip().lower() and "success" in ft_status.strip().lower(): # Both Success
            # Triage on to_neid
            main_failed_count_to_neid_2 = 0
            internet_failed_count_to_neid = 0
            circuit_failed_count_to_neid = 0
            main_failed_count_to_neid_2, internet_failed_count_to_neid, circuit_failed_count_to_neid = triage_process(to_neid, from_match, from_path, to_match, to_path, fwdClass, passwd, to_tenant, to_routing_ins, fr_interface_list_up_ip_add, to_interface_list, to_interface_list_up, fr_routing_ins, to_sdwanpeer, to_sdwanpath_cnt, to_interface_list_sdwan_nat, "FULL")
            main_failed_count += main_failed_count_to_neid_2
            main_failed_count_to_neid += main_failed_count_to_neid_2
            # Triage on from_neid
            main_failed_count_from_neid_4 = 0
            internet_failed_count_ft_neid = 0
            circuit_failed_count_from_neid = 0
            main_failed_count_from_neid_4, internet_failed_count_ft_neid, circuit_failed_count_from_neid = triage_process(from_neid, to_match, to_path, from_match, from_path, fwdClass, passwd, fr_tenant, fr_routing_ins, to_interface_list_up_ip_add, fr_interface_list, fr_interface_list_up, to_routing_ins, ft_sdwanpeer,  ft_sdwanpath_cnt, ft_interface_list_sdwan_nat, "FULL")
            main_failed_count += main_failed_count_from_neid_4
            main_failed_count_from_neid += main_failed_count_from_neid_4
                # Additional condition where to check first
            if global_peer:
                global_peer_list = [item.lower() for item in global_peer]
                if global_peer_list:
                    if 'down'.lower() in global_peer_list or 'init'.lower() in global_peer_list:
                        down_count = 0
                        down_count += int(global_peer_list.count('down'))
                        down_count += int(global_peer_list.count('init'))
                        if down_count == 1:
                            down_str = ">"
                            if 'init'.lower() in global_peer_list:
                                init_index = global_peer_list.index('init')
                                if init_index == 0:
                                    down_str += f" - Device {to_neid} is in [init] state from: {from_neid}"
                                if init_index == 1:
                                    down_str += f" - Device {from_neid} is in [init] state from: {to_neid}"
                            if 'down'.lower() in global_peer_list:
                                down_index = global_peer_list.index('down')
                                if down_index == 0:
                                    down_str += f" - Device {to_neid} is in [down] state from: {from_neid}"
                                if down_index == 1:
                                    down_str += f" - Device {from_neid} is in [down] state from: {to_neid}"
                            update_final_string('obs', f'{down_str}.')
                        elif down_count == 2:
                            update_final_string('npoa', f'Both of the sdwan peer is down/init on both side.')
        else:
            main_failed_count += 1
            to_interface_list_up_ip_add = []
            fr_interface_list = []
            fr_interface_list_up = []
            fr_routing_ins = "" 
            fr_tenant = ""
            main_failed_count_ft_neid_3 = 0
            internet_failed_count_ft_neid = 0
            circuit_failed_count_from_neid = 0
            main_failed_count_ft_neid_3, internet_failed_count_ft_neid, circuit_failed_count_from_neid = triage_process(from_neid, to_match, to_path, from_match, from_path, fwdClass, passwd, fr_tenant, fr_routing_ins, to_interface_list_up_ip_add, fr_interface_list, fr_interface_list_up, to_routing_ins, ft_sdwanpeer, ft_sdwanpath_cnt, ft_interface_list_sdwan_nat, "PARTIAL")
            main_failed_count += main_failed_count_ft_neid_3
            main_failed_count_from_neid += main_failed_count_ft_neid_3
            fr_interface_list_up_ip_add = []
            to_routing_ins = ""
            to_tenant = ""
            to_interface_list = []
            to_interface_list_up = []
            main_failed_count_to_neid_5 = 0
            internet_failed_count_to_neid = 0
            circuit_failed_count_to_neid = 0
            main_failed_count_to_neid_5, internet_failed_count_to_neid, circuit_failed_count_to_neid = triage_process(to_neid, from_match, from_path, to_match, to_path, fwdClass, passwd, to_tenant, to_routing_ins, fr_interface_list_up_ip_add, to_interface_list, to_interface_list_up, fr_routing_ins, to_sdwanpeer,  to_sdwanpath_cnt, to_interface_list_sdwan_nat, "PARTIAL")
            main_failed_count += main_failed_count_to_neid_5
            main_failed_count_to_neid += main_failed_count_to_neid_5 + internet_failed_count_to_neid
    else:
        update_final_string('obs', f'One or both device are unreachable from the domain.')
        update_final_string('npoa', f'Manually check the reachability or status of the affected device(s).')
    # Additional condition where to check first
    audit_logger.info(f"Function: main_function - main_failed_count {main_failed_count}")
    audit_logger.info(f"Function: main_function - ping_from_host {ping_from_host}")
    audit_logger.info(f"Function: main_function - ping_to_host {ping_to_host}")
    audit_logger.info(f"Function: main_function - global_peer {global_peer}")
    audit_logger.info(f"Function: main_function - from_match {from_match}")
    audit_logger.info(f"Function: main_function - to_match {to_match}")
    audit_logger.info(f"Function: main_function - main_failed_count_to_neid {main_failed_count_to_neid}")
    audit_logger.info(f"Function: main_function - main_failed_count_from_neid {main_failed_count_from_neid}")
    audit_logger.info(f"Function: main_function - circuit_failed_count_to_neid {circuit_failed_count_from_neid}")
    audit_logger.info(f"Function: main_function - circuit_failed_count_from_neid {circuit_failed_count_from_neid}")
    if main_failed_count:
        if 'down' in global_peer or 'N/A' in global_peer:
            if main_failed_count_to_neid > main_failed_count_from_neid:
                update_final_string('npoa', f'Device {to_neid} has more errors found. Please check this first.')
            elif main_failed_count_to_neid < main_failed_count_from_neid:
                update_final_string('npoa', f'Device {from_neid} has more errors found. Please check this first.')
            #
            if ping_from_host == True and ping_to_host == True:
                if circuit_failed_count_to_neid > circuit_failed_count_from_neid:
                    update_final_string('npoa', f'Device {to_neid} seems to have circuit issues.')
                elif circuit_failed_count_to_neid < circuit_failed_count_from_neid:
                    update_final_string('npoa', f'Device {from_neid} seems to have circuit issues.')
                else:
                    update_final_string('npoa', f'It seems to have an upstream issue between two sites.')
    #
    audit_logger.info(f"Function: main / To: {to_neid}: {main_failed_count_to_neid} | From: {from_neid}: {main_failed_count_from_neid}")
    if main_failed_count == 0:
        update_final_string('npoa', f'No Issues Found on all checks.')
        print(f"\n=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+\n{global_obs}\n{global_npoa}")
        print(f"=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+")
        print("ava-TRIAGE-SDWANPathUpDown")
        print(f"=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+")
        ### Added for VersaDirector clearing
        clearAttempt, result = clear_alarm_director(to_neid, to_tenant, pText.strip(), passwd)
        print(f"Attempting to clear alarm from Versa Director:\n=====================================")
        if clearAttempt:
            print(clearAttempt)
        else:
            print("\t- Unable to clear the alarm from the Versa Director.")
        ### Added for assure1 clearing
        print(f"=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+")
        as1_id = problem_dict['ASSURE1 ALARM ID']
        print(f"Assure1 Alarm: {as1_id} - Attempting to clear:\n=====================================")
        status, updated_row = as1_clear(as1_id)
        if updated_row >= 1:
            print(f'\t- Number of rows modified/cleared: {updated_row}\n')
        else:
            print(f'\t- Assure1 Alarm ID: {as1_id} is no longer present in Assure1 database.\n')
        ### END - assure1 clearing
    else:
        print(f"\n=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+\n{global_obs}\n{global_npoa}")
    #
    end_time = time.perf_counter()
    duration_seconds = end_time - start_time
    audit_logger.info(f"The automation took {duration_seconds} seconds to complete. - <TIMING>")


if __name__ == '__main__':
    try:    
        main_function()
    except Exception as e:
        print (f"Error: {e}")
        sys.exit()


