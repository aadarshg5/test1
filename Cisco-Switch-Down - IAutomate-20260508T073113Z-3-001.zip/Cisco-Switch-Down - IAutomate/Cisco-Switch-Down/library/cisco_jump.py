#!/usr/bin/python
from ansible.module_utils.basic import AnsibleModule
from netmiko import ConnectHandler
import time

def run_module():
    # Define the inputs
    module_args = dict(
        router_host=dict(type='str', required=True),
        router_user=dict(type='str', required=True),
        router_pass=dict(type='str', required=True, no_log=True),
        router_secret=dict(type='str', required=True, no_log=True),
        switch_ip=dict(type='str', required=True),
        switch_user=dict(type='str', required=True),
        switch_pass=dict(type='str', required=True, no_log=True),
        command=dict(type='str', default='show version')
    )

    result = dict(changed=False, output='')
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # Dictionary for the Viptela Router
    device = {
        'device_type': 'cisco_viptela',
        'host': module.params['router_host'],
        'username': module.params['router_user'],
        'password': module.params['router_pass'],
        'secret': module.params['router_secret'],
        'global_delay_factor': 2,
    }

    try:
        # 1. Connect to the Viptela Router
        net_connect = ConnectHandler(**device)
        
        # 2. Jump from Router to Switch
        ssh_cmd = f"ssh -l {module.params['switch_user']} {module.params['switch_ip']}"
        net_connect.write_channel(ssh_cmd + "\n")
        time.sleep(3)

        output = net_connect.read_channel()

        # Handle SSH Fingerprint
        if "yes/no" in output.lower():
            net_connect.write_channel("yes\n")
            time.sleep(3)
            output = net_connect.read_channel()

        # Handle Switch Password
        if "password" in output.lower():
            net_connect.write_channel(module.params['switch_pass'] + "\n")
            time.sleep(5)
            output = net_connect.read_channel()

        # 3. Verify Switch Access and run command
        if "#" in output or ">" in output:
            # Use send_command_timing for pings in nested shells 
            # to avoid strict prompt matching issues.
            final_output = net_connect.send_command_timing(
                module.params['command'],
                last_step=True # Tells Netmiko not to wait for more output
            )
            result['output'] = final_output
            result['changed'] = True
        else:
            module.fail_json(msg="Failed to reach switch prompt", last_output=output)

        # Cleanup
        net_connect.write_channel("exit\n")
        net_connect.disconnect()
        module.exit_json(**result)

    except Exception as e:
        module.fail_json(msg=f"Execution failed: {str(e)}")

if __name__ == '__main__':
    run_module()